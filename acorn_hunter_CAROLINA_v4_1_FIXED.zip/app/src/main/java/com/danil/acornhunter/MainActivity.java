package com.danil.acornhunter;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.WindowInsets;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.ToneGenerator;
import android.media.AudioManager;
import java.util.*;

/**
 * Acorn Hunter v4: a tiny original raycasting FPS inspired by the technical
 * feel of early 90s corridor shooters, with original map/graphics and the
 * user's supplied music/Carolina portrait.
 */
public class MainActivity extends Activity {
    MediaPlayer music;
    ToneGenerator tones;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        hideSystemUI();
        tones = new ToneGenerator(AudioManager.STREAM_MUSIC, 65);
        music = MediaPlayer.create(this, R.raw.acorn_music);
        if (music != null) { music.setLooping(true); music.setVolume(0.30f, 0.30f); }
        setContentView(new GameView(this));
    }

    void hideSystemUI() {
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        w.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        }
    }

    void beep(int type) {
        if (tones == null) return;
        try { tones.startTone(type, 90); } catch (Exception ignored) {}
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }
    @Override protected void onPause() { super.onPause(); if (music != null && music.isPlaying()) music.pause(); }
    @Override protected void onResume() { super.onResume(); hideSystemUI(); }
    @Override protected void onDestroy() {
        if (music != null) { music.release(); music = null; }
        if (tones != null) { tones.release(); tones = null; }
        super.onDestroy();
    }

    static class GameView extends View {
        final MainActivity host;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint pixel = new Paint();
        final Random rnd = new Random(42);
        Bitmap face;

        // 0 = title, 1 = playing, 2 = level transition, 3 = victory, 4 = defeat
        int screen = 0;
        int level = 1;
        int found = 0;
        int lives = 100;
        int ammo = 30;
        boolean muted = false;
        boolean firing = false;
        long fireUntil = 0;
        long lastFrame = System.nanoTime();
        long lastEnemyThink = 0;
        long toastUntil = 0;
        String toast = "";
        float playerX, playerY, angle;
        float bob = 0;
        float joystickX = 0, joystickY = 0;
        boolean joystickActive = false;
        float touchStartX, touchStartY;
        int activePointer = -1;
        float[] depth;

        final int MAP_W = 16, MAP_H = 12;
        int[][] map;
        ArrayList<Item> acorns = new ArrayList<>();
        ArrayList<Item> fakes = new ArrayList<>();
        ArrayList<Enemy> enemies = new ArrayList<>();

        static class Item { double x,y; boolean alive=true; Item(double x,double y){this.x=x;this.y=y;} }
        static class Enemy { double x,y; int hp=2; boolean alive=true; long hitFlash=0; Enemy(double x,double y){this.x=x;this.y=y;} }
        static class Sprite { double x,y,d; int type; Sprite(double x,double y,double d,int type){this.x=x;this.y=y;this.d=d;this.type=type;} }

        final int[][][] MAPS = new int[][][]{
            {
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1},
                {1,0,1,1,1,0,1,0,1,1,1,1,1,1,0,1},
                {1,0,0,0,1,0,0,0,1,0,0,0,0,1,0,1},
                {1,1,1,0,1,1,1,1,1,0,1,1,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1},
                {1,0,1,1,1,1,1,0,1,0,1,0,1,1,1,1},
                {1,0,0,0,0,0,1,0,1,0,0,0,0,0,0,1},
                {1,1,1,1,1,0,1,0,1,1,1,1,1,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
            },
            {
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,1},
                {1,0,1,0,1,0,1,1,1,0,1,0,1,1,0,1},
                {1,0,1,0,0,0,0,0,1,0,0,0,1,0,0,1},
                {1,0,1,1,1,1,1,0,1,1,1,0,1,0,1,1},
                {1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1},
                {1,1,1,1,1,0,1,1,1,0,1,1,1,1,0,1},
                {1,0,0,0,0,0,0,0,1,0,0,0,0,1,0,1},
                {1,0,1,1,1,1,1,0,1,1,1,1,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
                {1,0,1,1,1,1,1,1,1,1,1,1,0,0,0,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
            },
            {
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1},
                {1,0,1,1,1,1,0,1,0,1,1,1,1,1,0,1},
                {1,0,0,0,0,1,0,0,0,1,0,0,0,1,0,1},
                {1,1,1,1,0,1,1,1,1,1,0,1,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1},
                {1,0,1,1,1,1,1,1,1,1,0,1,1,1,0,1},
                {1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1},
                {1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
                {1,0,1,1,1,1,1,1,1,1,1,1,0,0,0,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
            }
        };

        GameView(MainActivity c) {
            super(c); host=c; setFocusable(true);
            face=BitmapFactory.decodeResource(getResources(), R.drawable.carolina_face);
            pixel.setAntiAlias(false);
        }

        void begin() {
            screen=1; level=1; muted=false; found=0; lives=100; ammo=30;
            if (host.music != null && !muted && !host.music.isPlaying()) host.music.start();
            loadLevel();
        }

        void loadLevel() {
            map=MAPS[level-1]; found=0; ammo=30 + level*8; lives=Math.min(100,lives+15);
            acorns.clear(); fakes.clear(); enemies.clear();
            playerX=1.7; playerY=1.7; angle=0.15;
            // fixed placements keep the hunt deterministic and fair.
            if(level==1){
                addAcorn(3.5,1.5); addAcorn(5.5,3.5); addAcorn(11.5,3.5); addAcorn(13.5,7.5);
                addEnemy(8.5,5.5); addEnemy(12.5,9.5);
                addFake(4.5,7.5);
            } else if(level==2){
                addAcorn(3.5,1.5); addAcorn(6.5,3.5); addAcorn(10.5,3.5); addAcorn(12.5,5.5); addAcorn(8.5,9.5);
                addEnemy(5.5,7.5); addEnemy(9.5,5.5); addEnemy(12.5,9.5); addEnemy(3.5,9.5);
                addFake(6.5,7.5); addFake(11.5,7.5);
            } else {
                addAcorn(3.5,1.5); addAcorn(6.5,1.5); addAcorn(11.5,3.5); addAcorn(3.5,5.5); addAcorn(8.5,5.5); addAcorn(12.5,7.5); addAcorn(6.5,9.5);
                addEnemy(4.5,3.5); addEnemy(10.5,3.5); addEnemy(13.5,5.5); addEnemy(5.5,7.5); addEnemy(10.5,9.5); addEnemy(12.5,9.5);
                addFake(4.5,9.5); addFake(10.5,5.5); addFake(8.5,7.5);
            }
            toast=level==1?"Операция началась. Найди жёлуди.":"Уровень "+level+": белки уже в курсе.";
            toastUntil=System.currentTimeMillis()+2200;
            invalidate();
        }
        void addAcorn(double x,double y){acorns.add(new Item(x,y));}
        void addFake(double x,double y){fakes.add(new Item(x,y));}
        void addEnemy(double x,double y){enemies.add(new Enemy(x,y));}

        boolean wall(double x,double y){
            int ix=(int)Math.floor(x), iy=(int)Math.floor(y);
            if(ix<0||iy<0||ix>=MAP_W||iy>=MAP_H) return true;
            return map[iy][ix]!=0;
        }
        boolean canStand(double x,double y){
            double r=.22;
            return !wall(x-r,y-r)&&!wall(x+r,y-r)&&!wall(x-r,y+r)&&!wall(x+r,y+r);
        }
        double normAngle(double a){ while(a<-Math.PI)a+=Math.PI*2; while(a>Math.PI)a-=Math.PI*2; return a; }
        double dist(double x,double y,double x2,double y2){return Math.hypot(x-x2,y-y2);}

        void txt(Canvas c, String text, float x, float y, float size, int color, boolean bold){
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setTextSize(size);
            p.setTypeface(bold ? Typeface.create(Typeface.DEFAULT, Typeface.BOLD) : Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
            c.drawText(text, x, y, p);
        }

        void txtCenter(Canvas c, String text, float cx, float baseline, float size, int color, boolean bold){
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setTextSize(size);
            p.setTypeface(bold ? Typeface.create(Typeface.DEFAULT, Typeface.BOLD) : Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
            c.drawText(text, cx - p.measureText(text)/2f, baseline, p);
        }

        void drawRotatePrompt(Canvas c, int w, int h){
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(18,17,25));
            c.drawRect(0,0,w,h,p);
            txtCenter(c, "ПОВЕРНИ ТЕЛЕФОН", w/2f, h*.40f, Math.min(30f,w*.07f), Color.WHITE, true);
            txtCenter(c, "ИГРА РАБОТАЕТ В ГОРИЗОНТАЛЬНОМ РЕЖИМЕ", w/2f, h*.48f, Math.min(15f,w*.04f), Color.LTGRAY, false);
            txtCenter(c, "↻", w/2f, h*.66f, Math.min(64f,w*.16f), Color.rgb(255,176,186), true);
        }

        void update(float dt){
            if(screen!=1) return;
            double forward=-joystickY, turn=joystickX;
            if(joystickActive){
                angle += turn*2.6*dt;
                double speed=(1.65+level*.08)*forward*dt;
                movePlayer(Math.cos(angle)*speed,Math.sin(angle)*speed);
                bob += Math.abs(speed)*16;
            }
            // Passive enemy movement, deliberately slow and arcade-like.
            long now=System.currentTimeMillis();
            if(now-lastEnemyThink>80){
                lastEnemyThink=now;
                for(Enemy e:enemies) if(e.alive){
                    double d=dist(playerX,playerY,e.x,e.y);
                    if(d<5.2 && d>0.65){
                        double ex=(playerX-e.x)/d*.018, ey=(playerY-e.y)/d*.018;
                        if(canStand(e.x+ex,e.y+ey)){e.x+=ex;e.y+=ey;}
                    }
                    if(d<.72){lives-=1; if(lives<=0){screen=4; toast="Белки победили. Это позор."; toastUntil=System.currentTimeMillis()+1400;}}
                }
            }
            // auto-pickup
            for(int i=acorns.size()-1;i>=0;i--) if(acorns.get(i).alive && dist(playerX,playerY,acorns.get(i).x,acorns.get(i).y)<.48){
                acorns.remove(i); found++; host.beep(ToneGenerator.TONE_PROP_BEEP2);
                if(found==1) toast="Котёнок, один есть. Я в тебя верила.";
                else if(found==2) toast="Данил сообщает: прогресс исторический.";
                else toast="ЖЁЛУДЬ! Дарина одобряет.";
                toastUntil=System.currentTimeMillis()+1300;
            }
            for(int i=fakes.size()-1;i>=0;i--) if(fakes.get(i).alive && dist(playerX,playerY,fakes.get(i).x,fakes.get(i).y)<.42){
                fakes.remove(i); lives-=15; host.beep(ToneGenerator.TONE_PROP_NACK);
                toast="ЭТО НЕ ЖЁЛУДЬ. Потеряно 15 HP."; toastUntil=System.currentTimeMillis()+1300;
                if(lives<=0){screen=4;toast="ШИШКА ПОБЕДИЛА.";toastUntil=System.currentTimeMillis()+1400;}
            }
            if(found>=acornGoal()){ screen=2; toast="Уровень пройден."; toastUntil=System.currentTimeMillis()+1600; }
            if(firing && System.currentTimeMillis()<fireUntil) shoot();
        }
        int acornGoal(){return level==1?4:level==2?5:7;}

        void movePlayer(double dx,double dy){
            double nx=playerX+dx, ny=playerY+dy;
            if(canStand(nx,playerY)) playerX=nx;
            if(canStand(playerX,ny)) playerY=ny;
        }

        void shoot(){
            if(ammo<=0){toast="Пусто. Даже желудей не осталось.";toastUntil=System.currentTimeMillis()+700;firing=false;return;}
            ammo--; firing=false; fireUntil=0; host.beep(ToneGenerator.TONE_PROP_BEEP);
            Enemy best=null; double bestD=99;
            for(Enemy e:enemies) if(e.alive){
                double dx=e.x-playerX, dy=e.y-playerY, d=Math.hypot(dx,dy);
                double rel=Math.abs(normAngle(Math.atan2(dy,dx)-angle));
                if(rel<0.12 && d<7.0 && d<bestD && clearLine(e.x,e.y)){best=e;bestD=d;}
            }
            if(best!=null){best.hp--;best.hitFlash=System.currentTimeMillis()+130;if(best.hp<=0){best.alive=false;toast="БЕЛКА ПОВЕРЖЕНА.";toastUntil=System.currentTimeMillis()+900;}else{toast="ПОПАЛА.";toastUntil=System.currentTimeMillis()+500;}}
        }
        boolean clearLine(double tx,double ty){
            double dx=tx-playerX,dy=ty-playerY,d=Math.hypot(dx,dy),steps=(int)(d*20);
            for(int i=1;i<steps;i++){double x=playerX+dx*i/steps,y=playerY+dy*i/steps;if(wall(x,y))return false;}return true;
        }

        void raycast(Canvas c,int w,int h){
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(42,43,62)); c.drawRect(0,0,w,h*.48f,p);
            p.setColor(Color.rgb(31,30,28)); c.drawRect(0,h*.48f,w,h,p);
            // ceiling bands
            for(int y=0;y<h*.48;y+=18){p.setColor(Color.rgb(42+y/20,43+y/24,62+y/18));c.drawRect(0,y,w,y+1,p);}
            int rays=Math.min(420,Math.max(220,w/3));
            depth=new float[rays];
            double fov=Math.toRadians(66);
            double step=fov/rays;
            float colW=(float)w/rays;
            for(int i=0;i<rays;i++){
                double ra=angle-fov/2+step*(i+.5);
                double cos=Math.cos(ra),sin=Math.sin(ra);
                double rx=playerX,ry=playerY; double d=0;
                while(d<20){rx+=cos*.035;ry+=sin*.035;d+=.035;if(wall(rx,ry))break;}
                double corrected=d*Math.cos(ra-angle); depth[i]=(float)corrected;
                float wallH=(float)Math.min(h*1.7,h/(Math.max(.18,corrected))*.56);
                float top=h*.48f-wallH/2f, bottom=h*.48f+wallH/2f;
                int shade=(int)Math.max(35,195-corrected*22);
                // alternating brick-ish columns without using copyrighted textures
                int brick=(i%7==0)?12:0;
                p.setColor(Color.rgb(Math.max(20,shade+brick),Math.max(20,shade-18+brick),Math.max(20,shade-35+brick)));
                c.drawRect(i*colW,top,(i+1)*colW+1,bottom,p);
            }
        }

        void renderSprites(Canvas c,int w,int h){
            ArrayList<Sprite> list=new ArrayList<>();
            for(Item a:acorns) if(a.alive) list.add(new Sprite(a.x,a.y,dist(playerX,playerY,a.x,a.y),1));
            for(Item a:fakes) if(a.alive) list.add(new Sprite(a.x,a.y,dist(playerX,playerY,a.x,a.y),2));
            for(Enemy e:enemies) if(e.alive) list.add(new Sprite(e.x,e.y,dist(playerX,playerY,e.x,e.y),3));
            Collections.sort(list,(a,b)->Double.compare(b.d,a.d));
            double fov=Math.toRadians(66);
            for(Sprite s:list){
                double dx=s.x-playerX,dy=s.y-playerY,d=Math.hypot(dx,dy), rel=normAngle(Math.atan2(dy,dx)-angle);
                if(Math.abs(rel)>fov*.62) continue;
                int sx=(int)((.5+rel/fov)*w);
                int ray=(int)((double)sx/w*depth.length); if(ray<0||ray>=depth.length||d>depth[ray]+.25) continue;
                float size=(float)(h/(d*.92)); int top=(int)(h*.48-size*.55), bottom=(int)(h*.48+size*.45);
                if(s.type==3) drawSquirrel(c,sx,top,bottom,size);
                else drawAcornBillboard(c,sx,(top+bottom)/2,(int)(size*.42),s.type==2);
            }
        }

        void drawAcornBillboard(Canvas c,int x,int cy,int r,boolean fake){
            p.setStyle(Paint.Style.FILL);p.setColor(fake?Color.rgb(100,78,55):Color.rgb(205,133,65));
            c.drawOval(x-r,cy-r,x+r,cy+r*1.25f,p);
            p.setColor(fake?Color.rgb(63,54,45):Color.rgb(89,61,42));
            c.drawRect(x-r,cy-r/2,x+r,cy-r/5,p);
            if(!fake){p.setColor(Color.rgb(255,211,125));c.drawCircle(x-r*.25f,cy,Math.max(2,r*.16f),p);}
        }
        void drawSquirrel(Canvas c,int x,int top,int bottom,float size){
            int cy=(top+bottom)/2; float r=Math.max(10,size*.22f);
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(167,93,52));c.drawCircle(x,cy,r,p);
            Path ears=new Path();ears.moveTo(x-r*.8f,cy-r*.5f);ears.lineTo(x-r*.4f,cy-r*1.3f);ears.lineTo(x,cy-r*.65f);ears.close();c.drawPath(ears,p);
            ears.reset();ears.moveTo(x+r*.8f,cy-r*.5f);ears.lineTo(x+r*.4f,cy-r*1.3f);ears.lineTo(x,cy-r*.65f);ears.close();c.drawPath(ears,p);
            p.setColor(Color.rgb(45,31,30));c.drawCircle(x-r*.35f,cy-r*.12f,Math.max(2,r*.12f),p);c.drawCircle(x+r*.35f,cy-r*.12f,Math.max(2,r*.12f),p);
            p.setColor(Color.rgb(240,170,120));c.drawCircle(x,cy+r*.28f,r*.28f,p);
        }

        void drawWeapon(Canvas c,int w,int h){
            float bobY=(float)Math.sin(bob*.55)*3;
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(35,27,29));
            Path gun=new Path();gun.moveTo(w*.43f,h);gun.lineTo(w*.46f,h*.78f);gun.lineTo(w*.54f,h*.78f);gun.lineTo(w*.57f,h);gun.close();c.drawPath(gun,p);
            p.setColor(Color.rgb(83,59,43));c.drawRoundRect(w*.475f,h*.70f+ bobY,w*.525f,h*.91f+bobY,10,10,p);
            p.setColor(Color.rgb(46,40,48));c.drawRoundRect(w*.455f,h*.83f+bobY,w*.545f,h*.99f+bobY,14,14,p);
            if(System.currentTimeMillis()<fireUntil){p.setColor(Color.rgb(255,218,122));Path flash=new Path();flash.moveTo(w*.5f,h*.67f);flash.lineTo(w*.47f,h*.76f);flash.lineTo(w*.5f,h*.74f);flash.lineTo(w*.53f,h*.76f);flash.close();c.drawPath(flash,p);}
        }

        void drawHud(Canvas c,int w,int h){
            p.setColor(Color.argb(220,18,17,25));c.drawRect(0,0,w,66,p);
            txt(c,"ОПЕРАЦИЯ «ЖЁЛУДЬ»",18,25,17,Color.WHITE,true);
            txt(c,"УР. "+level+"   ЖЁЛУДИ "+found+"/"+acornGoal(),18,49,14,Color.rgb(245,210,160),true);
            txt(c,"HP "+lives,w*.55f,27,16,lives<35?Color.rgb(255,110,120):Color.WHITE,true);
            txt(c,"AMMO "+ammo,w*.55f,50,14,Color.rgb(205,205,215),true);
            p.setColor(Color.argb(180,255,255,255));c.drawRoundRect(w-54,14,w-14,52,18,18,p);txtCenter(c,muted?"×":"♪",w-34,41,18,Color.rgb(25,23,30),true);
            drawMiniMap(c,w,h);
            // classic center crosshair
            p.setColor(Color.argb(205,255,240,210));p.setStrokeWidth(2);c.drawLine(w/2-9,h*.48f,w/2-2,h*.48f,p);c.drawLine(w/2+2,h*.48f,w/2+9,h*.48f,p);c.drawLine(w/2,h*.48f-9,w/2,h*.48f-2,p);c.drawLine(w/2,h*.48f+2,w/2,h*.48f+9,p);
            // Carolina portrait
            if(face!=null){
                int r=30; float cx=48,cy=h-58; Path clip=new Path();clip.addCircle(cx,cy,r,Path.Direction.CW);c.save();c.clipPath(clip);c.drawBitmap(face,null,new RectF(cx-r,cy-r,cx+r,cy+r),p);c.restore();
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(255,176,186));c.drawCircle(cx,cy,r,p);p.setStyle(Paint.Style.FILL);
            }
            txt(c,"CAROLINA",86,h-61,14,Color.WHITE,true);txt(c,"ОХОТНИК ЗА ЖЁЛУДЯМИ",86,h-42,11,Color.LTGRAY,false);
            // joystick
            float jcx=150,jcy=h-82;p.setColor(Color.argb(80,255,255,255));c.drawCircle(jcx,jcy,64,p);p.setColor(Color.argb(145,255,176,186));c.drawCircle(jcx+joystickX*38,jcy+joystickY*38,26,p);
            // fire button
            float fx=w-118,fy=h-88;p.setColor(Color.argb(155,255,176,186));c.drawCircle(fx,fy,58,p);txtCenter(c,"ВЗЯТЬ",fx,fy+5,15,Color.rgb(35,28,35),true);txtCenter(c,"/ АТАКА",fx,fy+23,12,Color.rgb(35,28,35),true);
            drawWeapon(c,w,h);
        }

        void drawMiniMap(Canvas c,int w,int h){
            float mw=128,mh=96,left=w-mw-72,top=72;
            p.setColor(Color.argb(185,10,10,14));c.drawRoundRect(left,top,left+mw,top+mh,12,12,p);
            if(map==null)return;
            float sx=mw/MAP_W, sy=mh/MAP_H;
            for(int yy=0;yy<MAP_H;yy++) for(int xx=0;xx<MAP_W;xx++){
                if(map[yy][xx]!=0){p.setColor(Color.rgb(72,69,80));c.drawRect(left+xx*sx,top+yy*sy,left+(xx+1)*sx+1,top+(yy+1)*sy+1,p);}
            }
            p.setColor(Color.rgb(255,176,186));for(Item a:acorns){float ax=left+(float)a.x*sx,ay=top+(float)a.y*sy;c.drawCircle(ax,ay,2.5f,p);}
            p.setColor(Color.rgb(220,120,70));for(Enemy e:enemies)if(e.alive){float ex=left+(float)e.x*sx,ey=top+(float)e.y*sy;c.drawCircle(ex,ey,2.5f,p);}
            p.setColor(Color.WHITE);float px=left+(float)playerX*sx,py=top+(float)playerY*sy;c.drawCircle(px,py,3.5f,p);
            p.setStrokeWidth(2);c.drawLine(px,py,px+(float)Math.cos(angle)*9,py+(float)Math.sin(angle)*9,p);
        }

        void drawToast(Canvas c,int w,int h){
            if(System.currentTimeMillis()>toastUntil)return;
            p.setColor(Color.argb(235,255,248,235));c.drawRoundRect(w*.18f,78,w*.82f,132,22,22,p);txtCenter(c,toast,w/2f,112,14,Color.rgb(55,43,47),true);postInvalidateDelayed(100);
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);int w=getWidth(),h=getHeight();
            if(w < h){ drawRotatePrompt(c,w,h); postInvalidateDelayed(250); return; }
            if(screen==0){drawTitle(c,w,h);return;}
            if(screen==2){drawLevelComplete(c,w,h);return;}
            if(screen==3||screen==4){drawEnd(c,w,h);return;}
            raycast(c,w,h);renderSprites(c,w,h);drawHud(c,w,h);drawToast(c,w,h);
            long now=System.nanoTime();float dt=Math.min(.05f,(now-lastFrame)/1_000_000_000f);lastFrame=now;update(dt);postInvalidateDelayed(16);
        }

        void drawTitle(Canvas c,int w,int h){
            p.setColor(Color.rgb(18,17,25));c.drawRect(0,0,w,h,p);
            // decorative corridor
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(78,66,88));
            c.drawRect(w*.12f,h*.16f,w*.88f,h*.82f,p);c.drawRect(w*.24f,h*.26f,w*.76f,h*.70f,p);p.setStyle(Paint.Style.FILL);
            txt(c,"ACORN HUNTER",w*.10f,h*.28f,34,Color.rgb(255,176,186),true);
            txt(c,"OPERATION «ЖЁЛУДЬ»",w*.10f,h*.36f,38,Color.WHITE,true);
            txt(c,"A tiny 90s-style raycasting nightmare",w*.10f,h*.43f,17,Color.LTGRAY,false);
            txt(c,"для человека, который слишком долго искал жёлуди.",w*.10f,h*.48f,16,Color.LTGRAY,false);
            p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.62f,w*.46f,h*.73f,28,28,p);txt(c,"НАЧАТЬ ОПЕРАЦИЮ",w*.16f,h*.687f,19,Color.rgb(35,28,35),true);
            txt(c,"WASD в сердце. Жёлуди в голове. Белки в прицеле.",w*.10f,h*.84f,13,Color.rgb(145,140,155),false);
        }

        void drawLevelComplete(Canvas c,int w,int h){
            p.setColor(Color.rgb(18,17,25));c.drawRect(0,0,w,h,p);
            txt(c,"LEVEL "+level+" COMPLETE",w*.10f,h*.30f,34,Color.rgb(255,205,120),true);
            txt(c,"Жёлуди собраны: "+found+" / "+acornGoal(),w*.10f,h*.39f,20,Color.WHITE,false);
            txt(c,level==1?"Это было подозрительно легко.":"Белки отступают, но это ещё не конец.",w*.10f,h*.46f,17,Color.LTGRAY,false);
            p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.60f,w*.46f,h*.71f,28,28,p);txt(c,"ИДТИ ДАЛЬШЕ",w*.18f,h*.667f,19,Color.rgb(35,28,35),true);
        }

        void drawEnd(Canvas c,int w,int h){
            p.setColor(Color.rgb(18,17,25));c.drawRect(0,0,w,h,p);
            if(screen==3){
                txt(c,"ОПЕРАЦИЯ ЗАВЕРШЕНА",w*.10f,h*.27f,32,Color.rgb(255,205,120),true);
                txt(c,"ОН СУЩЕСТВУЕТ.",w*.10f,h*.37f,42,Color.WHITE,true);
                txt(c,"Каролина нашла легендарный жёлудь.",w*.10f,h*.46f,19,Color.WHITE,false);
                txt(c,"Дарина может делать поделку.",w*.10f,h*.51f,19,Color.WHITE,false);
                txt(c,"Белки официально проиграли.",w*.10f,h*.56f,19,Color.rgb(255,176,186),true);
                txt(c,"P.S. Данил всё это время верил в тебя.",w*.10f,h*.65f,17,Color.LTGRAY,false);
            } else {
                txt(c,"ОПЕРАЦИЯ ПРОВАЛЕНА",w*.10f,h*.32f,34,Color.rgb(255,110,120),true);
                txt(c,"Белки оказались сильнее.",w*.10f,h*.41f,20,Color.WHITE,false);
                txt(c,"Но легенда о жёлуде ещё не закончена.",w*.10f,h*.47f,17,Color.LTGRAY,false);
            }
            p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.73f,w*.42f,h*.84f,28,28,p);txt(c,"НАЧАТЬ ЗАНОВО",w*.15f,h*.80f,17,Color.rgb(35,28,35),true);
        }

        void toggleMusic(){
            muted=!muted;if(host.music==null)return;
            if(muted&&host.music.isPlaying())host.music.pause();else if(!muted&&screen>0)host.music.start();
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            int action=e.getActionMasked();int idx=e.getActionIndex();float x=e.getX(idx),y=e.getY(idx);int w=getWidth(),h=getHeight();
            if(action==MotionEvent.ACTION_DOWN){
                if(screen==0){if(x>w*.07f&&x<w*.55f&&y>h*.56f&&y<h*.80f){begin();return true;}}
                if(screen==2){if(x>w*.07f&&x<w*.55f&&y>h*.55f){if(level<3){level++;loadLevel();}else screen=3;return true;}}
                if(screen==3||screen==4){if(x>w*.07f&&x<w*.48f&&y>h*.68f){begin();return true;}}
                if(screen==1){
                    if(x>w-80&&y<80){toggleMusic();return true;}
                    if(x>w*.70f&&y>h*.62f){firing=true;fireUntil=System.currentTimeMillis()+120;return true;}
                    if(x<w*.48f&&y>h*.58f){joystickActive=true;activePointer=e.getPointerId(idx);touchStartX=x;touchStartY=y;updateJoystick(x,y);return true;}
                }
            } else if(action==MotionEvent.ACTION_MOVE && screen==1){
                int pi=e.findPointerIndex(activePointer);if(joystickActive&&pi>=0){updateJoystick(e.getX(pi),e.getY(pi));return true;}
            } else if((action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL) && screen==1){
                if(e.getPointerId(idx)==activePointer){joystickActive=false;joystickX=joystickY=0;activePointer=-1;}
                return true;
            }
            return true;
        }
        void updateJoystick(float x,float y){
            float dx=(x-touchStartX)/70f,dy=(y-touchStartY)/70f;float len=(float)Math.hypot(dx,dy);if(len>1){dx/=len;dy/=len;}joystickX=dx;joystickY=dy;
        }
    }
}
