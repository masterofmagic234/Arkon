class_name TouchInputController
extends RefCounted

var joystick: Panel
var knob: Panel
var move_axis := Vector2.ZERO
var joystick_radius := 58.0
var joystick_touch_id := -1

func setup(p_joystick: Panel, p_knob: Panel, p_radius: float) -> void:
    joystick = p_joystick
    joystick_radius = p_radius
    knob = p_knob
    joystick.gui_input.connect(_on_joystick_gui_input)
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func get_move_axis() -> Vector2:
    return move_axis

func stop() -> void:
    move_axis = Vector2.ZERO
    _reset_joystick()

func _on_joystick_gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            joystick_touch_id = event.index
            _update_joystick(event.position)
            joystick.accept_event()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _update_joystick(event.position)
        joystick.accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            joystick_touch_id = -2
            _update_joystick(event.position)
            joystick.accept_event()
        elif joystick_touch_id == -2:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventMouseMotion and joystick_touch_id == -2:
        _update_joystick(event.position)
        joystick.accept_event()

func _update_joystick(position: Vector2) -> void:
    var center := joystick.size * 0.5
    var delta := position - center
    if delta.length() > joystick_radius:
        delta = delta.normalized() * joystick_radius
    move_axis = Vector2(delta.x / joystick_radius, delta.y / joystick_radius)
    knob.position = center - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5
