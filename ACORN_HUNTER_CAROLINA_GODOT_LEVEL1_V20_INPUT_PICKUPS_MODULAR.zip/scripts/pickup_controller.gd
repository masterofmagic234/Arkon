class_name PickupController
extends RefCounted

var acorns: Array[String] = []
var collected := 0
var fake_cone_found := false
var squirrel_names: Array[String] = []

func setup(initial_acorns: Array[String], initial_squirrels: Array[String]) -> void:
    acorns = initial_acorns.duplicate()
    squirrel_names = initial_squirrels.duplicate()

func collect_acorns(player: CharacterBody3D, owner: Node, pickup_radius: float, acorn_count: int, acorn_lines: Array[String], set_message: Callable, play_pickup: Callable, complete: Callable) -> void:
    for name in acorns.duplicate():
        var node := owner.get_node_or_null(name) as MeshInstance3D
        if node != null and player.global_position.distance_to(node.global_position) <= pickup_radius:
            node.visible = false
            acorns.erase(name)
            collected += 1
            play_pickup.call()
            set_message.call(acorn_lines.pick_random() + "\nЖёлуди: %d / %d" % [collected, acorn_count], 1.8)
            if collected == acorn_count:
                complete.call()

func check_fake_cone(player: CharacterBody3D, owner: Node, damage: int, cone_lines: Array[String], set_message: Callable, take_damage: Callable, play_damage: Callable, fail: Callable) -> bool:
    if fake_cone_found:
        return false
    var cone := owner.get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null and player.global_position.distance_to(cone.global_position) <= 1.2:
        fake_cone_found = true
        take_damage.call(damage)
        play_damage.call()
        set_message.call(cone_lines.pick_random(), 2.4)
        return true
    return false
