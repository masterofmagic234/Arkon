extends Node3D

# ACORN HUNTER — LEVEL 1
# Rebuilt from the last proven CLEAN/V6 control foundation.
# World sprites are deliberately MeshInstance3D + QuadMesh, not Sprite3D.
# UI owns touch input: joystick.gui_input + Fire.pressed.

const LevelData = preload("res://scripts/level_data.gd")
const HudView = preload("res://scripts/hud_view.gd")
const AudioController = preload("res://scripts/audio_controller.gd")
const MissionView = preload("res://scripts/mission_view.gd")
const CombatFeedbackView = preload("res://scripts/combat_feedback_view.gd")
const MessageView = preload("res://scripts/message_view.gd")
const MinimapView = preload("res://scripts/minimap_view.gd")
const NavigationController = preload("res://scripts/navigation_controller.gd")
const WorldQueries = preload("res://scripts/world_queries.gd")
const PlayerView = preload("res://scripts/player_view.gd")
const TouchInputController = preload("res://scripts/touch_input_controller.gd")
const PickupController = preload("res://scripts/pickup_controller.gd")

var move_axis := Vector2.ZERO
var collected := 0
var acorns: Array[String] = []
var ammo := LevelData.MAX_AMMO
var hp := LevelData.MAX_HP
var message_time := 0.0
var fire_cooldown := 0.0
var damage_cooldown := 0.0
var recoil_time := 0.0
var foot_timer := 0.0
var mission_complete := false
var mission_failed := false
var audio_controller: AudioController
var stunned: Dictionary = {}
var squirrel_hp := LevelData.SQUIRREL_HP.duplicate()
var squirrels := LevelData.SQUIRREL_NAMES.duplicate()
var squirrel_home := LevelData.SQUIRREL_HOME.duplicate()
var squirrel_phase := LevelData.SQUIRREL_PHASE.duplicate()
var hud_view: HudView
var mission_view: MissionView
var combat_feedback: CombatFeedbackView
var message_view: MessageView
var minimap_view: MinimapView
var navigation_controller: NavigationController
var player_view: PlayerView
var touch_input: TouchInputController
var pickup_controller: PickupController

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var joystick: Panel = $HUD/Joystick
@onready var knob: Panel = $HUD/Joystick/Knob
@onready var fire_button: Button = $HUD/Fire
@onready var mute_button: Button = $HUD/Mute
@onready var count_label: Label = $HUD/Count
@onready var hp_ammo_label: Label = $HUD/HPAmmo
@onready var message_label: Label = $HUD/Message
@onready var mission_panel: Panel = $HUD/Mission
@onready var mission_title: Label = $HUD/Mission/Title
@onready var mission_body: Label = $HUD/Mission/Body
@onready var weapon: TextureRect = $HUD/Weapon
@onready var muzzle: ColorRect = $HUD/MuzzleFlash
@onready var hit_marker: Label = $HUD/HitMarker
@onready var carolina: TextureRect = $HUD/Carolina
@onready var music: AudioStreamPlayer = $Music
@onready var fx: AudioStreamPlayer = $FX

func _ready() -> void:
    player_view = PlayerView.new()
    player_view.setup(camera, carolina)
    player_view.apply()
    mission_panel.visible = false
    muzzle.visible = false
    hit_marker.visible = false
    touch_input = TouchInputController.new()
    touch_input.setup(joystick, knob, LevelData.JOYSTICK_RADIUS)

    pickup_controller = PickupController.new()
    pickup_controller.setup(LevelData.ACORN_NAMES, LevelData.SQUIRREL_NAMES)
    acorns = pickup_controller.acorns
    fire_button.pressed.connect(_on_fire_pressed)
    mute_button.pressed.connect(_toggle_music)


    hud_view = HudView.new()
    hud_view.setup(count_label, hp_ammo_label)

    mission_view = MissionView.new()
    mission_view.setup(mission_panel, mission_title, mission_body, weapon)

    combat_feedback = CombatFeedbackView.new()
    combat_feedback.setup(weapon, muzzle, hit_marker)

    message_view = MessageView.new()
    message_view.setup(message_label)

    minimap_view = $HUD/Minimap as MinimapView

    navigation_controller = NavigationController.new()
    navigation_controller.setup($HUD/Mission/Menu, get_tree())

    audio_controller = AudioController.new()
    audio_controller.setup(music, fx)
    audio_controller.start_music()
    _update_hud()
    _set_message("Парк открыт. Дубы не прячутся — жёлуди тоже.", 4.0)
    _refresh_minimap()

func _physics_process(delta: float) -> void:
    if mission_complete or mission_failed:
        player.velocity = Vector3.ZERO
        return

    move_axis = touch_input.get_move_axis()
    var forward := -move_axis.y
    player.velocity = -player.global_transform.basis.z * (forward * LevelData.WALK_SPEED)
    player.velocity.y = 0.0
    player.move_and_slide()

    if abs(move_axis.x) > 0.04:
        player.rotate_y(-move_axis.x * LevelData.TURN_SPEED * delta)

    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    damage_cooldown = maxf(0.0, damage_cooldown - delta)
    recoil_time = maxf(0.0, recoil_time - delta)
    message_time = maxf(0.0, message_time - delta)

    if message_time <= 0.0:
        message_view.clear()
    if recoil_time <= 0.0:
        combat_feedback.set_idle_weapon()
    combat_feedback.update_muzzle(delta)

    if abs(forward) > 0.05:
        foot_timer -= delta
        if foot_timer <= 0.0:
            _footstep()
            foot_timer = 0.30
    else:
        foot_timer = 0.0

    _update_squirrels(delta)
    _collect_acorns()
    _check_fake_cone()
    _update_hud()
    _refresh_minimap()

func _on_fire_pressed() -> void:
    if mission_complete or mission_failed or fire_cooldown > 0.0:
        return
    if ammo <= 0:
        _set_message("Пусто. Даже белки в шоке.", 1.2)
        return

    ammo -= 1
    fire_cooldown = 0.18
    recoil_time = 0.10
    combat_feedback.recoil()
    combat_feedback.show_muzzle()
    audio_controller.play_fx(audio_controller.shoot_stream)

    var query := PhysicsRayQueryParameters3D.create(
        camera.global_position,
        camera.global_position + (-camera.global_transform.basis.z * LevelData.FIRE_RANGE),
        LevelData.SQUIRREL_LAYER | LevelData.WORLD_LAYER
    )
    query.collide_with_areas = true
    query.collide_with_bodies = true
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        _miss()
        return

    var squirrel := WorldQueries.find_squirrel_from_collider(hit.get("collider"), squirrels)
    if squirrel == "" or stunned.has(squirrel):
        _miss()
        return

    squirrel_hp[squirrel] = int(squirrel_hp.get(squirrel, 2)) - 1
    var target := get_node_or_null(squirrel) as MeshInstance3D
    audio_controller.play_fx(audio_controller.squirrel_hit_stream)
    combat_feedback.show_hit()
    if int(squirrel_hp[squirrel]) <= 0:
        stunned[squirrel] = true
        if target != null:
            var stunned_texture := load("res://assets/squirrel_stunned.png")
            if stunned_texture != null and target.mesh is QuadMesh:
                var base_mat := (target.mesh as QuadMesh).material as StandardMaterial3D
                if base_mat != null:
                    var unique_mat := base_mat.duplicate() as StandardMaterial3D
                    unique_mat.albedo_texture = stunned_texture
                    target.set_surface_override_material(0, unique_mat)
            target.rotation.z = deg_to_rad(-7.0)
            target.scale = Vector3(1.0, 0.78, 1.0)
        _set_message(LevelData.STUN_LINES.pick_random(), 2.0)
    else:
        _set_message(LevelData.HIT_LINES.pick_random() + "\nЕщё один раз — и белка отдыхает.", 1.4)
    await get_tree().create_timer(0.35).timeout
    if not mission_complete and not mission_failed:
        combat_feedback.hide_hit()

func _miss() -> void:
    combat_feedback.show_miss()
    _set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await get_tree().create_timer(0.22).timeout
    if not mission_complete and not mission_failed:
        combat_feedback.hide_hit()

func _update_squirrels(delta: float) -> void:
    var player_pos := Vector2(player.global_position.x, player.global_position.z)
    for name in squirrels:
        if stunned.has(name):
            continue
        var node := get_node_or_null(name) as MeshInstance3D
        if node == null:
            continue
        var home: Vector2 = squirrel_home[name]
        var dist := home.distance_to(player_pos)
        if dist < 6.0 and dist > 1.8:
            var away := (home - player_pos).normalized()
            var proposed := home + away * delta * 0.45
            if not WorldQueries.is_wall(proposed.x, proposed.y, LevelData.CELL_SIZE, LevelData.MAP_WIDTH, LevelData.MAP_HEIGHT, LevelData.CANONICAL_MAP):
                squirrel_home[name] = proposed
                node.position.x = proposed.x
                node.position.z = proposed.y
        node.rotation.z = sin(Time.get_ticks_msec() * 0.003 + float(squirrel_phase[name])) * 0.03
        if dist < 1.0 and damage_cooldown <= 0.0:
            damage_cooldown = 0.8
            hp = max(0, hp - 12)
            audio_controller.play_fx(audio_controller.damage_stream)
            _set_message(LevelData.DAMAGE_LINES.pick_random(), 1.2)
            if hp <= 0:
                _fail()

func _collect_acorns() -> void:
    pickup_controller.collect_acorns(
        player, self, LevelData.ACORN_PICKUP_RADIUS, LevelData.ACORN_COUNT,
        LevelData.ACORN_LINES, Callable(self, "_set_message"),
        Callable(self, "_play_pickup"), Callable(self, "_complete")
    )
    collected = pickup_controller.collected

func _check_fake_cone() -> void:
    pickup_controller.check_fake_cone(
        player, self, 12, LevelData.CONE_LINES,
        Callable(self, "_set_message"), Callable(self, "_take_damage"),
        Callable(self, "_play_damage"), Callable(self, "_fail")
    )

func _play_pickup() -> void:
    if audio_controller.pickup_stream != null:
        audio_controller.play_fx(audio_controller.pickup_stream)

func _play_damage() -> void:
    if audio_controller.damage_stream != null:
        audio_controller.play_fx(audio_controller.damage_stream)

func _take_damage(amount: int) -> void:
    hp = max(0, hp - amount)
    if hp <= 0:
        _fail()

func _complete() -> void:
    mission_complete = true
    touch_input.stop()
    move_axis = Vector2.ZERO
    mission_view.show_complete(LevelData.ACORN_COUNT)

func _fail() -> void:
    mission_failed = true
    touch_input.stop()
    move_axis = Vector2.ZERO
    mission_view.show_failed()

func _update_hud() -> void:
    hud_view.update_status(collected, LevelData.ACORN_COUNT, hp, ammo)

func _set_message(text: String, duration: float) -> void:
    message_view.set_text(text)
    message_time = duration

func _footstep() -> void:
    audio_controller.footstep()

func _toggle_music() -> void:
    var is_muted := audio_controller.toggle_music()
    mute_button.text = "×" if is_muted else "♪"
    _set_message("Музыка выключена." if is_muted else "Музыка возвращена. Белки снова слышат угрозу.", 1.6)

func _face_world_sprites() -> void:
    # Billboard materials handle camera-facing orientation.
    pass

func _refresh_minimap() -> void:
    minimap_view.set_game_state(player.global_position, player.rotation.y, acorns, squirrels, stunned)

