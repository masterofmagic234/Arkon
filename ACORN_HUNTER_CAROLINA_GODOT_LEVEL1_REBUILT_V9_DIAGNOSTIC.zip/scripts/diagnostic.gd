extends Node3D

# ACORN HUNTER — START INPUT DIAGNOSTIC
# This build intentionally does NOT enter gameplay. It maps every stage of
# the Android/GUI input path so the exact break point can be seen on-device.

@onready var title_layer: Control = $UI/Interface/TitleLayer
@onready var start_button: Button = $UI/Interface/TitleLayer/StartButton
@onready var start_touch: TouchScreenButton = $UI/Interface/TitleLayer/StartTouch
@onready var status: Label = $UI/Interface/TitleLayer/DiagnosticStatus
@onready var chain: Label = $UI/Interface/TitleLayer/DiagnosticChain
@onready var marker: ColorRect = $UI/Interface/TitleLayer/DiagnosticMarker

var counts := {
    "boot": 0,
    "screen_touch": 0,
    "screen_drag": 0,
    "mouse_button": 0,
    "gui_input": 0,
    "button_down": 0,
    "button_pressed": 0,
    "touch_pressed": 0,
    "unhandled": 0,
}

func _ready() -> void:
    counts["boot"] = 1
    start_button.gui_input.connect(_on_start_gui_input)
    start_button.button_down.connect(_on_button_down)
    start_button.pressed.connect(_on_button_pressed)
    start_touch.pressed.connect(_on_touch_pressed)
    start_touch.released.connect(_on_touch_released)
    _refresh("BOOT OK. Tap НАЧАТЬ ОПЕРАЦИЮ.")

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        counts["screen_touch"] += 1
        _refresh("RAW SCREEN TOUCH: %s id=%d pos=%s" % ["DOWN" if event.pressed else "UP", event.index, event.position])
    elif event is InputEventScreenDrag:
        counts["screen_drag"] += 1
        _refresh("RAW SCREEN DRAG id=%d pos=%s" % [event.index, event.position])
    elif event is InputEventMouseButton:
        counts["mouse_button"] += 1
        _refresh("MOUSE BUTTON: %s pos=%s" % ["DOWN" if event.pressed else "UP", event.position])

func _unhandled_input(event: InputEvent) -> void:
    counts["unhandled"] += 1
    _refresh("UNHANDLED INPUT: %s" % event.get_class())

func _on_start_gui_input(event: InputEvent) -> void:
    counts["gui_input"] += 1
    if event is InputEventMouseButton:
        _refresh("GUI INPUT: mouse %s" % ["DOWN" if event.pressed else "UP"])
    elif event is InputEventScreenTouch:
        _refresh("GUI INPUT: screen touch %s" % ["DOWN" if event.pressed else "UP"])
    else:
        _refresh("GUI INPUT: %s" % event.get_class())

func _on_button_down() -> void:
    counts["button_down"] += 1
    _mark_success("BUTTON_DOWN FIRED")

func _on_button_pressed() -> void:
    counts["button_pressed"] += 1
    _mark_success("BUTTON.PRESSED FIRED")

func _on_touch_pressed() -> void:
    counts["touch_pressed"] += 1
    _mark_success("TOUCHSCREENBUTTON.PRESSED FIRED")

func _on_touch_released() -> void:
    _refresh("TOUCHSCREENBUTTON.RELEASED FIRED")

func _mark_success(message: String) -> void:
    marker.color = Color(0.08, 0.65, 0.18, 0.88)
    _refresh("SUCCESS: " + message)
    await get_tree().create_timer(0.25).timeout
    marker.color = Color(0.08, 0.12, 0.10, 0.88)

func _refresh(message: String) -> void:
    status.text = message
    chain.text = "RAW TOUCH %d | RAW MOUSE %d | GUI %d | DOWN %d | PRESSED %d | TOUCHBTN %d | UNHANDLED %d" % [
        counts["screen_touch"], counts["mouse_button"], counts["gui_input"],
        counts["button_down"], counts["button_pressed"], counts["touch_pressed"],
        counts["unhandled"]
    ]
