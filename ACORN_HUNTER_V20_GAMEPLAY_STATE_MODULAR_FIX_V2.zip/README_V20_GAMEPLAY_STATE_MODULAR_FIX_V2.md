# ACORN HUNTER — V20 GAMEPLAY STATE MODULAR FIX V2

Base: V20 SQUIRREL ATTACK QUERY FIX, with SceneLookup already integrated.

The previous custom RefCounted GameState instance has been removed from runtime state storage. Gameplay state is now a built-in Dictionary produced by a minimal factory script. This avoids custom instance member typing and per-member initializers in the new module.

Preserved: proven touch input, spawn, sky, scene, assets, gameplay rules, SceneLookup, and SquirrelAttackQuery.
