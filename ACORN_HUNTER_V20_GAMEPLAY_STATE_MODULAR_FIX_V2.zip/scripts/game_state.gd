extends RefCounted

# Minimal state factory. Returns built-in Dictionary data only.
# No custom instance members or scene dependencies.
static func create(level_data) -> Dictionary:
    return {
        "move_axis": Vector2.ZERO,
        "joystick_touch_id": -1,
        "collected": 0,
        "ammo": level_data.MAX_AMMO,
        "hp": level_data.MAX_HP,
        "message_time": 0.0,
        "fire_cooldown": 0.0,
        "damage_cooldown": 0.0,
        "recoil_time": 0.0,
        "foot_timer": 0.0,
        "fake_cone_found": false,
        "mission_complete": false,
        "mission_failed": false,
        "stunned": {},
        "squirrel_hp": level_data.SQUIRREL_HP.duplicate(),
        "acorns": level_data.ACORN_NAMES.duplicate(),
        "squirrels": level_data.SQUIRREL_NAMES.duplicate(),
        "squirrel_home": level_data.SQUIRREL_HOME.duplicate(),
        "squirrel_phase": level_data.SQUIRREL_PHASE.duplicate()
    }
