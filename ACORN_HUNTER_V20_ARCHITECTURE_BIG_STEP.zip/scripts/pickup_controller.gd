extends RefCounted

# Owns acorn and fake-cone pickup/objective interactions.
const LevelData = preload("res://scripts/level_data.gd")
const PickupQuery = preload("res://scripts/pickup_query.gd")
const ConeQuery = preload("res://scripts/cone_query.gd")
const MissionProgressQuery = preload("res://scripts/mission_progress_query.gd")
const DeathQuery = preload("res://scripts/death_query.gd")
const HealthMath = preload("res://scripts/health_math.gd")
const SceneLookup = preload("res://scripts/scene_lookup.gd")

var root
var player
var game_state
var world_sprite_view
var audio_controller
var message_view
var on_complete: Callable
var on_fail: Callable

func setup(root_node, player_node, state, world_sprites, audio, messages, complete_callback: Callable, fail_callback: Callable) -> void:
    root = root_node
    player = player_node
    game_state = state
    world_sprite_view = world_sprites
    audio_controller = audio
    message_view = messages
    on_complete = complete_callback
    on_fail = fail_callback

func update() -> void:
    collect_acorns()
    check_fake_cone()

func collect_acorns() -> void:
    for name in game_state.acorns.duplicate():
        var node = SceneLookup.mesh_node(root, name)
        if node != null and PickupQuery.is_in_range(player.global_position, node.global_position, LevelData.ACORN_PICKUP_RADIUS):
            world_sprite_view.hide_pickup(node)
            game_state.acorns.erase(name)
            game_state.collected += 1
            if audio_controller.pickup_stream != null:
                audio_controller.play_fx(audio_controller.pickup_stream)
            message_view.set_text(LevelData.ACORN_LINES.pick_random() + "\nЖёлуди: %d / %d" % [game_state.collected, LevelData.ACORN_COUNT])
            game_state.message_time = 1.8
            if MissionProgressQuery.is_complete(game_state.collected, LevelData.ACORN_COUNT):
                on_complete.call()

func check_fake_cone() -> void:
    if game_state.fake_cone_found:
        return
    var cone := root.get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null and ConeQuery.is_in_range(player.global_position, cone.global_position):
        game_state.fake_cone_found = true
        game_state.hp = HealthMath.apply_damage(game_state.hp, 12)
        if audio_controller.damage_stream != null:
            audio_controller.play_fx(audio_controller.damage_stream)
        message_view.set_text(LevelData.CONE_LINES.pick_random())
        game_state.message_time = 2.4
        if DeathQuery.is_dead(game_state.hp):
            on_fail.call()
