extends RefCounted

# Coordinates combat and delegates enemy/pickup systems to dedicated controllers.
const LevelData = preload("res://scripts/level_data.gd")
const CombatQuery = preload("res://scripts/combat_query.gd")
const WorldQueries = preload("res://scripts/world_queries.gd")
const WorldSpriteView = preload("res://scripts/world_sprite_view.gd")
const HealthMath = preload("res://scripts/health_math.gd")
const AmmoMath = preload("res://scripts/ammo_math.gd")
const FireQuery = preload("res://scripts/fire_query.gd")
const MissionStateQuery = preload("res://scripts/mission_state_query.gd")
const DeathQuery = preload("res://scripts/death_query.gd")
const SceneLookup = preload("res://scripts/scene_lookup.gd")
const EnemyController = preload("res://scripts/enemy_controller.gd")
const PickupController = preload("res://scripts/pickup_controller.gd")

var root
var player
var camera
var game_state
var world_sprite_view
var combat_feedback
var audio_controller
var message_view
var mission_view
var enemy_controller
var pickup_controller
var on_mission_end: Callable

func setup(root_node, player_node, camera_node, state, world_sprites, feedback, audio, messages, mission, mission_end_callback: Callable) -> void:
    root = root_node
    player = player_node
    camera = camera_node
    game_state = state
    world_sprite_view = world_sprites
    combat_feedback = feedback
    audio_controller = audio
    message_view = messages
    mission_view = mission
    on_mission_end = mission_end_callback
    enemy_controller = EnemyController.new()
    enemy_controller.setup(root, player, game_state, world_sprite_view, audio_controller, message_view, Callable(self, "fail"))
    pickup_controller = PickupController.new()
    pickup_controller.setup(root, player, game_state, world_sprite_view, audio_controller, message_view, Callable(self, "complete"), Callable(self, "fail"))

func handle_fire() -> void:
    if not FireQuery.can_fire(game_state.mission_complete, game_state.mission_failed, game_state.fire_cooldown, game_state.ammo):
        if game_state.ammo <= 0 and not MissionStateQuery.is_finished(game_state.mission_complete, game_state.mission_failed) and game_state.fire_cooldown <= 0.0:
            set_message("Пусто. Даже белки в шоке.", 1.2)
        return
    game_state.ammo = AmmoMath.consume_one(game_state.ammo)
    game_state.fire_cooldown = 0.18
    game_state.recoil_time = 0.10
    combat_feedback.recoil()
    combat_feedback.show_muzzle()
    audio_controller.play_fx(audio_controller.shoot_stream)
    var hit := CombatQuery.raycast(root.get_world_3d(), camera)
    if hit.is_empty():
        miss()
        return
    var squirrel := WorldQueries.find_squirrel_from_collider(hit.get("collider"), game_state.squirrels)
    if squirrel == "" or game_state.stunned.has(squirrel):
        miss()
        return
    game_state.squirrel_hp[squirrel] = HealthMath.apply_damage(int(game_state.squirrel_hp.get(squirrel, 2)), 1)
    var target = SceneLookup.mesh_node(root, squirrel)
    audio_controller.play_fx(audio_controller.squirrel_hit_stream)
    combat_feedback.show_hit()
    if int(game_state.squirrel_hp[squirrel]) <= 0:
        game_state.stunned[squirrel] = true
        if target != null:
            world_sprite_view.apply_squirrel_stunned(target)
        set_message(LevelData.STUN_LINES.pick_random(), 2.0)
    else:
        set_message(LevelData.HIT_LINES.pick_random() + "\nЕщё один раз — и белка отдыхает.", 1.4)
    await root.get_tree().create_timer(0.35).timeout
    if MissionStateQuery.is_active(game_state.mission_complete, game_state.mission_failed):
        combat_feedback.hide_hit()

func miss() -> void:
    combat_feedback.show_miss()
    set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await root.get_tree().create_timer(0.22).timeout
    if MissionStateQuery.is_active(game_state.mission_complete, game_state.mission_failed):
        combat_feedback.hide_hit()

func update(delta: float) -> void:
    enemy_controller.update(delta)
    pickup_controller.update()

func complete() -> void:
    if game_state.mission_complete or game_state.mission_failed:
        return
    game_state.mission_complete = true
    if on_mission_end.is_valid():
        on_mission_end.call()
    mission_view.show_complete(LevelData.ACORN_COUNT)

func fail() -> void:
    if game_state.mission_complete or game_state.mission_failed:
        return
    game_state.mission_failed = true
    if on_mission_end.is_valid():
        on_mission_end.call()
    mission_view.show_failed()

func set_message(text: String, duration: float) -> void:
    message_view.set_text(text)
    game_state.message_time = duration
