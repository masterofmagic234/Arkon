extends RefCounted

# Owns player movement, look, joystick state and player-only movement feedback.
const LevelData = preload("res://scripts/level_data.gd")
const MovementMath = preload("res://scripts/movement_math.gd")
const TurnMath = preload("res://scripts/turn_math.gd")
const JoystickMath = preload("res://scripts/joystick_math.gd")

var player
var camera
var joystick
var knob
var game_state
var audio_controller
var move_axis := Vector2.ZERO
var joystick_touch_id := -1

func setup(player_node, camera_node, joystick_node, knob_node, state, audio) -> void:
    player = player_node
    camera = camera_node
    joystick = joystick_node
    knob = knob_node
    game_state = state
    audio_controller = audio

func physics_step(delta: float) -> void:
    if game_state.mission_complete or game_state.mission_failed:
        player.velocity = Vector3.ZERO
        return
    var forward := -move_axis.y
    player.velocity = MovementMath.velocity_for_input(player.global_transform.basis, move_axis, LevelData.WALK_SPEED)
    player.move_and_slide()
    if abs(move_axis.x) > 0.04:
        player.rotate_y(TurnMath.turn_amount(move_axis.x, LevelData.TURN_SPEED, delta))
    if abs(forward) > 0.05:
        game_state.foot_timer -= delta
        if game_state.foot_timer <= 0.0:
            audio_controller.footstep()
            game_state.foot_timer = 0.30
    else:
        game_state.foot_timer = 0.0

func handle_joystick_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            joystick_touch_id = event.index
            update_joystick(event.position)
            joystick.accept_event()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            reset_joystick()
            joystick.accept_event()
    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        update_joystick(event.position)
        joystick.accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            joystick_touch_id = -2
            update_joystick(event.position)
            joystick.accept_event()
        elif joystick_touch_id == -2:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            reset_joystick()
            joystick.accept_event()
    elif event is InputEventMouseMotion and joystick_touch_id == -2:
        update_joystick(event.position)
        joystick.accept_event()

func reset_after_mission() -> void:
    move_axis = Vector2.ZERO
    reset_joystick()

func update_joystick(position: Vector2) -> void:
    var center := joystick.size * 0.5
    var delta := JoystickMath.clamped_delta(position, center, LevelData.JOYSTICK_RADIUS)
    move_axis = JoystickMath.axis_from_delta(delta, LevelData.JOYSTICK_RADIUS)
    knob.position = center - knob.size * 0.5 + delta

func reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5
