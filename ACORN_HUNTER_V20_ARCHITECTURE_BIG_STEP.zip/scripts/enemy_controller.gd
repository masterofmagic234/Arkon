extends RefCounted

# Owns squirrel AI, movement, attack and damage state changes.
const LevelData = preload("res://scripts/level_data.gd")
const WorldCollision = preload("res://scripts/world_collision.gd")
const WorldSpriteView = preload("res://scripts/world_sprite_view.gd")
const SquirrelMotionMath = preload("res://scripts/squirrel_motion_math.gd")
const SquirrelQuery = preload("res://scripts/squirrel_query.gd")
const SquirrelAttackQuery = preload("res://scripts/squirrel_attack_query.gd")
const HealthMath = preload("res://scripts/health_math.gd")
const DeathQuery = preload("res://scripts/death_query.gd")
const SceneLookup = preload("res://scripts/scene_lookup.gd")

var root
var player
var game_state
var world_sprite_view
var audio_controller
var message_view
var on_fail: Callable

func setup(root_node, player_node, state, world_sprites, audio, messages, fail_callback: Callable) -> void:
    root = root_node
    player = player_node
    game_state = state
    world_sprite_view = world_sprites
    audio_controller = audio
    message_view = messages
    on_fail = fail_callback

func update(delta: float) -> void:
    var player_pos := Vector2(player.global_position.x, player.global_position.z)
    for name in game_state.squirrels:
        if game_state.stunned.has(name):
            continue
        var node = SceneLookup.mesh_node(root, name)
        if node == null:
            continue
        var home: Vector2 = game_state.squirrel_home[name]
        var dist := home.distance_to(player_pos)
        if SquirrelQuery.should_chase(dist):
            var proposed := SquirrelMotionMath.proposed_position(home, player_pos, delta, 0.45)
            if not WorldCollision.is_wall(proposed.x, proposed.y):
                game_state.squirrel_home[name] = proposed
                node.position.x = proposed.x
                node.position.z = proposed.y
        world_sprite_view.animate_squirrel(node, float(game_state.squirrel_phase[name]))
        if SquirrelAttackQuery.can_attack(dist, game_state.damage_cooldown, LevelData.SQUIRREL_ATTACK_DISTANCE):
            game_state.damage_cooldown = 0.8
            game_state.hp = HealthMath.apply_damage(game_state.hp, 12)
            audio_controller.play_fx(audio_controller.damage_stream)
            message_view.set_text(LevelData.DAMAGE_LINES.pick_random())
            game_state.message_time = 1.2
            if DeathQuery.is_dead(game_state.hp):
                on_fail.call()
