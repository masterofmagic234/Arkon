extends Node3D

const ACORN_POSITIONS := [
    Vector3(-4.5, 0.25, -2.5),
    Vector3(0.5, 0.25, -4.0),
    Vector3(4.0, 0.25, 0.5),
    Vector3(1.5, 0.25, 4.0)
]

const TREE_POSITIONS := [
    Vector3(-5.0, 1.0, -4.0),
    Vector3(3.5, 1.0, -4.5),
    Vector3(5.0, 1.0, 3.0),
    Vector3(-4.5, 1.0, 4.0),
    Vector3(0.0, 1.0, 5.0)
]

var acorn_texture: Texture2D = preload("res://assets/acorn.png")
var tree_texture: Texture2D = preload("res://assets/oak_tree.png")
var squirrel_texture: Texture2D = preload("res://assets/squirrel.png")
var moon_texture: Texture2D = preload("res://assets/moon.png")
var star_texture: Texture2D = preload("res://assets/star.png")
var ground_texture: Texture2D = preload("res://assets/grass.png")

func _ready() -> void:
    _build_world()

func _build_world() -> void:
    _add_environment()
    _add_ground()
    _add_walls()
    for position in TREE_POSITIONS:
        _add_billboard(tree_texture, position, 1.7, 0.0)
    for position in ACORN_POSITIONS:
        _add_billboard(acorn_texture, position, 0.45, 0.0)
    _add_billboard(squirrel_texture, Vector3(-1.5, 0.55, 1.5), 1.0, 0.0)
    _add_sky_objects()

func _add_environment() -> void:
    var environment := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_material := ProceduralSkyMaterial.new()
    sky_material.sky_top_color = Color("07112e")
    sky_material.sky_horizon_color = Color("26344f")
    sky_material.ground_horizon_color = Color("182231")
    sky_material.ground_bottom_color = Color("05090f")
    sky.sky_material = sky_material
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.7
    environment.environment = env
    add_child(environment)

    var moon_light := DirectionalLight3D.new()
    moon_light.rotation_degrees = Vector3(-50.0, -25.0, 0.0)
    moon_light.light_color = Color("9aaee8")
    moon_light.light_energy = 0.8
    moon_light.shadow_enabled = true
    add_child(moon_light)

func _add_ground() -> void:
    var mesh := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(20.0, 14.0)
    var material := StandardMaterial3D.new()
    material.albedo_texture = ground_texture
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    plane.material = material
    mesh.mesh = plane
    mesh.position = Vector3(0.0, 0.0, 0.0)
    add_child(mesh)

func _add_walls() -> void:
    for x in [-10.0, 10.0]:
        _add_wall(Vector3(x, 1.0, 0.0), Vector3(0.5, 2.0, 14.0))
    for z in [-7.0, 7.0]:
        _add_wall(Vector3(0.0, 1.0, z), Vector3(20.0, 2.0, 0.5))

func _add_wall(position: Vector3, size: Vector3) -> void:
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    var material := StandardMaterial3D.new()
    material.albedo_color = Color("26352c")
    box.material = material
    mesh.mesh = box
    mesh.position = position
    add_child(mesh)

func _add_billboard(texture: Texture2D, position: Vector3, scale_value: float, y_offset: float) -> void:
    var sprite := Sprite3D.new()
    sprite.texture = texture
    sprite.pixel_size = 0.01
    sprite.position = position + Vector3(0.0, y_offset, 0.0)
    sprite.scale = Vector3.ONE * scale_value
    sprite.material_override = _sprite_material()
    add_child(sprite)

func _sprite_material() -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    material.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    return material

func _add_sky_objects() -> void:
    var moon := Sprite3D.new()
    moon.texture = moon_texture
    moon.pixel_size = 0.003
    moon.position = Vector3(-4.0, 5.2, -5.0)
    moon.material_override = _sprite_material()
    add_child(moon)

    var rng := RandomNumberGenerator.new()
    rng.seed = 1777
    for index in range(40):
        var star := Sprite3D.new()
        star.texture = star_texture
        star.pixel_size = rng.randf_range(0.0015, 0.003)
        star.position = Vector3(rng.randf_range(-9.0, 9.0), rng.randf_range(3.0, 7.0), rng.randf_range(-6.0, -2.0))
        star.material_override = _sprite_material()
        add_child(star)

func _on_back_pressed() -> void:
    get_tree().change_scene_to_file("res://menu.tscn")
