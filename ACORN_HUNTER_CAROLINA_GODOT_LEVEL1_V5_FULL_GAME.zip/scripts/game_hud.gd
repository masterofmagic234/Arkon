extends Control

var hp:=100
var ammo:=35
var found:=0
var goal:=4
var face:Texture2D
var map_data=[]
var player_pos:=Vector2.ZERO
var player_yaw:=0.0
var weapon_recoil:=0.0
var toast_text:=""
var toast_alpha:=0.0

func _ready()->void:
    mouse_filter=Control.MOUSE_FILTER_IGNORE
    _resize()
    queue_redraw()

func _notification(what:int)->void:
    if what==NOTIFICATION_RESIZED: _resize()

func _resize()->void:
    position=Vector2.ZERO
    size=get_viewport_rect().size

func set_state(p_hp:int,p_ammo:int,p_found:int,p_goal:int,p_pos:Vector2,p_yaw:float,recoil:float,msg:String,alpha:float)->void:
    hp=p_hp; ammo=p_ammo; found=p_found; goal=p_goal; player_pos=p_pos; player_yaw=p_yaw; weapon_recoil=recoil; toast_text=msg; toast_alpha=alpha
    queue_redraw()

func _draw()->void:
    var s:=size
    # top HUD
    draw_rect(Rect2(0,0,s.x,68),Color(0.018,0.055,0.050,0.96))
    draw_line(Vector2(0,68),Vector2(s.x,68),Color(0.30,0.65,0.50,0.45),2)
    var f:=ThemeDB.fallback_font
    draw_string(f,Vector2(18,27),"ОПЕРАЦИЯ «ЖЁЛУДЬ»",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color(0.95,0.97,0.92,1))
    draw_string(f,Vector2(18,50),"УР. 1   ЖЁЛУДИ %d/%d"%[found,goal],HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color(0.70,0.88,0.76,1))

    # center profile card
    var cx:=s.x*0.58
    draw_circle(Vector2(cx,34),28,Color(0.04,0.07,0.07,1))
    if face:
        draw_texture_rect(face,Rect2(cx-23,11,46,46),false)
    draw_string(f,Vector2(cx+36,27),"CAROLINA",HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color(0.96,0.96,0.92,1))
    draw_string(f,Vector2(cx+36,47),"ОХОТНИК",HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color(0.62,0.72,0.68,1))

    # right stats
    draw_string(f,Vector2(s.x-235,27),"HP %03d"%hp,HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color(0.98,0.96,0.90,1))
    draw_string(f,Vector2(s.x-235,49),"AMMO %02d"%ammo,HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color(0.82,0.86,0.84,1))

    # minimap
    _draw_minimap(s)

    # crosshair
    var c:=Vector2(s.x*0.5,s.y*0.5)
    draw_line(c-Vector2(8,0),c+Vector2(8,0),Color(1,1,1,0.82),2)
    draw_line(c-Vector2(0,8),c+Vector2(0,8),Color(1,1,1,0.82),2)

    # weapon overlay: intentionally flat/clean, always centered and independent of camera pitch
    _draw_weapon(s)

    if toast_alpha>0.01 and toast_text!="":
        var box:=Rect2(s.x*0.28,s.y*0.72,s.x*0.44,48)
        draw_rect(box,Color(0.01,0.025,0.025,0.88*toast_alpha),true)
        draw_string(f,Vector2(box.position.x,box.position.y+31),toast_text,HORIZONTAL_ALIGNMENT_CENTER,box.size.x,17,Color(0.94,0.98,0.90,toast_alpha))

func _draw_weapon(s:Vector2)->void:
    var cx:=s.x*0.5
    var base:=s.y+weapon_recoil*18.0
    # dark body / receiver
    var pts=PackedVector2Array([
        Vector2(cx-82,base-7),Vector2(cx-58,base-104),Vector2(cx-26,base-132),
        Vector2(cx+26,base-132),Vector2(cx+58,base-104),Vector2(cx+82,base-7)
    ])
    draw_colored_polygon(pts,Color(0.055,0.050,0.065,1))
    draw_rect(Rect2(cx-22,base-126,44,100),Color(0.17,0.16,0.19,1),true)
    draw_rect(Rect2(cx-8,base-174,16,56),Color(0.10,0.10,0.12,1),true)
    draw_rect(Rect2(cx-6,base-182,12,11),Color(0.58,0.62,0.66,1),true)
    draw_rect(Rect2(cx-43,base-94,86,14),Color(0.26,0.24,0.25,1),true)
    if weapon_recoil>0.05:
        draw_circle(Vector2(cx,base-190),18,Color(1.0,0.72,0.20,0.28))
        draw_circle(Vector2(cx,base-190),8,Color(1.0,0.93,0.55,0.85))

func _draw_minimap(s:Vector2)->void:
    var f:=ThemeDB.fallback_font
    var w:=220.0
    var h:=154.0
    var origin:=Vector2(s.x-w-22,82)
    draw_rect(Rect2(origin-Vector2(6,6),Vector2(w+12,h+12)),Color(0.015,0.035,0.032,0.94),true)
    draw_rect(Rect2(origin-Vector2(6,6),Vector2(w+12,h+12)),Color(0.35,0.65,0.46,0.45),false,2)
    var cw:=w/20.0
    var ch:=h/14.0
    for y in range(14):
        for x in range(20):
            var r:=Rect2(origin+Vector2(x*cw,y*ch),Vector2(cw+0.4,ch+0.4))
            if map_data.size()>y and map_data[y][x]==1:
                draw_rect(r,Color(0.15,0.25,0.20,1),true)
            else:
                draw_rect(r,Color(0.035,0.075,0.060,1),true)
    # objective markers: map cells are known from game
    var objectives=[Vector2(5.5,2.5),Vector2(10.5,2.5),Vector2(14.5,3.5),Vector2(13.5,7.5)]
    for p in objectives:
        var q:=origin+Vector2(p.x/20.0*w,p.y/14.0*h)
        draw_circle(q,4,Color(0.92,0.68,0.22,0.95))
    var pp:=origin+Vector2(player_pos.x/20.0*w,player_pos.y/14.0*h)
    draw_circle(pp,5,Color(0.95,0.55,0.58,1))
    var dir:=Vector2(-sin(player_yaw),-cos(player_yaw))*10.0
    draw_line(pp,pp+dir,Color(1,1,1,0.95),2)
    draw_string(f,origin+Vector2(8,16),"MAP",HORIZONTAL_ALIGNMENT_LEFT,-1,11,Color(0.76,0.86,0.80,0.9))
