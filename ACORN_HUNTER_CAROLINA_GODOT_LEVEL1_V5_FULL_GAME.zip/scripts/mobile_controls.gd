extends Control
signal move_changed(v: Vector2)
signal look_changed(v: Vector2)
signal fire_pressed

var joy_center:=Vector2.ZERO
var joy_touch:=-1
var look_touch:=-1
var fire_touch:=-1
var joy_radius:=78.0
var joy_knob:=Vector2.ZERO
var fire_rect:=Rect2()
var last_look:=Vector2.ZERO

func _ready()->void:
    mouse_filter=Control.MOUSE_FILTER_STOP
    set_process_input(true)
    _resize_to_viewport()
    queue_redraw()

func _notification(what:int)->void:
    if what==NOTIFICATION_RESIZED:
        _resize_to_viewport()
        queue_redraw()

func _resize_to_viewport()->void:
    var vp:=get_viewport_rect().size
    position=Vector2.ZERO
    size=vp

func _draw()->void:
    if not visible: return
    var s:=size
    joy_center=Vector2(125.0,s.y-105.0)
    fire_rect=Rect2(s.x-170.0,s.y-180.0,130.0,130.0)
    draw_circle(joy_center,joy_radius,Color(0.75,0.82,0.82,0.16))
    draw_circle(joy_center+joy_knob,31.0,Color(0.95,0.55,0.58,0.82))
    draw_circle(fire_rect.position+fire_rect.size/2.0,56.0,Color(0.95,0.55,0.58,0.82))
    var f:=ThemeDB.fallback_font
    draw_string(f,fire_rect.position+Vector2(25,48),"АТАКА",HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color(0.12,0.08,0.09,1))
    draw_string(f,fire_rect.position+Vector2(32,68),"FIRE",HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color(0.12,0.08,0.09,0.75))

func _input(event:InputEvent)->void:
    if not visible: return
    if event is InputEventScreenTouch:
        var p:=event.position
        if event.pressed:
            if fire_rect.has_point(p):
                fire_touch=event.index
                fire_pressed.emit()
                get_viewport().set_input_as_handled()
            elif p.x<size.x*0.43 and p.y>size.y*0.55:
                joy_touch=event.index
                _set_joy(p)
                get_viewport().set_input_as_handled()
            elif p.x>size.x*0.45:
                look_touch=event.index
                last_look=p
                get_viewport().set_input_as_handled()
        else:
            if event.index==joy_touch:
                joy_touch=-1
                joy_knob=Vector2.ZERO
                move_changed.emit(Vector2.ZERO)
                queue_redraw()
            if event.index==look_touch: look_touch=-1
            if event.index==fire_touch: fire_touch=-1
    elif event is InputEventScreenDrag:
        if event.index==joy_touch:
            _set_joy(event.position)
            get_viewport().set_input_as_handled()
        elif event.index==look_touch:
            var d:=event.position-last_look
            last_look=event.position
            look_changed.emit(d)
            get_viewport().set_input_as_handled()

func _set_joy(p:Vector2)->void:
    var d:=p-joy_center
    if d.length()>joy_radius: d=d.normalized()*joy_radius
    joy_knob=d
    move_changed.emit(Vector2(d.x/joy_radius,-d.y/joy_radius))
    queue_redraw()
