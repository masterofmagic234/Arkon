# ACORN HUNTER — Carolina — Godot Level 1 V5

This archive is intended to be uploaded as-is to GitHub.
The repository's external GitHub Actions workflow should locate `project.godot` inside the ZIP and export an Android APK.

V5 focuses on:
- robust mobile touch controls;
- movement and look separated from fire;
- custom HUD and full 20x14 minimap;
- world-grounded fixed-Y sprites;
- objective path generated from the actual map;
- intro/start screen and music started by user action;
- 3D weapon replaced by a stable FPS overlay weapon;
- real 3D depth/collision remains Godot-managed.
