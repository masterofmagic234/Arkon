# Acorn Hunter v12 — World-Space Park Floor

Based on the frozen V6.2/V11 performance baseline.

## What changed
- Added separate world-space grass and stone paving textures.
- The paving follows the actual map geometry: each walkable map cell knows which neighboring cells connect, and the stone strip forms straight segments, corners, T-junctions and crossings in world coordinates.
- Grass remains as a verge beside the path inside each corridor.
- Floor rendering is downsampled to keep phone performance reasonable.
- The dynamic night sky from the baseline is retained.
- No gameplay, weapon, enemy, HUD, sprite, or wall changes are included in this iteration.

## GitHub
The existing ZIP-first workflow can unpack this archive and build the APK automatically. No local Android tooling is required.
