extends RefCounted

# Gameplay orchestration only. Input and scene lifecycle remain in game.gd.
const LevelData = preload("res://scripts/level_data.gd")
const CombatQuery = preload("res://scripts/combat_query.gd")
const WorldCollision = preload("res://scripts/world_collision.gd")
const WorldQueries = preload("res://scripts/world_queries.gd")
const WorldSpriteView = preload("res://scripts/world_sprite_view.gd")
const PickupQuery = preload("res://scripts/pickup_query.gd")
const SquirrelMotionMath = preload("res://scripts/squirrel_motion_math.gd")
const SquirrelQuery = preload("res://scripts/squirrel_query.gd")
const SquirrelAttackQuery = preload("res://scripts/squirrel_attack_query.gd")
const ConeQuery = preload("res://scripts/cone_query.gd")
const HealthMath = preload("res://scripts/health_math.gd")
const AmmoMath = preload("res://scripts/ammo_math.gd")
const MissionProgressQuery = preload("res://scripts/mission_progress_query.gd")
const FireQuery = preload("res://scripts/fire_query.gd")
const MissionStateQuery = preload("res://scripts/mission_state_query.gd")
const DeathQuery = preload("res://scripts/death_query.gd")
const SceneLookup = preload("res://scripts/scene_lookup.gd")

var root
var player
var camera
var game_state
var world_sprite_view
var combat_feedback
var audio_controller
var message_view
var mission_view
var on_mission_end: Callable

func setup(root_node, player_node, camera_node, state, world_sprites, feedback, audio, messages, mission, mission_end_callback: Callable) -> void:
    root = root_node
    player = player_node
    camera = camera_node
    game_state = state
    world_sprite_view = world_sprites
    combat_feedback = feedback
    audio_controller = audio
    message_view = messages
    mission_view = mission
    on_mission_end = mission_end_callback

func handle_fire() -> void:
    if not FireQuery.can_fire(game_state.mission_complete, game_state.mission_failed, game_state.fire_cooldown, game_state.ammo):
        if game_state.ammo <= 0 and not MissionStateQuery.is_finished(game_state.mission_complete, game_state.mission_failed) and game_state.fire_cooldown <= 0.0:
            set_message("Пусто. Даже белки в шоке.", 1.2)
        return
    game_state.ammo = AmmoMath.consume_one(game_state.ammo)
    game_state.fire_cooldown = 0.18
    game_state.recoil_time = 0.10
    combat_feedback.recoil()
    combat_feedback.show_muzzle()
    audio_controller.play_fx(audio_controller.shoot_stream)

    var hit := CombatQuery.raycast(root.get_world_3d(), camera)
    if hit.is_empty():
        miss()
        return

    var squirrel := WorldQueries.find_squirrel_from_collider(hit.get("collider"), game_state.squirrels)
    if squirrel == "" or game_state.stunned.has(squirrel):
        miss()
        return

    game_state.squirrel_hp[squirrel] = HealthMath.apply_damage(int(game_state.squirrel_hp.get(squirrel, 2)), 1)
    var target = SceneLookup.mesh_node(root, squirrel)
    audio_controller.play_fx(audio_controller.squirrel_hit_stream)
    combat_feedback.show_hit()
    if int(game_state.squirrel_hp[squirrel]) <= 0:
        game_state.stunned[squirrel] = true
        if target != null:
            world_sprite_view.apply_squirrel_stunned(target)
        set_message(LevelData.STUN_LINES.pick_random(), 2.0)
    else:
        set_message(LevelData.HIT_LINES.pick_random() + "\nЕщё один раз — и белка отдыхает.", 1.4)
    await root.get_tree().create_timer(0.35).timeout
    if MissionStateQuery.is_active(game_state.mission_complete, game_state.mission_failed):
        combat_feedback.hide_hit()

func miss() -> void:
    combat_feedback.show_miss()
    set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await root.get_tree().create_timer(0.22).timeout
    if MissionStateQuery.is_active(game_state.mission_complete, game_state.mission_failed):
        combat_feedback.hide_hit()

func update(delta: float) -> void:
    update_squirrels(delta)
    collect_acorns()
    check_fake_cone()

func update_squirrels(delta: float) -> void:
    var player_pos := Vector2(player.global_position.x, player.global_position.z)
    for name in game_state.squirrels:
        if game_state.stunned.has(name):
            continue
        var node = SceneLookup.mesh_node(root, name)
        if node == null:
            continue
        var home: Vector2 = game_state.squirrel_home[name]
        var dist := home.distance_to(player_pos)
        if SquirrelQuery.should_chase(dist):
            var proposed := SquirrelMotionMath.proposed_position(home, player_pos, delta, 0.45)
            if not WorldCollision.is_wall(proposed.x, proposed.y):
                game_state.squirrel_home[name] = proposed
                node.position.x = proposed.x
                node.position.z = proposed.y
        world_sprite_view.animate_squirrel(node, float(game_state.squirrel_phase[name]))
        if SquirrelAttackQuery.can_attack(dist, game_state.damage_cooldown, LevelData.SQUIRREL_ATTACK_DISTANCE):
            game_state.damage_cooldown = 0.8
            game_state.hp = HealthMath.apply_damage(game_state.hp, 12)
            audio_controller.play_fx(audio_controller.damage_stream)
            set_message(LevelData.DAMAGE_LINES.pick_random(), 1.2)
            if DeathQuery.is_dead(game_state.hp):
                fail()

func collect_acorns() -> void:
    for name in game_state.acorns.duplicate():
        var node = SceneLookup.mesh_node(root, name)
        if node != null and PickupQuery.is_in_range(player.global_position, node.global_position, LevelData.ACORN_PICKUP_RADIUS):
            world_sprite_view.hide_pickup(node)
            game_state.acorns.erase(name)
            game_state.collected += 1
            if audio_controller.pickup_stream != null:
                audio_controller.play_fx(audio_controller.pickup_stream)
            set_message(LevelData.ACORN_LINES.pick_random() + "\nЖёлуди: %d / %d" % [game_state.collected, LevelData.ACORN_COUNT], 1.8)
            if MissionProgressQuery.is_complete(game_state.collected, LevelData.ACORN_COUNT):
                complete()

func check_fake_cone() -> void:
    if game_state.fake_cone_found:
        return
    var cone := root.get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null and ConeQuery.is_in_range(player.global_position, cone.global_position):
        game_state.fake_cone_found = true
        game_state.hp = HealthMath.apply_damage(game_state.hp, 12)
        if audio_controller.damage_stream != null:
            audio_controller.play_fx(audio_controller.damage_stream)
        set_message(LevelData.CONE_LINES.pick_random(), 2.4)
        if DeathQuery.is_dead(game_state.hp):
            fail()

func complete() -> void:
    game_state.mission_complete = true
    if on_mission_end.is_valid():
        on_mission_end.call()
    mission_view.show_complete(LevelData.ACORN_COUNT)

func fail() -> void:
    game_state.mission_failed = true
    if on_mission_end.is_valid():
        on_mission_end.call()
    mission_view.show_failed()

func set_message(text: String, duration: float) -> void:
    message_view.set_text(text)
    game_state.message_time = duration
