class_name GameState
extends RefCounted

const LevelData = preload("res://scripts/core/level_data.gd")

var collected := 0
var ammo := LevelData.MAX_AMMO
var hp := LevelData.MAX_HP
var message_time := 0.0
var fire_cooldown := 0.0
var damage_cooldown := 0.0
var recoil_time := 0.0
var foot_timer := 0.0
var fake_cone_found := false
var mission_complete := false
var mission_failed := false
var muted := false
var stunned: Dictionary = {}
var squirrel_hp := {"Squirrel01": 2, "Squirrel02": 2}
var acorns := LevelData.ACORNS.duplicate()
var squirrels := LevelData.SQUIRRELS.duplicate()
var squirrel_home := LevelData.SQUIRREL_HOME.duplicate()
var squirrel_phase := LevelData.SQUIRREL_PHASE.duplicate()
