class_name HudController
extends RefCounted

const GameState = preload("res://scripts/core/game_state.gd")

var game: Node
var state: GameState
var count_label: Label
var hp_ammo_label: Label
var message_label: Label
var mission_panel: Panel
var mission_title: Label
var mission_body: Label
var weapon: TextureRect
var muzzle: ColorRect
var hit_marker: Label
var mute_button: Button

func setup(game_root: Node, game_state: GameState) -> void:
    game = game_root
    state = game_state
    count_label = game_root.get_node("HUD/Count")
    hp_ammo_label = game_root.get_node("HUD/HPAmmo")
    message_label = game_root.get_node("HUD/Message")
    mission_panel = game_root.get_node("HUD/Mission")
    mission_title = game_root.get_node("HUD/Mission/Title")
    mission_body = game_root.get_node("HUD/Mission/Body")
    weapon = game_root.get_node("HUD/Weapon")
    muzzle = game_root.get_node("HUD/MuzzleFlash")
    hit_marker = game_root.get_node("HUD/HitMarker")
    mute_button = game_root.get_node("HUD/Mute")
    mission_panel.visible = false
    muzzle.visible = false
    hit_marker.visible = false

func update() -> void:
    count_label.text = "ЖЁЛУДИ  %d / 4" % state.collected
    hp_ammo_label.text = "HP %d     AMMO %d" % [state.hp, state.ammo]

func set_message(text: String, duration: float) -> void:
    message_label.text = text
    state.message_time = duration

func tick_message(delta: float) -> void:
    state.message_time = maxf(0.0, state.message_time - delta)
    if state.message_time <= 0.0:
        message_label.text = ""

func start_shot_feedback() -> void:
    state.recoil_time = 0.10
    weapon.position.y = 470.0
    muzzle.visible = true
    muzzle.modulate.a = 1.0

func tick_shot_feedback(delta: float) -> void:
    state.recoil_time = maxf(0.0, state.recoil_time - delta)
    if state.recoil_time <= 0.0:
        weapon.position.y = 455.0
    if muzzle.visible:
        muzzle.modulate.a = clampf(muzzle.modulate.a - delta * 7.0, 0.0, 1.0)
        if muzzle.modulate.a <= 0.0:
            muzzle.visible = false

func show_hit_marker(symbol: String, duration: float) -> void:
    hit_marker.visible = true
    hit_marker.text = symbol
    game.get_tree().create_timer(duration).timeout.connect(_hide_hit_marker)

func _hide_hit_marker() -> void:
    if not state.mission_complete and not state.mission_failed:
        hit_marker.visible = false

func complete() -> void:
    state.mission_complete = true
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    mission_body.text = "ЖЁЛУДИ: 4 / 4\n\nОН СУЩЕСТВУЕТ.\n\nКаролина нашла легендарный жёлудь.\nДарина может делать поделку.\nБелки официально проиграли.\n\nP.S. Данил всё это время верил в тебя."
    weapon.visible = false

func fail() -> void:
    state.mission_failed = true
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ПРОВАЛЕНА"
    mission_body.text = "HP: 0\n\nБелки победили.\nЭто позор.\n\nНо Дарина всё ещё ждёт жёлуди."
    weapon.visible = false
