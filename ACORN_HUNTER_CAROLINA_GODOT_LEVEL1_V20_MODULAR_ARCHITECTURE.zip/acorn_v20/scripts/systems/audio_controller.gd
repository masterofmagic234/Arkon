class_name AudioController
extends RefCounted

signal message_requested(text: String, duration: float)

var game: Node
var music: AudioStreamPlayer
var fx: AudioStreamPlayer
var mute_button: Button
var muted := false

var foot1_stream = preload("res://assets/footstep1.wav")
var foot2_stream = preload("res://assets/footstep2.wav")
var shoot_stream = preload("res://assets/shoot.wav")
var squirrel_hit_stream = preload("res://assets/squirrel_hit.wav")
var pickup_stream = preload("res://assets/pickup.wav")
var damage_stream = preload("res://assets/damage.wav")

func setup(game_root: Node) -> void:
    game = game_root
    music = game_root.get_node("Music")
    fx = game_root.get_node("FX")
    mute_button = game_root.get_node("HUD/Mute")
    music.volume_db = -9.0
    music.play()
    mute_button.pressed.connect(_toggle_music)

func play_fx(stream: AudioStream) -> void:
    if muted or stream == null:
        return
    fx.stream = stream
    fx.play()

func footstep() -> void:
    if muted:
        return
    fx.stream = foot1_stream if int(Time.get_ticks_msec() / 300) % 2 == 0 else foot2_stream
    fx.play()

func play_shot() -> void:
    play_fx(shoot_stream)

func play_squirrel_hit() -> void:
    play_fx(squirrel_hit_stream)

func play_pickup() -> void:
    play_fx(pickup_stream)

func play_damage() -> void:
    play_fx(damage_stream)

func _toggle_music() -> void:
    muted = not muted
    mute_button.text = "×" if muted else "♪"
    if muted:
        music.stop()
    elif not music.playing:
        music.play()
    message_requested.emit(
        "Музыка выключена." if muted else "Музыка возвращена. Белки снова слышат угрозу.", 1.6
    )
