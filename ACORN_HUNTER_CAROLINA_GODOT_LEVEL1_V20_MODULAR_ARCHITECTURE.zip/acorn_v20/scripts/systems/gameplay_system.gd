class_name GameplaySystem
extends Node

const LevelData = preload("res://scripts/core/level_data.gd")
const GameState = preload("res://scripts/core/game_state.gd")
const InputController = preload("res://scripts/systems/input_controller.gd")
const AudioController = preload("res://scripts/systems/audio_controller.gd")
const HudController = preload("res://scripts/ui/hud_controller.gd")

signal message_requested(text: String, duration: float)
signal hud_update_requested
signal mission_completed
signal mission_failed

var game: Node
var state: GameState
var input_controller: InputController
var audio: AudioController
var hud: HudController
var player: CharacterBody3D
var camera: Camera3D
var weapon: TextureRect
var hit_marker: Label

func setup(game_root: Node, game_state: GameState, input_ref: InputController, audio_ref: AudioController, hud_ref: HudController) -> void:
    game = game_root
    state = game_state
    input_controller = input_ref
    audio = audio_ref
    hud = hud_ref
    player = game_root.get_node("Player")
    camera = game_root.get_node("Player/Camera3D")
    weapon = game_root.get_node("HUD/Weapon")
    hit_marker = game_root.get_node("HUD/HitMarker")

func request_message(text: String, duration: float) -> void:
    message_requested.emit(text, duration)

func tick(delta: float) -> void:
    if state.mission_complete or state.mission_failed:
        player.velocity = Vector3.ZERO
        return

    var move_axis := input_controller.move_axis
    var forward := -move_axis.y
    player.velocity = -player.global_transform.basis.z * (forward * LevelData.WALK_SPEED)
    player.velocity.y = 0.0
    player.move_and_slide()
    if abs(move_axis.x) > 0.04:
        player.rotate_y(-move_axis.x * LevelData.TURN_SPEED * delta)

    state.fire_cooldown = maxf(0.0, state.fire_cooldown - delta)
    state.damage_cooldown = maxf(0.0, state.damage_cooldown - delta)
    hud.tick_message(delta)
    hud.tick_shot_feedback(delta)

    if abs(forward) > 0.05:
        state.foot_timer -= delta
        if state.foot_timer <= 0.0:
            audio.footstep()
            state.foot_timer = 0.30
    else:
        state.foot_timer = 0.0

    _update_squirrels(delta)
    _collect_acorns()
    _check_fake_cone()
    hud_update_requested.emit()

func fire() -> void:
    if state.mission_complete or state.mission_failed or state.fire_cooldown > 0.0:
        return
    if state.ammo <= 0:
        request_message("Пусто. Даже белки в шоке.", 1.2)
        return
    state.ammo -= 1
    state.fire_cooldown = 0.18
    hud.start_shot_feedback()
    audio.play_shot()

    var query := PhysicsRayQueryParameters3D.create(
        camera.global_position,
        camera.global_position + (-camera.global_transform.basis.z * LevelData.FIRE_RANGE),
        LevelData.SQUIRREL_LAYER | LevelData.WORLD_LAYER
    )
    query.collide_with_areas = true
    query.collide_with_bodies = true
    var hit := game.get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        _miss()
        return
    var squirrel := _find_squirrel_from_collider(hit.get("collider"))
    if squirrel == "" or state.stunned.has(squirrel):
        _miss()
        return

    state.squirrel_hp[squirrel] = int(state.squirrel_hp.get(squirrel, 2)) - 1
    var target := game.get_node_or_null(squirrel) as MeshInstance3D
    audio.play_squirrel_hit()
    hud.show_hit_marker("×", 0.35)
    if int(state.squirrel_hp[squirrel]) <= 0:
        state.stunned[squirrel] = true
        if target != null:
            var stunned_texture := load("res://assets/squirrel_stunned.png")
            if stunned_texture != null and target.mesh is QuadMesh:
                var base_mat := (target.mesh as QuadMesh).material as StandardMaterial3D
                if base_mat != null:
                    var unique_mat := base_mat.duplicate() as StandardMaterial3D
                    unique_mat.albedo_texture = stunned_texture
                    target.set_surface_override_material(0, unique_mat)
            target.rotation.z = deg_to_rad(-7.0)
            target.scale = Vector3(1.0, 0.78, 1.0)
        request_message(LevelData.STUN_LINES.pick_random(), 2.0)
    else:
        request_message(LevelData.HIT_LINES.pick_random() + "\nЕщё один раз — и белка отдыхает.", 1.4)

func _find_squirrel_from_collider(collider: Object) -> String:
    var node := collider as Node
    while node != null:
        if state.squirrels.has(node.name):
            return node.name
        node = node.get_parent()
    return ""

func _miss() -> void:
    hud.show_hit_marker("•", 0.22)
    request_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)

func _update_squirrels(delta: float) -> void:
    var player_pos := Vector2(player.global_position.x, player.global_position.z)
    for name in state.squirrels:
        if state.stunned.has(name):
            continue
        var node := game.get_node_or_null(name) as MeshInstance3D
        if node == null:
            continue
        var home: Vector2 = state.squirrel_home[name]
        var dist := home.distance_to(player_pos)
        if dist < 6.0 and dist > 1.8:
            var away := (home - player_pos).normalized()
            var proposed := home + away * delta * 0.45
            if not LevelData.is_wall(proposed.x, proposed.y):
                state.squirrel_home[name] = proposed
                node.position.x = proposed.x
                node.position.z = proposed.y
        node.rotation.z = sin(Time.get_ticks_msec() * 0.003 + float(state.squirrel_phase[name])) * 0.03
        if dist < 1.0 and state.damage_cooldown <= 0.0:
            state.damage_cooldown = 0.8
            state.hp = max(0, state.hp - 12)
            audio.play_damage()
            request_message(LevelData.DAMAGE_LINES.pick_random(), 1.2)
            if state.hp <= 0:
                _fail()

func _collect_acorns() -> void:
    for name in state.acorns.duplicate():
        var node := game.get_node_or_null(name) as MeshInstance3D
        if node != null and player.global_position.distance_to(node.global_position) <= LevelData.ACORN_PICKUP_RADIUS:
            node.visible = false
            state.acorns.erase(name)
            state.collected += 1
            audio.play_pickup()
            request_message(LevelData.ACORN_LINES.pick_random() + "\nЖёлуди: %d / 4" % state.collected, 1.8)
            if state.collected == 4:
                _complete()

func _check_fake_cone() -> void:
    if state.fake_cone_found:
        return
    var cone := game.get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null and player.global_position.distance_to(cone.global_position) <= 1.2:
        state.fake_cone_found = true
        state.hp = max(0, state.hp - 12)
        audio.play_damage()
        request_message(LevelData.CONE_LINES.pick_random(), 2.4)
        if state.hp <= 0:
            _fail()

func _complete() -> void:
    state.mission_complete = true
    input_controller.move_axis = Vector2.ZERO
    input_controller._reset_joystick()
    hud.complete()
    mission_completed.emit()

func _fail() -> void:
    state.mission_failed = true
    input_controller.move_axis = Vector2.ZERO
    input_controller._reset_joystick()
    hud.fail()
    mission_failed.emit()
