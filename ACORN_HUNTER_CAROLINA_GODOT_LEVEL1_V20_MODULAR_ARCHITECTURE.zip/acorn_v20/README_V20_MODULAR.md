# ACORN HUNTER — V20 MODULAR

Architecture refactor of the V20 Expanded Canonical baseline.

## Preservation rule
This build is an architecture refactor, not a gameplay redesign. The scene, map, sky, assets, spawn, movement model, touch handling, combat rules and HUD copy are preserved from V20 unless required to move code between modules.

## Module boundaries
- `scripts/core/level_data.gd` — single source of truth for map, constants, object names and tuning values.
- `scripts/core/game_state.gd` — runtime state only; no scene logic.
- `scripts/systems/input_controller.gd` — proven V20 joystick/fire input only.
- `scripts/systems/gameplay_system.gd` — movement, combat, squirrels, pickups and mission rules.
- `scripts/systems/audio_controller.gd` — music, footsteps and FX.
- `scripts/ui/hud_controller.gd` — HUD presentation, feedback and end panels.
- `scripts/game.gd` — orchestration/wiring only.
- `scripts/minimap.gd` — presentation only; consumes `LevelData` and runtime state.

## Safe-change rule
A change to one subsystem should normally require editing only that subsystem and, if needed, its explicit interface. Do not copy map/constants into another script.

## Important V20 invariants
- landscape orientation
- V20 scene and visual assets
- V20 procedural sky untouched
- player spawn untouched
- V20 joystick/mouse handling preserved
- 38 ammo / 100 HP
- 4 acorns
- squirrels have 2 HP; second hit becomes stunned
- canonical 20x14 map scaled by 1.8

## Validation
Static checks were performed on the refactored source. Runtime Android validation requires an actual Godot/Android build environment; do not treat static validation as proof of device behavior.
