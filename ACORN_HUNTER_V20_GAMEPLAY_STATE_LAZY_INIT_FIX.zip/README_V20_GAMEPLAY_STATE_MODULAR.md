# ACORN HUNTER — V20 GAMEPLAY STATE MODULAR

Base: V20 SQUIRREL ATTACK QUERY FIX (last phone-confirmed working build).

## This step
- Added `scripts/game_state.gd` as the single container for mutable gameplay runtime state.
- Moved only runtime state out of `game.gd`: movement axis/touch id, ammo, HP, pickups, timers, mission flags, squirrel state and positions.
- `game.gd` remains responsible for orchestration, input, physics and presentation calls.
- Added and integrated `SceneLookup` for scene-node lookup only.
- Preserved the proven touch input path, player spawn, sky, scene, assets, and gameplay rules.
- No new gameplay mechanics.

## Architectural boundary
`GameState` contains data only. It has no Node references, input handling, physics, audio, or UI code.
