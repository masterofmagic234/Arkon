extends RefCounted

# Mutable gameplay state only. No scene nodes, input handling, or presentation logic.
# This keeps runtime state independent from the systems that read or display it.
const LevelData = preload("res://scripts/level_data.gd")

var move_axis := Vector2.ZERO
var joystick_touch_id := -1
var collected := 0
var ammo := LevelData.MAX_AMMO
var hp := LevelData.MAX_HP
var message_time := 0.0
var fire_cooldown := 0.0
var damage_cooldown := 0.0
var recoil_time := 0.0
var foot_timer := 0.0
var fake_cone_found := false
var mission_complete := false
var mission_failed := false
var stunned: Dictionary = {}
var squirrel_hp := LevelData.SQUIRREL_HP.duplicate()
var acorns := LevelData.ACORN_NAMES.duplicate()
var squirrels := LevelData.SQUIRREL_NAMES.duplicate()
var squirrel_home := LevelData.SQUIRREL_HOME.duplicate()
var squirrel_phase := LevelData.SQUIRREL_PHASE.duplicate()
