extends RefCounted

# Scene-tree lookup only. No gameplay rules live here.
static func mesh_node(root, node_name):
    return root.get_node_or_null(node_name)
