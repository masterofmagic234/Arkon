# ACORN HUNTER — V20 GAMEPLAY STATE LAZY INIT FIX

Based on phone-confirmed V20 GAMEPLAY STATE MODULAR / FIX.

This build changes only GameState lifetime initialization:
- GameState is no longer instantiated as a member initializer.
- It is instantiated at the start of _ready(), after the scene is loaded.
- The variable is kept as RefCounted to avoid a custom global class dependency.

No gameplay, input, spawn, sky, assets, or SceneLookup logic changed.
