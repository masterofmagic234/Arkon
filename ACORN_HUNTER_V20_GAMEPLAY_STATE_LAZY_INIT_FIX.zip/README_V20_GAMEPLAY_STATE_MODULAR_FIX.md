# ACORN HUNTER — V20 GAMEPLAY STATE MODULAR FIX

Base: V20 GAMEPLAY STATE MODULAR.

Fix: GameState is instantiated as a dynamically typed value (`var game_state = GameState.new()`) rather than inferred from an anonymous preloaded RefCounted script. This preserves access to the custom state fields without requiring a global `class_name` registration.

No gameplay/input/sky/spawn logic changed.
