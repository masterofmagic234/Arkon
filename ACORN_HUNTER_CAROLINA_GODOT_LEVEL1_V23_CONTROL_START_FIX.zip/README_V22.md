# ACORN HUNTER — V22

Base: V19 proven mobile input + canonical map.

Changes:
- V19 touch input path preserved unchanged.
- High-resolution 4096x2048 equirectangular night panorama.
- Linear+mipmap texture filtering on 3D materials.
- Old low-resolution moon/star billboards hidden; moon and stars are part of the panorama.
- Squirrels hunt the player using BFS through the canonical grid.
- Squirrels have 2 HP and become the stunned sprite after the second hit; no corpse sprite.
- World sprites reduced to fit corridors better.
