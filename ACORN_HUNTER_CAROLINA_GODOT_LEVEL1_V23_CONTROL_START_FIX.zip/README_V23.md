# ACORN HUNTER — V23 CONTROL + START FIX

V23 is based on V22 High Quality Night.

## Fixes
- Restored the canonical starting location from the original raycaster: map cell (2.5, 2.5), centered-world position (-7.5, -4.5).
- Player now starts facing into the level.
- Replaced joystick `gui_input` routing with root-level touch routing.
- Finger movement continues to control the joystick after the finger leaves the joystick panel.
- Touch coordinates are explicitly converted from viewport space to joystick-local space.
- Disabled `emulate_mouse_from_touch` because mobile touch is now handled directly; this removes duplicate mouse/touch input paths.
- Desktop mouse drag on the joystick is still supported for testing.
- Added the previously referenced `squirrel_stunned.png` asset to the package.

## Unchanged
- V22 high-quality 4096x2048 panorama sky.
- Linear + mipmap filtering on world textures.
- Squirrel 2-hit/stunned behavior.
- Canonical 20x14 level layout and existing HUD/audio/art.

## Verification
This package is statically checked only. The container does not have a Godot runtime, so Android runtime input/export cannot be truthfully claimed as tested here.
