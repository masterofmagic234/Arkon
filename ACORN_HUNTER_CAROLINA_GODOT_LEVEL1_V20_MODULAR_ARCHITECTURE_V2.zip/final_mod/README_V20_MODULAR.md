# ACORN HUNTER — V20 MODULAR ARCHITECTURE

This build is an architectural refactor of V20. The scene, project settings, assets, player spawn, camera, sky and UI layout are intentionally preserved from V20.

## Dependency direction

```text
LevelData (immutable definition)
        ↓
GameState (runtime state)
        ↓
GameplaySystem ← InputController
        ↓               ↓
HudController     AudioController
        ↓
Game scene / Minimap
```

## Rules

- `game.tscn` is unchanged from V20.
- `project.godot` is unchanged from V20.
- The sky is not touched.
- Touch input remains attached to the actual UI controls, as in V20.
- Gameplay rules are in `GameplaySystem`.
- HUD presentation is in `HudController`.
- Audio is in `AudioController`.
- Runtime mutable state is in `GameState`.
- Level constants/map/data are in `LevelData`.
- Minimap reads the same canonical map from `LevelData`.
- `game.gd` is only the composition root and frame coordinator.

No new gameplay features are introduced by this refactor.
