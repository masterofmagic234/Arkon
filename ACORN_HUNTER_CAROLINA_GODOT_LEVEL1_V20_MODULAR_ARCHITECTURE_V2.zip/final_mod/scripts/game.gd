extends Node3D

const GameState = preload("res://scripts/core/game_state.gd")
const InputController = preload("res://scripts/systems/input_controller.gd")
const AudioController = preload("res://scripts/systems/audio_controller.gd")
const HudController = preload("res://scripts/ui/hud_controller.gd")
const GameplaySystem = preload("res://scripts/systems/gameplay_system.gd")

# ACORN HUNTER — LEVEL 1
# V20 behavior baseline. This file is only the composition root.
# It wires independent systems together; it does not contain gameplay rules.

var state: GameState
var input_controller: InputController
var audio_controller: AudioController
var hud_controller: HudController
var gameplay_system: GameplaySystem

@onready var camera: Camera3D = $Player/Camera3D
@onready var carolina: TextureRect = $HUD/Carolina
@onready var minimap: Control = $HUD/Minimap

func _ready() -> void:
    # Camera setup is deliberately identical to V20.
    camera.rotation = Vector3.ZERO
    camera.fov = 70.0
    camera.near = 0.05
    camera.far = 40.0
    carolina.texture = load("res://assets/carolina_face.png")

    state = GameState.new()
    input_controller = InputController.new()
    audio_controller = AudioController.new()
    hud_controller = HudController.new()
    gameplay_system = GameplaySystem.new()
    add_child(gameplay_system)

    # Explicit composition: each subsystem receives only the references it actually needs.
    input_controller.setup(self)
    audio_controller.setup(self)
    hud_controller.setup(self, state)
    gameplay_system.setup(self, state, input_controller, audio_controller, hud_controller)

    input_controller.fire_requested.connect(gameplay_system.fire)
    audio_controller.message_requested.connect(hud_controller.set_message)
    $HUD/Mission/Menu.pressed.connect(_on_menu_pressed)

    hud_controller.update()
    hud_controller.set_message("Парк открыт. Дубы не прячутся — жёлуди тоже.", 4.0)
    _refresh_minimap()

func _physics_process(delta: float) -> void:
    gameplay_system.tick(delta)
    _refresh_minimap()

func _refresh_minimap() -> void:
    minimap.set_game_state(
        $Player.global_position,
        $Player.rotation.y,
        state.acorns,
        state.squirrels,
        state.stunned
    )

func _on_menu_pressed() -> void:
    get_tree().change_scene_to_file("res://menu.tscn")
