class_name HudController
extends RefCounted

const GameState = preload("res://scripts/core/game_state.gd")

# HUD is presentation only. It receives state and commands; gameplay rules stay elsewhere.
var state: GameState
var count_label: Label
var hp_ammo_label: Label
var message_label: Label
var mission_panel: Panel
var mission_title: Label
var mission_body: Label
var weapon: TextureRect
var muzzle: ColorRect
var hit_marker: Label

func setup(game_root: Node, game_state: GameState) -> void:
    state = game_state
    count_label = game_root.get_node("HUD/Count")
    hp_ammo_label = game_root.get_node("HUD/HPAmmo")
    message_label = game_root.get_node("HUD/Message")
    mission_panel = game_root.get_node("HUD/Mission")
    mission_title = game_root.get_node("HUD/Mission/Title")
    mission_body = game_root.get_node("HUD/Mission/Body")
    weapon = game_root.get_node("HUD/Weapon")
    muzzle = game_root.get_node("HUD/MuzzleFlash")
    hit_marker = game_root.get_node("HUD/HitMarker")
    mission_panel.visible = false
    muzzle.visible = false
    hit_marker.visible = false

func update() -> void:
    count_label.text = "ЖЁЛУДИ  %d / 4" % state.collected
    hp_ammo_label.text = "HP %d     AMMO %d" % [state.hp, state.ammo]

func set_message(text: String, duration: float) -> void:
    message_label.text = text
    state.message_time = duration

func tick(delta: float) -> void:
    state.message_time = maxf(0.0, state.message_time - delta)
    if state.message_time <= 0.0:
        message_label.text = ""
    state.recoil_time = maxf(0.0, state.recoil_time - delta)
    if state.recoil_time <= 0.0:
        weapon.position.y = 455.0
    if muzzle.visible:
        muzzle.modulate.a = clampf(muzzle.modulate.a - delta * 7.0, 0.0, 1.0)
        if muzzle.modulate.a <= 0.0:
            muzzle.visible = false

func start_shot_feedback() -> void:
    state.recoil_time = 0.10
    weapon.position.y = 470.0
    muzzle.visible = true
    muzzle.modulate.a = 1.0

func show_hit_marker(symbol: String) -> void:
    hit_marker.visible = true
    hit_marker.text = symbol

func hide_hit_marker_if_active() -> void:
    if not state.mission_complete and not state.mission_failed:
        hit_marker.visible = false

func complete() -> void:
    state.mission_complete = true
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    mission_body.text = "ЖЁЛУДИ: 4 / 4\n\nОН СУЩЕСТВУЕТ.\n\nКаролина нашла легендарный жёлудь.\nДарина может делать поделку.\nБелки официально проиграли.\n\nP.S. Данил всё это время верил в тебя."
    weapon.visible = false

func fail() -> void:
    state.mission_failed = true
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ПРОВАЛЕНА"
    mission_body.text = "HP: 0\n\nБелки победили.\nЭто позор.\n\nНо Дарина всё ещё ждёт жёлуди."
    weapon.visible = false
