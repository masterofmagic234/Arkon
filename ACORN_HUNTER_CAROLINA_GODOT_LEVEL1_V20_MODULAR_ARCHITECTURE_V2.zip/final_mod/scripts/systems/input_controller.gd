class_name InputController
extends RefCounted

const LevelData = preload("res://scripts/core/level_data.gd")

# Input is intentionally isolated. Gameplay only consumes move_axis and fire_requested.
signal move_changed(axis: Vector2)
signal fire_requested

var joystick: Panel
var knob: Panel
var fire_button: Button
var joystick_touch_id := -1
var move_axis := Vector2.ZERO

func setup(game_root: Node) -> void:
    joystick = game_root.get_node("HUD/Joystick")
    knob = game_root.get_node("HUD/Joystick/Knob")
    fire_button = game_root.get_node("HUD/Fire")
    joystick.gui_input.connect(_on_joystick_gui_input)
    fire_button.pressed.connect(_on_fire_pressed)
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func _on_joystick_gui_input(event: InputEvent) -> void:
    # This is the V20 touch path kept intact: GUI control owns the touch event.
    if event is InputEventScreenTouch:
        if event.pressed:
            joystick_touch_id = event.index
            _update_joystick(event.position)
            joystick.accept_event()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _update_joystick(event.position)
        joystick.accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            joystick_touch_id = -2
            _update_joystick(event.position)
            joystick.accept_event()
        elif joystick_touch_id == -2:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventMouseMotion and joystick_touch_id == -2:
        _update_joystick(event.position)
        joystick.accept_event()
    move_changed.emit(move_axis)

func _update_joystick(position: Vector2) -> void:
    var center := joystick.size * 0.5
    var delta := position - center
    if delta.length() > LevelData.JOYSTICK_RADIUS:
        delta = delta.normalized() * LevelData.JOYSTICK_RADIUS
    move_axis = Vector2(delta.x / LevelData.JOYSTICK_RADIUS, delta.y / LevelData.JOYSTICK_RADIUS)
    knob.position = center - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    move_axis = Vector2.ZERO
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func reset() -> void:
    joystick_touch_id = -1
    _reset_joystick()

func _on_fire_pressed() -> void:
    fire_requested.emit()
