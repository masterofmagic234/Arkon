# ACORN HUNTER — V21 POLISHED NIGHT

Base: user-confirmed V20/V19 playable build.

Changes in V21:
- Squirrels hunt the player instead of fleeing.
- Squirrel movement uses BFS over the canonical 20x14 map, so squirrels route around walls instead of getting stuck inside them.
- Squirrel movement is constrained by a small clearance radius.
- Tree and squirrel billboard sprites are reduced to fit within their free map cells and avoid visual wall intersection.
- Stunned squirrel remains a friendly-looking defeated sprite; the gameplay remains 2 HP / second hit = defeated.
- Added a custom equirectangular night-sky panorama with stars and a soft Milky Way band.
- Added subtle moonlight, mobile-compatible glow, and depth fog for atmosphere.
- Existing touch controls, music, weapon, map, HUD, acorns and canonical level geometry are preserved.

Static validation:
- canonical map: 20x14
- walls: 107
- free cells: 173
- ZIP integrity checked

Runtime caveat: Godot Android runtime is not available in the build environment, so the APK was not physically executed here.
