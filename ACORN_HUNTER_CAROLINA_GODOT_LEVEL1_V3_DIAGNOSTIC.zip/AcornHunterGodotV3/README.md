# ACORN HUNTER — Carolina — Godot Level 1 V2

V2 rebuild of Level 1 using Godot 4 real 3D.

Key changes from V1:
- Camera3D and Player are static scene nodes, guaranteed to exist before runtime construction.
- Android orientation is explicitly landscape.
- Path cells are calculated before floor meshes are created.
- Object positions are sanitized so trees/acorns/squirrels/fake cone cannot spawn inside walls.
- Godot handles perspective, depth, billboard projection and collisions.
- Compatibility renderer / OpenGL 3.

Build through the external GitHub Actions workflow that extracts this ZIP, as requested.
