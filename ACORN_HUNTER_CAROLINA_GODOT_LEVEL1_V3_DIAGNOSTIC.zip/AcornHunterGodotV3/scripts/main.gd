extends Node3D

const MAP_W := 20
const MAP_H := 14
const SPEED := 4.1
const LOOK_SENS := 0.0045
const GOAL := 4

const MAP = [
 [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
 [1,0,0,0,0,0,1,1,1,0,0,0,1,1,0,0,0,0,0,1],
 [1,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,1],
 [1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1],
 [1,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1],
 [1,0,1,1,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1],
 [1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1],
 [1,0,0,0,1,1,1,0,1,0,1,1,1,0,0,0,0,1,0,1],
 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1],
 [1,0,0,1,1,1,0,0,1,1,1,0,0,0,0,0,0,1,0,1],
 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
 [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

const ACORNS = [Vector2(5.5,2.5),Vector2(10.5,2.5),Vector2(14.5,3.5),Vector2(13.5,7.5)]
const TREES = [Vector2(5.5,2.5),Vector2(10.5,2.5),Vector2(14.5,3.5),Vector2(3.5,6.5),Vector2(8.5,6.5),Vector2(13.5,7.5),Vector2(17.5,8.5),Vector2(5.5,11.5),Vector2(12.5,11.5)]
const SQUIRRELS = [Vector2(9.2,5.2),Vector2(16.3,6.7)]

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var diagnostic: Label = $DiagnosticLayer/Panel/Diagnostic

var grass = preload("res://assets/grass_tile.png")
var stone = preload("res://assets/stone_path_tile.png")
var wall_tex = [preload("res://assets/hedge_wall_0.png"),preload("res://assets/hedge_wall_1.png"),preload("res://assets/hedge_wall_2.png"),preload("res://assets/hedge_wall_3.png")]
var tree_tex = preload("res://assets/oak_tree.png")
var acorn_tex = preload("res://assets/acorn.png")
var squirrel_tex = preload("res://assets/squirrel.png")
var face_tex = preload("res://assets/carolina_face.png")

var yaw := 0.0
var pitch := -0.035
var hp := 100
var ammo := 38
var found := 0
var acorns: Array[Node3D] = []
var squirrels: Array[Dictionary] = []
var fake_cones: Array[Node3D] = []
var hud_acorns: Label
var hud_hp: Label
var hud_ammo: Label
var toast: Label
var fire_timer := 0.0
var toast_timer := 0.0
var move_touch := Vector2.ZERO

func _ready() -> void:
    _diag("01/07  main.gd STARTED")
    _diag("02/07  Camera: " + str(camera.current) + "  pos=" + str(camera.global_position))
    _diag("03/07  Building floor + walls…")
    _build_floor_and_walls()
    _diag("04/07  Building trees / acorns / squirrels…")
    _build_objects()
    _diag("05/07  Building weapon…")
    _build_weapon()
    _diag("06/07  Building HUD / controls…")
    _build_hud()
    _diag("07/07  LEVEL 1 READY — diagnostic stays visible for 8s")
    await get_tree().create_timer(8.0).timeout
    if is_instance_valid(diagnostic):
        diagnostic.get_parent().get_parent().visible = false

func _diag(text: String) -> void:
    if is_instance_valid(diagnostic):
        diagnostic.text = "ACORN HUNTER — DIAGNOSTIC\n" + text
    print("[ACORN DIAG] " + text)

func _process(delta: float) -> void:
    fire_timer = max(0.0, fire_timer - delta)
    toast_timer = max(0.0, toast_timer - delta)
    if toast_timer <= 0.0 and is_instance_valid(toast): toast.text = ""
    _move_player(delta)
    _move_squirrels(delta)
    _pickups()
    _update_hud()

func _unhandled_input(e: InputEvent) -> void:
    if e is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT): _look(e.relative)
    elif e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT and e.pressed: _shoot()

func _look(d: Vector2) -> void:
    yaw -= d.x * LOOK_SENS
    pitch = clamp(pitch - d.y * LOOK_SENS, -1.15, 1.15)
    player.rotation.y = yaw
    camera.rotation.x = pitch

func _move_player(_delta: float) -> void:
    var k := Input.get_vector("move_left","move_right","move_forward","move_back")
    var v := move_touch if move_touch.length() > 0.05 else k
    var forward := -player.global_transform.basis.z
    var right := player.global_transform.basis.x
    var dir := right * v.x + forward * v.y
    dir.y = 0.0
    if dir.length() > 1.0: dir = dir.normalized()
    player.velocity = dir * SPEED
    player.velocity.y = 0.0
    player.move_and_slide()
    player.global_position.y = 0.92

func _build_floor_and_walls() -> void:
    for y in range(MAP_H):
        for x in range(MAP_W):
            if MAP[y][x] == 0:
                _make_floor(x,y)
            else:
                _make_wall(x,y)

func _mat(texture: Texture2D) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_texture = texture
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    m.roughness = 1.0
    return m

func _make_floor(x:int,y:int) -> void:
    var m := MeshInstance3D.new()
    var p := PlaneMesh.new()
    p.size = Vector2(1.02,1.02)
    m.mesh = p
    m.position = Vector3(x+0.5,0,y+0.5)
    m.material_override = _mat(grass)
    add_child(m)

func _make_wall(x:int,y:int) -> void:
    var m := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = Vector3(1.0,2.4,1.0)
    m.mesh = b
    m.position = Vector3(x+0.5,1.2,y+0.5)
    m.material_override = _mat(wall_tex[(x*31+y*17)%wall_tex.size()])
    add_child(m)
    var body := StaticBody3D.new()
    body.position = m.position
    var cs := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(1,2.4,1)
    cs.shape = shape
    body.add_child(cs)
    add_child(body)

func _build_objects() -> void:
    for p in TREES:
        _tree(p)
    for p in ACORNS:
        _acorn(p)
    _fake(Vector2(3.84,6.84))
    for p in SQUIRRELS:
        _squirrel(p)

func _sprite(tex:Texture2D, pos:Vector3, px:float, scale:=Vector3.ONE) -> Sprite3D:
    var s := Sprite3D.new()
    s.texture = tex
    s.pixel_size = px
    s.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    s.position = pos
    s.scale = scale
    s.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    s.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
    add_child(s)
    return s

func _tree(p:Vector2) -> void:
    _sprite(tree_tex,Vector3(p.x,1.4,p.y),0.010)

func _acorn(p:Vector2) -> void:
    var s := _sprite(acorn_tex,Vector3(p.x,0.32,p.y),0.0046)
    acorns.append(s)

func _fake(p:Vector2) -> void:
    var m := MeshInstance3D.new()
    var cone := CylinderMesh.new()
    cone.top_radius = 0.03
    cone.bottom_radius = 0.16
    cone.height = 0.38
    cone.radial_segments = 8
    m.mesh = cone
    m.position = Vector3(p.x,0.19,p.y)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color("654126")
    mat.roughness = 1
    m.material_override = mat
    add_child(m)
    fake_cones.append(m)

func _squirrel(p:Vector2) -> void:
    var s := _sprite(squirrel_tex,Vector3(p.x,0.62,p.y),0.0064)
    squirrels.append({"node":s,"hp":2,"alive":true})

func _build_weapon() -> void:
    var w := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = Vector3(0.42,0.24,0.95)
    w.mesh = b
    w.position = Vector3(0,-0.4,-0.78)
    var m := StandardMaterial3D.new()
    m.albedo_color = Color("1b181b")
    w.material_override = m
    camera.add_child(w)

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var bar := ColorRect.new()
    bar.color = Color(0.015,0.055,0.05,0.94)
    bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    bar.custom_minimum_size = Vector2(0,62)
    layer.add_child(bar)
    var title := Label.new()
    title.text = "ОПЕРАЦИЯ «ЖЁЛУДЬ»"
    title.position = Vector2(18,8)
    title.add_theme_font_size_override("font_size",22)
    bar.add_child(title)
    hud_acorns = Label.new()
    hud_acorns.position = Vector2(18,36)
    bar.add_child(hud_acorns)
    hud_hp = Label.new()
    hud_hp.position = Vector2(930,8)
    hud_hp.add_theme_font_size_override("font_size",18)
    bar.add_child(hud_hp)
    hud_ammo = Label.new()
    hud_ammo.position = Vector2(930,34)
    bar.add_child(hud_ammo)
    var face := TextureRect.new()
    face.texture = face_tex
    face.position = Vector2(710,4)
    face.size = Vector2(54,54)
    face.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    face.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    bar.add_child(face)
    var who := Label.new()
    who.text = "CAROLINA\nОХОТНИК"
    who.position = Vector2(770,8)
    bar.add_child(who)
    toast = Label.new()
    toast.position = Vector2(250,80)
    toast.size = Vector2(780,50)
    toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast.add_theme_font_size_override("font_size",20)
    layer.add_child(toast)
    var controls := preload("res://scripts/mobile_controls.gd").new()
    controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(controls)
    controls.move_changed.connect(_set_move)
    controls.look_changed.connect(_look)
    controls.fire_pressed.connect(_shoot)

func _set_move(v:Vector2) -> void:
    move_touch = v

func _move_squirrels(delta:float) -> void:
    for e in squirrels:
        if not e["alive"]: continue
        var s:Sprite3D = e["node"]
        var d := player.global_position - s.global_position
        d.y = 0
        if d.length() > 0.8 and d.length() < 6:
            var n := s.global_position + d.normalized() * delta * 1.0
            if _walkable(n.x,n.z): s.global_position = n
        if s.global_position.distance_to(player.global_position) < 0.68: hp = max(0,hp-12)

func _walkable(x:float,z:float) -> bool:
    var ix := int(floor(x)); var iz := int(floor(z))
    return ix>=0 and iz>=0 and ix<MAP_W and iz<MAP_H and MAP[iz][ix]==0

func _pickups() -> void:
    for a in acorns.duplicate():
        if is_instance_valid(a) and player.global_position.distance_to(a.global_position)<0.55:
            acorns.erase(a); a.queue_free(); found += 1; _say("ЖЁЛУДЬ НАЙДЕН. %d/%d" % [found,GOAL])
    for f in fake_cones.duplicate():
        if is_instance_valid(f) and player.global_position.distance_to(f.global_position)<0.55:
            fake_cones.erase(f); f.queue_free(); hp=max(0,hp-12); _say("Это не жёлудь. Это ШИШКА.")

func _shoot() -> void:
    if fire_timer>0 or ammo<=0: return
    ammo -= 1; fire_timer=0.18
    var o := camera.global_position
    var d := -camera.global_transform.basis.z
    var best = null; var best_dist := 99.0
    for e in squirrels:
        if not e["alive"]: continue
        var s:Sprite3D=e["node"]
        var to := s.global_position + Vector3(0,0.2,0) - o
        var dist := to.length()
        if dist>8: continue
        if d.dot(to.normalized()) < 0.985: continue
        var q := PhysicsRayQueryParameters3D.create(o,s.global_position+Vector3(0,0.2,0))
        q.exclude=[player.get_rid()]
        var hit := get_world_3d().direct_space_state.intersect_ray(q)
        if hit.is_empty() and dist<best_dist:
            best=e; best_dist=dist
    if best != null:
        best["hp"] -= 1
        if best["hp"] <= 0:
            best["alive"] = false
            var s:Sprite3D=best["node"]
            s.scale=Vector3(1,0.42,1); s.position.y=0.22
            _say("БЕЛКА ПОВЕРЖЕНА.")

func _say(t:String) -> void:
    toast.text=t; toast_timer=1.4

func _update_hud() -> void:
    if is_instance_valid(hud_hp):
        hud_hp.text="HP %d" % hp
        hud_ammo.text="AMMO %d" % ammo
        hud_acorns.text="УР. 1    ЖЁЛУДИ %d/%d" % [found,GOAL]
