# ACORN HUNTER — Godot Level 1 V4

Full Level 1 Godot 3D port. Includes intro screen, mobile movement/look/fire, HUD, weapon, audio, sky stars/moon, pickups, squirrels and collisions.

Build through the repository workflow that extracts this ZIP.
