extends Node3D

const MAP_W := 20
const MAP_H := 14
const SPEED := 4.2
const LOOK_SENS := 0.0045
const GOAL := 4
const PLAYER_RADIUS := 0.28
const MAP = [
 [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
 [1,0,0,0,0,0,1,1,1,0,0,0,1,1,0,0,0,0,0,1],
 [1,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,1],
 [1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1],
 [1,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1],
 [1,0,1,1,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1],
 [1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1],
 [1,0,0,0,1,1,1,0,1,0,1,1,1,0,0,0,0,1,0,1],
 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1],
 [1,0,0,1,1,1,0,0,1,1,1,0,0,0,0,0,0,1,0,1],
 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
 [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]
const ACORNS = [Vector2(5.5,2.5),Vector2(10.5,2.5),Vector2(14.5,3.5),Vector2(13.5,7.5)]
const TREES = [Vector2(3.5,2.5),Vector2(5.5,2.5),Vector2(10.5,2.5),Vector2(14.5,3.5),Vector2(3.5,6.5),Vector2(8.5,6.5),Vector2(13.5,7.5),Vector2(17.5,8.5),Vector2(5.5,11.5),Vector2(12.5,11.5)]
const SQUIRRELS = [Vector2(9.2,5.2),Vector2(16.3,6.7)]

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var world_env: WorldEnvironment = $WorldEnvironment

var grass = preload("res://assets/grass_tile.png")
var stone = preload("res://assets/stone_path_tile.png")
var wall_tex = [preload("res://assets/hedge_wall_0.png"),preload("res://assets/hedge_wall_1.png"),preload("res://assets/hedge_wall_2.png"),preload("res://assets/hedge_wall_3.png")]
var tree_tex = preload("res://assets/oak_tree.png")
var acorn_tex = preload("res://assets/acorn.png")
var squirrel_tex = preload("res://assets/squirrel.png")
var face_tex = preload("res://assets/carolina_face.png")
var music_stream = preload("res://assets/acorn_music.mp3")
var hit_stream = preload("res://assets/squirrel_hit.wav")
var step1_stream = preload("res://assets/footstep1.wav")
var step2_stream = preload("res://assets/footstep2.wav")
var gun_stream = preload("res://assets/gunshot.wav")
var pickup_stream = preload("res://assets/pickup.wav")
var damage_stream = preload("res://assets/damage.wav")

var yaw := 0.0
var pitch := -0.035
var hp := 100
var ammo := 35
var found := 0
var game_started := false
var acorns: Array[Node3D] = []
var squirrels: Array[Dictionary] = []
var fake_cones: Array[Node3D] = []
var hud_acorns: Label
var hud_hp: Label
var hud_ammo: Label
var toast: Label
var intro: Control
var intro_layer: CanvasLayer
var ui_layer: CanvasLayer
var intro_button: Button
var weapon_root: Node3D
var muzzle: MeshInstance3D
var fire_timer := 0.0
var toast_timer := 0.0
var move_touch := Vector2.ZERO
var step_timer := 0.0
var walk_phase := 0.0
var sky_root: Node3D
var moon: Sprite3D
var stars: Array[Sprite3D] = []
var rng := RandomNumberGenerator.new()

func _ready() -> void:
    rng.seed = 1337
    _setup_world()
    _build_floor_and_walls()
    _build_objects()
    _build_weapon()
    _build_hud()
    _build_intro()
    _build_sky_objects()
    _start_music()
    _update_hud()

func _setup_world() -> void:
    world_env.environment.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var mat := ProceduralSkyMaterial.new()
    mat.sky_top_color = Color("061020")
    mat.sky_horizon_color = Color("223d58")
    mat.ground_bottom_color = Color("020507")
    mat.ground_horizon_color = Color("16251f")
    mat.sun_angle_max = 8.0
    mat.sun_curve = 0.04
    sky.sky_material = mat
    world_env.environment.sky = sky
    world_env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    world_env.environment.ambient_light_energy = 0.62
    world_env.environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC

func _start_music() -> void:
    var p := AudioStreamPlayer.new()
    p.stream = music_stream
    p.autoplay = true
    p.volume_db = -9.0
    add_child(p)
    p.play()

func _process(delta: float) -> void:
    fire_timer = max(0.0, fire_timer - delta)
    toast_timer = max(0.0, toast_timer - delta)
    if toast_timer <= 0.0 and is_instance_valid(toast): toast.text = ""
    if not game_started:
        return
    _move_player(delta)
    _move_squirrels(delta)
    _pickups()
    _update_hud()
    _update_weapon(delta)
    _update_sky()

func _unhandled_input(e: InputEvent) -> void:
    if not game_started:
        return
    if e is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        _look(e.relative)
    elif e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT and e.pressed:
        # Desktop only. Android touch is handled exclusively by mobile_controls.gd.
        if not OS.has_feature("mobile"):
            _shoot()

func _look(d: Vector2) -> void:
    yaw -= d.x * LOOK_SENS
    pitch = clamp(pitch - d.y * LOOK_SENS, -1.05, 1.05)
    player.rotation.y = yaw
    camera.rotation.x = pitch

func _move_player(delta: float) -> void:
    var k := Input.get_vector("move_left","move_right","move_forward","move_back")
    var v := move_touch if move_touch.length() > 0.05 else k
    var forward := -player.global_transform.basis.z
    var right := player.global_transform.basis.x
    var dir := right * v.x + forward * v.y
    dir.y = 0.0
    if dir.length() > 1.0: dir = dir.normalized()
    player.velocity = dir * SPEED
    player.move_and_slide()
    player.global_position.y = 0.92
    if dir.length() > 0.1:
        step_timer -= delta
        walk_phase += delta * 11.0
        camera.position.y = 0.57 + sin(walk_phase) * 0.018
        if step_timer <= 0.0:
            _play_one_shot(step1_stream if int(walk_phase) % 2 == 0 else step2_stream, -14.0)
            step_timer = 0.42
    else:
        camera.position.y = lerp(camera.position.y, 0.57, min(1.0, delta*8.0))

func _build_floor_and_walls() -> void:
    for y in range(MAP_H):
        for x in range(MAP_W):
            if MAP[y][x] == 0:
                _make_floor(x,y)
            else:
                _make_wall(x,y)

func _make_path_cell(x:int,y:int) -> void:
    if not _walkable_cell(x,y): return
    var m:=MeshInstance3D.new()
    var p:=PlaneMesh.new(); p.size=Vector2(0.82,0.82); m.mesh=p
    m.position=Vector3(x+0.5,0.006,y+0.5); m.material_override=_mat(stone); m.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF; add_child(m)

func _walkable_cell(x:int,y:int)->bool:
    return x>=0 and y>=0 and x<MAP_W and y<MAP_H and MAP[y][x]==0

func _mat(texture: Texture2D) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_texture = texture
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    m.roughness = 1.0
    return m

func _make_floor(x:int,y:int) -> void:
    var m := MeshInstance3D.new()
    var p := PlaneMesh.new()
    p.size = Vector2(1.0,1.0)
    p.subdivide_width = 0
    p.subdivide_depth = 0
    m.mesh = p
    m.position = Vector3(x+0.5,0,y+0.5)
    m.material_override = _mat(grass)
    m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(m)

func _make_wall(x:int,y:int) -> void:
    var body := StaticBody3D.new()
    body.position = Vector3(x+0.5,1.2,y+0.5)
    var m := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = Vector3(1.0,2.4,1.0)
    m.mesh = b
    m.material_override = _mat(wall_tex[(x*31+y*17)%wall_tex.size()])
    body.add_child(m)
    var cs := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(1,2.4,1)
    cs.shape = shape
    body.add_child(cs)
    add_child(body)

func _build_objects() -> void:
    # A simple stone path follows the main corridors without replacing the grass world.
    var path_cells=[Vector2i(1,1),Vector2i(2,1),Vector2i(3,1),Vector2i(4,1),Vector2i(5,1),Vector2i(6,1),Vector2i(7,1),Vector2i(8,1),Vector2i(9,1),Vector2i(10,1),Vector2i(11,1),Vector2i(12,1),Vector2i(13,1),Vector2i(14,1),Vector2i(15,1),Vector2i(16,1),Vector2i(17,1),Vector2i(18,1),Vector2i(13,2),Vector2i(13,3),Vector2i(13,4),Vector2i(13,5),Vector2i(13,6),Vector2i(13,7)]
    for c in path_cells: _make_path_cell(c.x,c.y)
    for p in TREES:
        if _walkable(p.x,p.y): _tree(p)
    for p in ACORNS:
        if _walkable(p.x,p.y): _acorn(p)
    _fake(Vector2(3.84,6.84))
    for p in SQUIRRELS:
        if _walkable(p.x,p.y): _squirrel(p)

func _safe_object_pos(p:Vector2, clearance:float)->Vector2:
    if _walkable(p.x,p.y) and not _near_wall(p.x,p.y,clearance): return p
    var best:=p
    var best_d:=999.0
    for iy in range(-4,5):
        for ix in range(-4,5):
            var q:=p+Vector2(ix,iy)*0.12
            if _walkable(q.x,q.y) and not _near_wall(q.x,q.y,clearance):
                var d:=q.distance_to(p)
                if d<best_d: best=q; best_d=d
    return best

func _sprite(tex:Texture2D, pos:Vector3, px:float, scale:=Vector3.ONE) -> Sprite3D:
    var s := Sprite3D.new()
    s.texture = tex
    s.pixel_size = px
    s.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    s.position = pos
    s.scale = scale
    s.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    s.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
    s.no_depth_test = false
    add_child(s)
    return s

func _tree(p:Vector2) -> void:
    p=_safe_object_pos(p,0.36)
    var s := _sprite(tree_tex,Vector3(p.x,1.4,p.y),0.010)
    s.render_priority = 0

func _acorn(p:Vector2) -> void:
    p=_safe_object_pos(p,0.22)
    var s := _sprite(acorn_tex,Vector3(p.x,0.22,p.y),0.0037)
    s.scale = Vector3(1.0,1.0,1.0)
    acorns.append(s)

func _fake(p:Vector2) -> void:
    if not _walkable(p.x,p.y): return
    var m := MeshInstance3D.new()
    var cone := CylinderMesh.new()
    cone.top_radius = 0.03
    cone.bottom_radius = 0.16
    cone.height = 0.30
    cone.radial_segments = 8
    m.mesh = cone
    m.position = Vector3(p.x,0.15,p.y)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color("654126")
    mat.roughness = 1
    m.material_override = mat
    add_child(m)
    fake_cones.append(m)

func _squirrel(p:Vector2) -> void:
    p=_safe_object_pos(p,0.32)
    var s := _sprite(squirrel_tex,Vector3(p.x,0.60,p.y),0.0056)
    squirrels.append({"node":s,"hp":2,"alive":true,"phase":rng.randf_range(0,6.28)})

func _build_weapon() -> void:
    weapon_root = Node3D.new()
    weapon_root.position = Vector3(0.02,-0.40,-0.82)
    camera.add_child(weapon_root)
    var body := MeshInstance3D.new()
    var b := BoxMesh.new(); b.size = Vector3(0.34,0.20,0.72); body.mesh=b
    body.position = Vector3(0,0,0.10)
    body.material_override = _weapon_mat(Color("17151a")); weapon_root.add_child(body)
    var stock := MeshInstance3D.new()
    var sb := BoxMesh.new(); sb.size=Vector3(0.24,0.25,0.34); stock.mesh=sb
    stock.position=Vector3(0,-0.03,0.47); stock.material_override=_weapon_mat(Color("3a2a24")); weapon_root.add_child(stock)
    var barrel := MeshInstance3D.new()
    var cy := CylinderMesh.new(); cy.top_radius=0.045; cy.bottom_radius=0.055; cy.height=0.62; cy.radial_segments=8; barrel.mesh=cy
    barrel.rotation_degrees=Vector3(90,0,0); barrel.position=Vector3(0,0,-0.52); barrel.material_override=_weapon_mat(Color("2b2b31")); weapon_root.add_child(barrel)
    var sight := MeshInstance3D.new()
    var sy:=BoxMesh.new(); sy.size=Vector3(0.06,0.10,0.18); sight.mesh=sy; sight.position=Vector3(0,0.15,-0.22); sight.material_override=_weapon_mat(Color("45414a")); weapon_root.add_child(sight)
    muzzle = MeshInstance3D.new()
    var mb:=SphereMesh.new(); mb.radius=0.11; mb.height=0.22; muzzle.mesh=mb; muzzle.position=Vector3(0,0,-0.83)
    var mm:=StandardMaterial3D.new(); mm.albedo_color=Color("ffd35a"); mm.emission_enabled=true; mm.emission=Color("ffb000"); mm.emission_energy_multiplier=5.0; muzzle.material_override=mm; muzzle.visible=false; weapon_root.add_child(muzzle)

func _weapon_mat(c:Color)->StandardMaterial3D:
    var m:=StandardMaterial3D.new(); m.albedo_color=c; m.roughness=0.65; return m

func _update_weapon(delta:float) -> void:
    if fire_timer > 0.0:
        weapon_root.position.y = lerp(weapon_root.position.y,-0.35,delta*24.0)
        weapon_root.position.z = lerp(weapon_root.position.z,-0.88,delta*24.0)
        muzzle.visible = true
    else:
        weapon_root.position.y = lerp(weapon_root.position.y,-0.40,delta*14.0)
        weapon_root.position.z = lerp(weapon_root.position.z,-0.82,delta*14.0)
        muzzle.visible = false

func _build_hud() -> void:
    ui_layer=CanvasLayer.new(); ui_layer.layer=20; add_child(ui_layer)
    var bar:=ColorRect.new(); bar.color=Color(0.015,0.055,0.05,0.94); bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE); bar.custom_minimum_size=Vector2(0,66); ui_layer.add_child(bar)
    var title:=Label.new(); title.text="ОПЕРАЦИЯ «ЖЁЛУДЬ»"; title.position=Vector2(18,8); title.add_theme_font_size_override("font_size",21); bar.add_child(title)
    hud_acorns=Label.new(); hud_acorns.position=Vector2(18,39); hud_acorns.add_theme_font_size_override("font_size",14); bar.add_child(hud_acorns)
    var face:=TextureRect.new(); face.texture=face_tex; face.position=Vector2(715,5); face.size=Vector2(52,52); face.expand_mode=TextureRect.EXPAND_IGNORE_SIZE; face.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED; bar.add_child(face)
    var who:=Label.new(); who.text="CAROLINA\nОХОТНИК"; who.position=Vector2(775,8); who.add_theme_font_size_override("font_size",13); bar.add_child(who)
    hud_hp=Label.new(); hud_hp.position=Vector2(1010,9); hud_hp.add_theme_font_size_override("font_size",17); bar.add_child(hud_hp)
    hud_ammo=Label.new(); hud_ammo.position=Vector2(1010,38); hud_ammo.add_theme_font_size_override("font_size",14); bar.add_child(hud_ammo)
    toast=Label.new(); toast.position=Vector2(260,82); toast.size=Vector2(760,48); toast.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; toast.add_theme_font_size_override("font_size",19); ui_layer.add_child(toast)
    var cross:=Label.new(); cross.text="+"; cross.position=Vector2(634,337); cross.add_theme_font_size_override("font_size",20); cross.modulate=Color(1,1,1,0.78); ui_layer.add_child(cross)
    var controls:=preload("res://scripts/mobile_controls.gd").new(); controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); controls.visible=false; ui_layer.add_child(controls); controls.name="MobileControls"; controls.move_changed.connect(_set_move); controls.look_changed.connect(_look); controls.fire_pressed.connect(_shoot); controls.set_process_input(true)
    ui_layer.set_meta("mobile_controls",controls)

func _build_intro() -> void:
    intro_layer=CanvasLayer.new(); intro_layer.layer=100; add_child(intro_layer)
    intro=Control.new(); intro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); intro.mouse_filter=Control.MOUSE_FILTER_STOP; intro_layer.add_child(intro)
    var bg:=ColorRect.new(); bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); bg.color=Color(0.015,0.025,0.035,0.97); intro.add_child(bg)
    var title:=Label.new(); title.text="ОПЕРАЦИЯ «ЖЁЛУДЬ»"; title.set_anchors_preset(Control.PRESET_CENTER); title.position=Vector2(-320,-180); title.size=Vector2(640,70); title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",38); intro.add_child(title)
    var sub:=Label.new(); sub.text="CAROLINA • ОХОТНИК\nЧетыре настоящих жёлудя. Одна очень долгая охота."; sub.set_anchors_preset(Control.PRESET_CENTER); sub.position=Vector2(-430,-92); sub.size=Vector2(860,90); sub.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; sub.add_theme_font_size_override("font_size",19); sub.modulate=Color(0.8,0.86,0.88,1); intro.add_child(sub)
    intro_button=Button.new(); intro_button.text="НАЧАТЬ ОХОТУ"; intro_button.set_anchors_preset(Control.PRESET_CENTER); intro_button.position=Vector2(-150,45); intro_button.size=Vector2(300,78); intro_button.add_theme_font_size_override("font_size",22); intro_button.pressed.connect(_start_game); intro.add_child(intro_button)
    var hint:=Label.new(); hint.text="Собери 4 жёлудя. Не перепутай их с шишками."; hint.set_anchors_preset(Control.PRESET_CENTER); hint.position=Vector2(-430,160); hint.size=Vector2(860,40); hint.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; hint.modulate=Color(0.65,0.7,0.72,1); intro.add_child(hint)

func _start_game() -> void:
    if game_started: return
    game_started=true
    if is_instance_valid(intro_layer): intro_layer.queue_free()
    intro=null; intro_layer=null
    var controls:=_find_mobile_controls()
    if controls: controls.visible=true
    _say("ОХОТА НАЧАЛАСЬ. УДАЧИ, КАРОЛИНА.")

func _find_mobile_controls()->Control:
    if is_instance_valid(ui_layer):
        var c=ui_layer.get_meta("mobile_controls",null)
        if c is Control: return c
    return null

func _set_move(v:Vector2)->void: move_touch=v

func _move_squirrels(delta:float)->void:
    for e in squirrels:
        if not e["alive"]: continue
        var s:Sprite3D=e["node"]
        var d:=player.global_position-s.global_position; d.y=0
        if d.length()>0.9 and d.length()<7.0:
            var speed:=1.45
            var n:=s.global_position+d.normalized()*delta*speed
            if _walkable(n.x,n.z) and not _near_wall(n.x,n.z,0.22): s.global_position=n
        if s.global_position.distance_to(player.global_position)<0.70:
            hp=max(0,hp-12)
            _play_one_shot(damage_stream,-7.0)
            _say("БЕЛКА КУСАЕТСЯ!")

func _near_wall(x:float,z:float,r:float)->bool:
    for yy in range(int(floor(z-r)),int(floor(z+r))+1):
        for xx in range(int(floor(x-r)),int(floor(x+r))+1):
            if yy>=0 and xx>=0 and yy<MAP_H and xx<MAP_W and MAP[yy][xx]==1:
                var minx=float(xx); var maxx=float(xx+1); var minz=float(yy); var maxz=float(yy+1)
                var qx=clamp(x,minx,maxx); var qz=clamp(z,minz,maxz)
                if Vector2(x-qx,z-qz).length()<r: return true
    return false

func _walkable(x:float,z:float)->bool:
    var ix:=int(floor(x)); var iz:=int(floor(z))
    return ix>=0 and iz>=0 and ix<MAP_W and iz<MAP_H and MAP[iz][ix]==0 and not _near_wall(x,z,PLAYER_RADIUS)

func _pickups()->void:
    for a in acorns.duplicate():
        if is_instance_valid(a) and player.global_position.distance_to(a.global_position)<0.62:
            acorns.erase(a); a.queue_free(); found+=1; _play_one_shot(pickup_stream,-4.0); _say("ЖЁЛУДЬ НАЙДЕН. %d/%d" % [found,GOAL])
            if found>=GOAL: _complete_level()
    for f in fake_cones.duplicate():
        if is_instance_valid(f) and player.global_position.distance_to(f.global_position)<0.55:
            fake_cones.erase(f); f.queue_free(); hp=max(0,hp-12); _play_one_shot(damage_stream,-5.0); _say("ЭТО НЕ ЖЁЛУДЬ. ЭТО ШИШКА.")

func _shoot()->void:
    if not game_started or fire_timer>0.0 or ammo<=0: return
    ammo-=1; fire_timer=0.16; _play_one_shot(gun_stream,-3.0)
    var o:=camera.global_position; var d:=-camera.global_transform.basis.z
    var best=null; var best_dist:=99.0
    for e in squirrels:
        if not e["alive"]: continue
        var s:Sprite3D=e["node"]; var to:=s.global_position+Vector3(0,0.28,0)-o; var dist:=to.length()
        if dist>9: continue
        if d.dot(to.normalized())<0.985: continue
        var q:=PhysicsRayQueryParameters3D.create(o,s.global_position+Vector3(0,0.28,0)); q.exclude=[player.get_rid()]
        var hit:=get_world_3d().direct_space_state.intersect_ray(q)
        if hit.is_empty() and dist<best_dist: best=e; best_dist=dist
    if best!=null:
        best["hp"]-=1; _play_one_shot(hit_stream,-5.0)
        if best["hp"]<=0:
            best["alive"]=false; var s:Sprite3D=best["node"]; s.scale=Vector3(1.0,0.45,1.0); s.position.y=0.20; _say("БЕЛКА ПОВЕРЖЕНА.")

func _complete_level()->void:
    game_started=false
    var controls:=_find_mobile_controls()
    if controls: controls.visible=false
    var layer:=CanvasLayer.new(); layer.layer=90; add_child(layer)
    var panel:=ColorRect.new(); panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); panel.color=Color(0.015,0.025,0.035,0.92); layer.add_child(panel)
    var title:=Label.new(); title.set_anchors_preset(Control.PRESET_CENTER); title.position=Vector2(-430,-130); title.size=Vector2(860,70); title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.text="ОПЕРАЦИЯ ВЫПОЛНЕНА"; title.add_theme_font_size_override("font_size",34); panel.add_child(title)
    var sub:=Label.new(); sub.set_anchors_preset(Control.PRESET_CENTER); sub.position=Vector2(-430,-35); sub.size=Vector2(860,100); sub.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; sub.text="4/4 ЖЁЛУДЕЙ НАЙДЕНЫ\nКаролина, ты это сделала."; sub.add_theme_font_size_override("font_size",22); panel.add_child(sub)

func _play_one_shot(stream:AudioStream, db:float)->void:
    var p:=AudioStreamPlayer.new(); p.stream=stream; p.volume_db=db; add_child(p); p.play(); p.finished.connect(p.queue_free)

func _say(t:String)->void: toast.text=t; toast_timer=1.5

func _update_hud()->void:
    if is_instance_valid(hud_hp): hud_hp.text="HP %d"%hp; hud_ammo.text="AMMO %d"%ammo; hud_acorns.text="УР. 1    ЖЁЛУДИ %d/%d"%[found,GOAL]

func _build_sky_objects()->void:
    sky_root=Node3D.new(); sky_root.name="SkyObjects"; add_child(sky_root)
    moon=Sprite3D.new(); moon.texture=preload("res://assets/moon.png"); moon.pixel_size=0.025; moon.billboard=BaseMaterial3D.BILLBOARD_ENABLED; moon.position=Vector3(0,9,-26); moon.scale=Vector3(1.7,1.7,1.7); moon.texture_filter=BaseMaterial3D.TEXTURE_FILTER_NEAREST; moon.modulate=Color(1,1,1,0.96); sky_root.add_child(moon)
    for i in range(90):
        var a:=rng.randf_range(0,TAU); var elev:=rng.randf_range(0.10,1.15); var r:=rng.randf_range(18,32)
        var pos:=Vector3(cos(a)*cos(elev)*r,sin(elev)*r,sin(a)*cos(elev)*r)
        var st:=Sprite3D.new(); st.texture=preload("res://assets/star.png"); st.pixel_size=0.0022; st.billboard=BaseMaterial3D.BILLBOARD_ENABLED; st.position=pos; st.texture_filter=BaseMaterial3D.TEXTURE_FILTER_NEAREST; st.modulate=Color(0.75+rng.randf()*0.25,0.78+rng.randf()*0.22,0.9+rng.randf()*0.1,0.75+rng.randf()*0.25); sky_root.add_child(st); stars.append(st)

func _update_sky()->void:
    if sky_root:
        sky_root.global_position=player.global_position
        sky_root.rotation.y=yaw*0.14
        sky_root.rotation.x=pitch*0.08
