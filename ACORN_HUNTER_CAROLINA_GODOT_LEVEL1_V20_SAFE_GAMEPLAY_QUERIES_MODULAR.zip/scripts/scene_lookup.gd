class_name SceneLookup
extends RefCounted

static func mesh_node(root: Node, node_name: String) -> MeshInstance3D:
    return root.get_node_or_null(node_name) as MeshInstance3D
