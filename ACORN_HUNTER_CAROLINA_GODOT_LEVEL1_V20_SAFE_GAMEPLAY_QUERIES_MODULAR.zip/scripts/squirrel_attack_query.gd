class_name SquirrelAttackQuery
extends RefCounted

static func can_attack(distance: float, stunned: bool, damage_cooldown: float, attack_distance: float) -> bool:
    return not stunned and distance <= attack_distance and damage_cooldown <= 0.0
