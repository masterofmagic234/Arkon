extends Node3D

# ACORN HUNTER — clean Godot rebuild
# Level 1 only. Same soul as the old Android prototype, new implementation.

const MAP_W := 20
const MAP_H := 14
const WALL_H := 2.15
const PLAYER_SPEED := 2.15
const TURN_SPEED := 2.2
const FOV := 68.0

const MAP := [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,1,1,1,0,0,0,1,1,0,0,0,0,0,1],
    [1,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,1],
    [1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1],
    [1,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1],
    [1,0,1,1,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1],
    [1,0,0,0,1,1,1,0,1,0,1,1,1,0,0,0,0,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1],
    [1,0,0,1,1,1,0,0,1,1,1,0,0,0,0,0,0,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

const ACORN_POS := [Vector2(5.96,2.60), Vector2(10.03,2.78), Vector2(14.97,3.46), Vector2(13.29,7.72)]
const TREE_POS := [
    Vector3(5.5,0,2.5), Vector3(10.5,0,2.5), Vector3(14.5,0,3.5),
    Vector3(3.5,0,6.5), Vector3(8.5,0,6.5), Vector3(13.5,0,7.5),
    Vector3(17.5,0,8.5), Vector3(5.5,0,11.5), Vector3(12.5,0,11.5)
]
const SQUIRREL_POS := [Vector2(9.2,5.2), Vector2(16.3,6.7)]
const FAKE_POS := [Vector2(3.84,6.84)]

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var world_root: Node3D = $GameRoot
@onready var title_layer: Control = $UI/Interface/TitleLayer
@onready var game_layer: Control = $UI/Interface/GameLayer
@onready var victory_layer: Control = $UI/Interface/VictoryLayer
@onready var start_button: Button = $UI/Interface/TitleLayer/StartButton
@onready var fire_button: Button = $UI/Interface/GameLayer/FireButton
@onready var mute_button: Button = $UI/Interface/GameLayer/MuteButton
@onready var status_label: Label = $UI/Interface/GameLayer/Status
@onready var hp_ammo_label: Label = $UI/Interface/GameLayer/HPAmmo
@onready var carolina: TextureRect = $UI/Interface/GameLayer/Carolina
@onready var weapon: TextureRect = $UI/Interface/GameLayer/Weapon
@onready var toast_panel: PanelContainer = $UI/Interface/GameLayer/Toast
@onready var toast_label: Label = $UI/Interface/GameLayer/Toast/Text
@onready var minimap: Control = $UI/Interface/GameLayer/MiniMap
@onready var game_ui: Control = $UI/Interface/GameLayer
@onready var victory_again: Button = $UI/Interface/VictoryLayer/Again

var grass_tex = preload("res://assets/grass.png")
var stone_tex = preload("res://assets/stone.png")
var hedge_tex = preload("res://assets/hedge_wall_0.png")
var oak_tex = preload("res://assets/oak_tree.png")
var squirrel_tex = preload("res://assets/squirrel.png")
var acorn_tex = preload("res://assets/acorn.png")
var pine_tex = preload("res://assets/pine_tree.png")
var carolina_tex = preload("res://assets/carolina_face.png")
var moon_tex = preload("res://assets/moon.png")
var star_tex = preload("res://assets/star.png")
var weapon_tex = preload("res://assets/weapon.png")

var music = preload("res://assets/acorn_music.mp3")
var foot1 = preload("res://assets/footstep1.wav")
var foot2 = preload("res://assets/footstep2.wav")
var squirrel_hit = preload("res://assets/squirrel_hit.wav")
var shoot_sound = preload("res://assets/shoot.wav")

var audio_music: AudioStreamPlayer
var audio_fx: AudioStreamPlayer

var playing := false
var starting := false
var muted := false
var hp := 100
var ammo := 35
var found := 0
var yaw := 0.0
var joystick := Vector2.ZERO
var joystick_active := false
var look_active := false
var last_touch := Vector2.ZERO
var fire_cooldown := 0.0
var foot_timer := 0.0
var bob := 0.0
var stars_root: Node3D
var acorns: Array[Node3D] = []
var squirrels: Array[Dictionary] = []
var trees: Array[Node3D] = []
var toast_time := 0.0
var path_cells: Dictionary = {}
var keys_down: Dictionary = {}

func _ready() -> void:
    # Keep the camera intentionally level: Wolfenstein-style, no pitch control.
    camera.rotation = Vector3.ZERO
    camera.fov = FOV
    carolina.texture = carolina_tex
    weapon.texture = weapon_tex
    weapon.visible = false
    # StartButton is connected in main.tscn. Do not connect it again at runtime.
    fire_button.pressed.connect(_fire)
    mute_button.pressed.connect(_toggle_music)
    victory_again.pressed.connect(_start_game)
    minimap.main = self
    game_ui.main = self
    _setup_audio()
    _setup_stars()
    _build_level()
    _show_title()

func _setup_audio() -> void:
    audio_music = AudioStreamPlayer.new()
    audio_music.stream = music
    audio_music.volume_db = -7.0
    add_child(audio_music)
    audio_fx = AudioStreamPlayer.new()
    add_child(audio_fx)

func _setup_stars() -> void:
    stars_root = Node3D.new()
    stars_root.name = "NightSkyObjects"
    add_child(stars_root)
    var moon := Sprite3D.new()
    moon.texture = moon_tex
    moon.pixel_size = 0.0022
    moon.position = Vector3(-7.5,5.8,-13.0)
    moon.material_override = _sprite_material(true)
    stars_root.add_child(moon)
    var rng := RandomNumberGenerator.new()
    rng.seed = 1777
    for i in range(85):
        var s := Sprite3D.new()
        s.texture = star_tex
        s.pixel_size = rng.randf_range(0.002,0.005)
        var a := rng.randf_range(-3.0,3.0)
        var d := rng.randf_range(11.0,22.0)
        var y := rng.randf_range(2.5,7.5)
        s.position = Vector3(cos(a)*d,y,sin(a)*d)
        s.material_override = _sprite_material(true)
        stars_root.add_child(s)

func _sprite_material(unshaded := false) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED if unshaded else BaseMaterial3D.SHADING_MODE_PER_PIXEL
    m.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    return m

func _mat(tex: Texture2D, tint := Color.WHITE, unshaded := false) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_texture = tex
    m.albedo_color = tint
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED if unshaded else BaseMaterial3D.SHADING_MODE_PER_PIXEL
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    return m

func _build_level() -> void:
    _build_floor()
    _build_walls()
    _build_path()
    for p in TREE_POS:
        _spawn_tree(p)
    for p in ACORN_POS:
        _spawn_acorn(p)
    for p in SQUIRREL_POS:
        _spawn_squirrel(p)
    for p in FAKE_POS:
        _spawn_fake(p)
    _say("Парк открыт. Ищи дубы — жёлуди рядом.")

func _build_floor() -> void:
    var body := StaticBody3D.new()
    body.name = "Ground"
    var mesh := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(MAP_W, MAP_H)
    plane.material = _mat(grass_tex)
    mesh.mesh = plane
    mesh.position = Vector3(MAP_W/2.0, -0.03, MAP_H/2.0)
    body.add_child(mesh)
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(MAP_W,0.1,MAP_H)
    shape.shape = box
    shape.position = Vector3(MAP_W/2.0,-0.08,MAP_H/2.0)
    body.add_child(shape)
    world_root.add_child(body)

func _build_walls() -> void:
    for y in range(MAP_H):
        for x in range(MAP_W):
            if MAP[y][x] == 1:
                _spawn_wall(x,y)

func _spawn_wall(x:int,y:int) -> void:
    var body := StaticBody3D.new()
    body.name = "Hedge_%d_%d" % [x,y]
    body.position = Vector3(x+0.5, WALL_H/2.0, y+0.5)
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(1.0,WALL_H,1.0)
    box.material = _mat(hedge_tex)
    mesh.mesh = box
    body.add_child(mesh)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(1.0,WALL_H,1.0)
    collision.shape = shape
    body.add_child(collision)
    world_root.add_child(body)

func _build_path() -> void:
    path_cells.clear()
    var starts := [Vector2i(1,1)]
    var goals := []
    for p in ACORN_POS:
        goals.append(Vector2i(int(p.x),int(p.y)))
    for goal in goals:
        var prev := {}
        var q:Array[Vector2i] = []
        var start := starts[0]
        q.append(start); prev[start] = start
        var qi := 0
        while qi < q.size():
            var cur := q[qi]; qi += 1
            if cur == goal: break
            for d in [Vector2i(1,0),Vector2i(-1,0),Vector2i(0,1),Vector2i(0,-1)]:
                var n := cur + d
                if n.x < 0 or n.y < 0 or n.x >= MAP_W or n.y >= MAP_H: continue
                if MAP[n.y][n.x] == 1 or prev.has(n): continue
                prev[n] = cur; q.append(n)
        if not prev.has(goal): continue
        var cur := goal
        while cur != start:
            path_cells[cur] = true
            cur = prev[cur]
        path_cells[start] = true
    for cell in path_cells.keys():
        var x:int = cell.x; var y:int = cell.y
        var mesh := MeshInstance3D.new()
        var plane := BoxMesh.new()
        plane.size = Vector3(0.92,0.025,0.92)
        plane.material = _mat(stone_tex)
        mesh.mesh = plane
        mesh.position = Vector3(x+0.5,0.012,y+0.5)
        world_root.add_child(mesh)

func _spawn_tree(pos:Vector3) -> void:
    var s := Sprite3D.new()
    s.texture = oak_tex
    s.pixel_size = 0.008
    s.position = pos + Vector3(0,1.05,0)
    s.scale = Vector3(1.45,1.45,1.45)
    s.material_override = _sprite_material(false)
    world_root.add_child(s)
    trees.append(s)

func _spawn_acorn(p:Vector2) -> void:
    var s := Sprite3D.new()
    s.texture = acorn_tex
    s.pixel_size = 0.006
    s.position = Vector3(p.x,0.22,p.y)
    s.scale = Vector3(1.1,1.1,1.1)
    s.material_override = _sprite_material(false)
    world_root.add_child(s)
    acorns.append(s)

func _spawn_fake(p:Vector2) -> void:
    var s := Sprite3D.new()
    s.texture = pine_tex
    s.pixel_size = 0.0065
    s.position = Vector3(p.x,0.30,p.y)
    s.scale = Vector3(0.9,0.9,0.9)
    s.material_override = _sprite_material(false)
    world_root.add_child(s)
    s.set_meta("fake",true)

func _spawn_squirrel(p:Vector2) -> void:
    var s := Sprite3D.new()
    s.texture = squirrel_tex
    s.pixel_size = 0.009
    s.position = Vector3(p.x,0.58,p.y)
    s.scale = Vector3(1.0,1.0,1.0)
    s.material_override = _sprite_material(false)
    world_root.add_child(s)
    squirrels.append({"node":s,"pos":p,"hp":2,"stunned":0.0,"alive":true,"dead":false,"stars":[]})

func _show_title() -> void:
    playing = false
    title_layer.visible = true
    game_layer.visible = false
    victory_layer.visible = false
    weapon.visible = false
    start_button.grab_focus()

func _on_start_pressed() -> void:
    _start_game()

func _on_start_button_down() -> void:
    # Start on button-down for the mobile path. This avoids depending on a
    # later synthetic mouse-release event from Android touch emulation.
    _start_game()

func _start_game() -> void:
    if playing or starting:
        return
    starting = true
    playing = true
    title_layer.visible = false
    game_layer.visible = true
    victory_layer.visible = false
    weapon.visible = true
    hp = 100
    ammo = 35
    found = 0
    player.global_position = Vector3(1.5,0.9,1.5)
    yaw = 0.0
    player.rotation.y = 0.0
    _reset_items()
    if not muted:
        audio_music.play()
    _say("Операция началась. Найди жёлуди.")
    starting = false

func _reset_items() -> void:
    # Reset every piece of mutable gameplay state so "ЕЩЁ РАЗ" is a true fresh run.
    for i in acorns.size():
        acorns[i].visible = true
        acorns[i].set_meta("collected",false)
    for child in world_root.get_children():
        if child is Sprite3D and child.has_meta("fake"):
            child.visible = true
    for i in range(squirrels.size()):
        var e:Dictionary = squirrels[i]
        var s:Sprite3D = e["node"]
        var start_pos:Vector2 = SQUIRREL_POS[i]
        s.visible = true
        s.position = Vector3(start_pos.x,0.58,start_pos.y)
        s.scale = Vector3.ONE
        s.rotation = Vector3.ZERO
        e["pos"] = start_pos
        e["hp"] = 2
        e["stunned"] = 0.0
        e["alive"] = true
        e["dead"] = false
        for star in e["stars"]:
            if is_instance_valid(star): star.queue_free()
        e["stars"] = []
    squirrels = squirrels
    player.velocity = Vector3.ZERO
    joystick = Vector2.ZERO
    joystick_active = false
    look_active = false
    last_touch = Vector2.ZERO
    fire_cooldown = 0.0
    foot_timer = 0.0
    bob = 0.0
    toast_time = 0.0

func _physics_process(delta:float) -> void:
    if not playing:
        return
    _update_input(delta)
    _update_squirrels(delta)
    _check_items()
    fire_cooldown = max(0.0,fire_cooldown-delta)
    toast_time = max(0.0,toast_time-delta)
    if toast_time <= 0.0:
        toast_panel.visible = false
    _update_hud()

func _update_input(delta:float) -> void:
    var forward := joystick.y
    var turn := joystick.x
    if keys_down.get(KEY_W,false) or keys_down.get(KEY_UP,false): forward = 1.0
    if keys_down.get(KEY_S,false) or keys_down.get(KEY_DOWN,false): forward = -1.0
    if keys_down.get(KEY_A,false) or keys_down.get(KEY_LEFT,false): turn = -1.0
    if keys_down.get(KEY_D,false) or keys_down.get(KEY_RIGHT,false): turn = 1.0
    if keys_down.get(KEY_SPACE,false): _fire()
    player.rotation.y -= turn * TURN_SPEED * delta
    yaw = player.rotation.y
    var dir := Vector3(-sin(player.rotation.y),0,-cos(player.rotation.y))
    var strafe := Vector3(cos(player.rotation.y),0,-sin(player.rotation.y))
    var velocity := (dir*forward + strafe*0.0) * PLAYER_SPEED
    if abs(forward) > 0.05:
        bob += delta*10.0
        foot_timer -= delta
        if foot_timer <= 0.0:
            _footstep()
            foot_timer = 0.28
    else:
        foot_timer = 0.0
    velocity.y = 0.0
    player.velocity = velocity
    player.move_and_slide()
    # Camera remains perfectly level; no vertical look.
    camera.rotation.x = 0.0
    camera.rotation.z = 0.0

func _input(event:InputEvent) -> void:
    # GUI controls must receive touch/mouse input before gameplay fallback.
    # Godot processes _input() before the Control GUI stage, so handling
    # Start/Fire/Mute here can prevent Button.pressed from firing on Android.
    if event is InputEventKey:
        keys_down[event.keycode] = event.pressed

func _unhandled_input(event:InputEvent) -> void:
    # Fallback touch handling runs only after GUI Controls had their chance.
    if event is InputEventScreenTouch and event.pressed:
        if not playing:
            return
        if fire_button.get_global_rect().has_point(event.position):
            _fire()
            get_viewport().set_input_as_handled()
            return
        if mute_button.get_global_rect().has_point(event.position):
            _toggle_music()
            get_viewport().set_input_as_handled()
            return
    if not playing:
        return
    if event is InputEventScreenTouch:
        var pos := event.position
        var size := get_viewport().get_visible_rect().size
        if event.pressed:
            if pos.x < size.x*0.43 and pos.y > size.y*0.53:
                joystick_active = true
                joystick = Vector2.ZERO
                last_touch = pos
            elif pos.x > size.x*0.43 and pos.y < size.y*0.88:
                look_active = true
                last_touch = pos
        else:
            if joystick_active and pos.x < size.x*0.48:
                joystick_active = false
                joystick = Vector2.ZERO
            if look_active and pos.x >= size.x*0.40:
                look_active = false
    elif event is InputEventScreenDrag:
        if joystick_active:
            var delta := event.position-last_touch
            joystick = Vector2(clamp(delta.x/75.0,-1.0,1.0),clamp(-delta.y/75.0,-1.0,1.0))
        elif look_active:
            var delta := event.position-last_touch
            player.rotation.y -= delta.x*0.008
            yaw = player.rotation.y
        last_touch = event.position

func _fire() -> void:
    if not playing or fire_cooldown > 0.0:
        return
    if ammo <= 0:
        _say("Пусто. Даже белки в шоке.")
        return
    ammo -= 1
    fire_cooldown = 0.20
    _play_fx(shoot_sound)
    _weapon_kick()
    var best:Dictionary = {}
    var best_d := 999.0
    var forward := Vector2(-sin(player.rotation.y),-cos(player.rotation.y))
    for e in squirrels:
        if not e["alive"]: continue
        var p:Vector2 = e["pos"]
        var pp := Vector2(player.global_position.x,player.global_position.z)
        var v := p-pp
        var d := v.length()
        if d > 9.0 or d < 0.2: continue
        var align := forward.dot(v.normalized())
        if align > 0.985 and d < best_d and _clear_shot(p):
            best = e
            best_d = d
    if not best.is_empty():
        var s:Sprite3D = best["node"]
        best["hp"] -= 1
        best["stunned"] = 1.5
        if best["stars"].is_empty():
            _add_stars(best)
        _play_fx(squirrel_hit)
        if best["hp"] <= 0:
            best["alive"] = false
            best["dead"] = true
            s.position.y = 0.25
            s.scale = Vector3(1.25,0.42,1.25)
            s.rotation.z = deg_to_rad(82.0)
            _say("БЕЛКА ПОВЕРЖЕНА. Контужена окончательно.")
        else:
            _say("ПОПАЛА. Белка контужена. И очень недовольна.")

func _clear_shot(target:Vector2) -> bool:
    var a := Vector2(player.global_position.x,player.global_position.z)
    var d := a.distance_to(target)
    var steps := max(1,int(d*10.0))
    for i in range(1,steps):
        var p := a.lerp(target,float(i)/float(steps))
        if _is_wall(p.x,p.y): return false
    return true

func _update_squirrels(delta:float) -> void:
    var pp := Vector2(player.global_position.x,player.global_position.z)
    for e in squirrels:
        if not e["alive"]: continue
        var s:Sprite3D = e["node"]
        var stun:float = e["stunned"]
        if stun > 0.0:
            e["stunned"] = max(0.0,stun-delta)
            s.rotation.z = sin(Time.get_ticks_msec()*0.012)*0.10
            continue
        if not e["dead"] and not e["stars"].is_empty():
            for star in e["stars"]:
                if is_instance_valid(star): star.queue_free()
            e["stars"] = []
            s.rotation.z = 0.0
        var p:Vector2 = e["pos"]
        var d := p.distance_to(pp)
        if d < 6.0 and d > 1.0:
            var v := (pp-p).normalized()
            var np := p+v*delta*0.62
            if _can_squirrel(np.x,np.y):
                e["pos"] = np
                s.position.x = np.x
                s.position.z = np.y
        if d < 0.75:
            hp = max(0,hp-int(delta*24.0))
            if hp <= 0:
                playing = false
                _say("Белки победили. Это позор.")

func _add_stars(e:Dictionary) -> void:
    var s:Sprite3D = e["node"]
    for i in range(3):
        var star := Sprite3D.new()
        star.texture = star_tex
        star.pixel_size = 0.004
        star.position = s.position + Vector3((i-1)*0.22,0.45,0)
        star.material_override = _sprite_material(true)
        world_root.add_child(star)
        e["stars"].append(star)

func _check_items() -> void:
    var pp := Vector2(player.global_position.x,player.global_position.z)
    for i in acorns.size():
        var s:Sprite3D = acorns[i]
        if not s.visible: continue
        var d := pp.distance_to(Vector2(s.position.x,s.position.z))
        if d < 0.42:
            s.visible = false
            found += 1
            if found == 1: _say("Котёнок, один есть. Я в тебя верила.")
            elif found == 2: _say("Данил сообщает: прогресс исторический.")
            elif found == 3: _say("ЖЁЛУДЬ! Дарина одобряет.")
            else:
                _say("ЧЕТЫРЕ ИЗ ЧЕТЫРЁХ. ОН СУЩЕСТВУЕТ.")
                playing = false
                victory_layer.visible = true
                weapon.visible = false
    for child in world_root.get_children():
        if not (child is Sprite3D) or not child.has_meta("fake") or not child.visible: continue
        var d := pp.distance_to(Vector2(child.position.x,child.position.z))
        if d < 0.48:
            child.visible = false
            hp = max(0,hp-15)
            _say("ЭТО НЕ ЖЁЛУДЬ. Потеряно 15 HP. Это ШИШКА.")

func _is_wall(x:float,z:float) -> bool:
    var ix := int(floor(x)); var iy := int(floor(z))
    if ix < 0 or iy < 0 or ix >= MAP_W or iy >= MAP_H: return true
    return MAP[iy][ix] == 1

func _can_squirrel(x:float,z:float) -> bool:
    return not _is_wall(x-0.12,z-0.12) and not _is_wall(x+0.12,z+0.12)

func _say(text:String) -> void:
    toast_label.text = text
    toast_panel.visible = true
    toast_time = 1.65

func _footstep() -> void:
    if muted: return
    audio_fx.stream = foot1 if int(Time.get_ticks_msec()/280)%2==0 else foot2
    audio_fx.play()

func _play_fx(stream:AudioStream) -> void:
    if muted: return
    audio_fx.stream = stream
    audio_fx.play()

func _toggle_music() -> void:
    muted = not muted
    mute_button.text = "×" if muted else "♪"
    if muted:
        audio_music.stop()
    elif playing:
        audio_music.play()
    _say("Музыка выключена." if muted else "Музыка возвращена. Белки снова слышат угрозу.")

func _weapon_kick() -> void:
    weapon.position.y = 16
    var tw := create_tween()
    tw.tween_property(weapon,"position:y",0.0,0.10).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)

func _update_hud() -> void:
    status_label.text = "ОПЕРАЦИЯ «ЖЁЛУДЬ»\nУР. 1   ЖЁЛУДИ %d/4" % found
    hp_ammo_label.text = "HP %d\nAMMO %d" % [hp,ammo]

func _process(_delta:float) -> void:
    if playing:
        var sway := sin(bob)*2.0
        weapon.position.y = sway
    else:
        weapon.position.y = 0.0
