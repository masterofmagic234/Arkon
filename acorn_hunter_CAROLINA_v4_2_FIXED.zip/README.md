# Acorn Hunter — Carolina v4.1

Personal retro raycasting FPS for Android.

- Landscape immersive mode
- Portrait fallback screen asking the player to rotate the phone
- Raycast corridor rendering
- Three levels with progression screens
- Squirrels, acorns, fake acorns, HP and ammo
- Carolina portrait in HUD
- User-supplied music bundled as `acorn_music.mp3`
- GitHub Actions workflow for cloud APK builds
