extends RefCounted

# Gameplay orchestration only. Input and scene lifecycle remain in game.gd.
const LevelData = preload("res://scripts/level_data.gd")
const CombatQuery = preload("res://scripts/combat_query.gd")
const WorldQueries = preload("res://scripts/world_queries.gd")
const WorldSpriteView = preload("res://scripts/world_sprite_view.gd")
const PickupQuery = preload("res://scripts/pickup_query.gd")
const ConeQuery = preload("res://scripts/cone_query.gd")
const HealthMath = preload("res://scripts/health_math.gd")
const DeathQuery = preload("res://scripts/death_query.gd")
const AmmoMath = preload("res://scripts/ammo_math.gd")
const MissionProgressQuery = preload("res://scripts/mission_progress_query.gd")
const FireQuery = preload("res://scripts/fire_query.gd")
const MissionStateQuery = preload("res://scripts/mission_state_query.gd")
const SceneLookup = preload("res://scripts/scene_lookup.gd")

var root
var player
var camera
var game_state
var world_sprite_view
var combat_feedback
var audio_controller
var message_view
var mission_view
var enemy_controller
var on_mission_end: Callable

func setup(root_node, player_node, camera_node, state, world_sprites, feedback, audio, messages, mission, enemy, mission_end_callback: Callable) -> void:
    root = root_node
    player = player_node
    camera = camera_node
    game_state = state
    world_sprite_view = world_sprites
    combat_feedback = feedback
    audio_controller = audio
    message_view = messages
    mission_view = mission
    enemy_controller = enemy
    on_mission_end = mission_end_callback

func handle_fire() -> void:
    if not FireQuery.can_fire(game_state.mission_complete, game_state.mission_failed, game_state.fire_cooldown, game_state.ammo):
        if game_state.ammo <= 0 and not MissionStateQuery.is_finished(game_state.mission_complete, game_state.mission_failed) and game_state.fire_cooldown <= 0.0:
            set_message("Пусто. Даже белки в шоке.", 1.2)
        return
    game_state.ammo = AmmoMath.consume_one(game_state.ammo)
    game_state.fire_cooldown = 0.18
    game_state.recoil_time = 0.10
    combat_feedback.recoil()
    combat_feedback.show_muzzle()
    audio_controller.play_fx(audio_controller.shoot_stream)

    var hit := CombatQuery.raycast(root.get_world_3d(), camera)
    if hit.is_empty():
        miss()
        return

    var squirrel := WorldQueries.find_squirrel_from_collider(hit.get("collider"), game_state.squirrels)
    if squirrel == "" or enemy_controller.is_disabled(squirrel):
        miss()
        return

    enemy_controller.hit_squirrel(squirrel)
    combat_feedback.show_hit()
    await root.get_tree().create_timer(0.35).timeout
    if MissionStateQuery.is_active(game_state.mission_complete, game_state.mission_failed):
        combat_feedback.hide_hit()

func miss() -> void:
    combat_feedback.show_miss()
    set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await root.get_tree().create_timer(0.22).timeout
    if MissionStateQuery.is_active(game_state.mission_complete, game_state.mission_failed):
        combat_feedback.hide_hit()

func update(delta: float) -> void:
    enemy_controller.update(delta)
    collect_acorns()
    check_fake_cone()

func collect_acorns() -> void:
    for name in game_state.acorns.duplicate():
        var node = SceneLookup.mesh_node(root, name)
        if node != null and PickupQuery.is_in_range(player.global_position, node.global_position, LevelData.ACORN_PICKUP_RADIUS):
            world_sprite_view.hide_pickup(node)
            game_state.acorns.erase(name)
            game_state.collected += 1
            if audio_controller.pickup_stream != null:
                audio_controller.play_fx(audio_controller.pickup_stream)
            set_message(LevelData.ACORN_LINES.pick_random() + "\nЖёлуди: %d / %d" % [game_state.collected, LevelData.ACORN_COUNT], 1.8)
            if MissionProgressQuery.is_complete(game_state.collected, LevelData.ACORN_COUNT):
                complete()

func check_fake_cone() -> void:
    if game_state.fake_cone_found:
        return
    var cone := root.get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null and ConeQuery.is_in_range(player.global_position, cone.global_position):
        game_state.fake_cone_found = true
        game_state.hp = HealthMath.apply_damage(game_state.hp, 12)
        if audio_controller.damage_stream != null:
            audio_controller.play_fx(audio_controller.damage_stream)
        set_message(LevelData.CONE_LINES.pick_random(), 2.4)
        if DeathQuery.is_dead(game_state.hp):
            fail()

func complete() -> void:
    game_state.mission_complete = true
    if on_mission_end.is_valid():
        on_mission_end.call()
    mission_view.show_complete(LevelData.ACORN_COUNT)

func fail() -> void:
    game_state.mission_failed = true
    if on_mission_end.is_valid():
        on_mission_end.call()
    mission_view.show_failed()

func set_message(text: String, duration: float) -> void:
    message_view.set_text(text)
    game_state.message_time = duration
