# ACORN HUNTER — V9 START INPUT DIAGNOSTIC

Purpose: isolate the exact point where the Android touch/button chain fails.

This build intentionally does not start the game. It displays live counters for:
- raw InputEventScreenTouch
- raw mouse events (touch emulation)
- Control._gui_input
- Button.button_down
- Button.pressed
- TouchScreenButton.pressed
- _unhandled_input

Tap the START button once or twice and send a screenshot of the diagnostic line at the bottom.
The key result is which counters increment.
