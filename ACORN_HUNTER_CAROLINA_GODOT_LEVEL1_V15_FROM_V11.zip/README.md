# ACORN HUNTER — Operation «Жёлудь» — Godot clean rebuild

A clean recreation of the spirit of the original Acorn Hunter prototype, rebuilt from zero in Godot 4.7.2.

## Level 1
- Wolfenstein-style fixed-height camera.
- 20×14 hedge map.
- 4 acorns, 1 fake pine cone, 9 oak trees, 2 two-hit squirrels.
- Stunned squirrels keep their stars; defeated squirrels remain on the ground.
- Carolina/Darina jokes and personal messages.
- Night sky, moon, stars, minimap, HUD, weapon kick, music and SFX.
- Android touch controls: direct Start/Fire/Mute handling plus mouse-emulated buttons.
- No vertical camera look.

## Important input fix
The Android build explicitly enables touch-to-mouse emulation and also handles the Start/Fire/Mute touch rectangles directly in the game script. The title screen has the gameplay layer hidden by default, so a failed runtime initialization cannot leave the HUD accidentally visible over the title.
