# V8 — Mobile START hardening

## Why V8 changes the start path

The Android screenshot proved that the GUI Button itself is receiving the touch visually, but the gameplay transition is not occurring. Instead of adding more `_input()` heuristics, V8 uses Godot's dedicated `TouchScreenButton` for the mobile hit target and starts the game on the Button's `button_down` event.

Godot documents that `Button` supports touch via `emulate_mouse_from_touch`, while `TouchScreenButton` emits `pressed` directly on touch-down. V8 therefore keeps the visible `Button` for normal GUI interaction and places an invisible `TouchScreenButton` over exactly the same rectangle as a mobile-specific fallback.

The start path is now:
- Desktop / mouse: `StartButton.button_down` → `_on_start_button_down()` → `_start_game()`
- Mobile touch: `StartTouch.pressed` → `_on_start_button_down()` → `_start_game()`

A guard prevents a second input path from starting the game twice.
