# ACORN HUNTER — V5 START FIX

V5 hardens the title-screen transition for Android:
- TitleLayer no longer participates in mouse/touch hit-testing; only the StartButton receives GUI input.
- StartButton has an explicit scene-level `pressed` connection.
- Runtime connection uses a dedicated handler and deferred transition.
- Direct Android ScreenTouch fallback also defers the transition.
- Landscape and all V3/V4 gameplay fixes are preserved.
