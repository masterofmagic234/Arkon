# ACORN HUNTER — Level 1 V4 Android input/orientation fix

This patch addresses the reported V2/V3 Android behavior:

- Forces the game to launch in landscape instead of portrait.
- Makes the title layer pass mouse/touch input correctly to its controls.
- Keeps the Start button as an explicit input target.
- Adds a direct GUI mouse/touch fallback for the Start button, covering Android builds that emulate touch as mouse input.
- Preserves the V3 restart-state and multi-touch fixes.

The gameplay scene and assets are otherwise unchanged.
