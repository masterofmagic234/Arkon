# ACORN HUNTER — V10 START FIX

## Root cause found in V9 diagnostic

The Android touch chain was working correctly: `InputEventScreenTouch`, mouse emulation, `Control._gui_input`, `Button.button_down` and `Button.pressed` all fired.

The actual scene had two configuration/code mistakes:

1. `main.tscn` was still using `res://scripts/diagnostic.gd` as the script for the root `Main` node. That diagnostic script intentionally never starts gameplay.
2. `main.gd` contained `_on_start_pressed()` / `_on_start_button_down()` but the `StartButton` had no connection to either method.

V10 fixes both:
- `Main` now uses `res://scripts/main.gd`.
- `StartButton.pressed` is explicitly connected to `_start_game()` in `_ready()`.

The diagnostic counters are removed from the runtime build.
