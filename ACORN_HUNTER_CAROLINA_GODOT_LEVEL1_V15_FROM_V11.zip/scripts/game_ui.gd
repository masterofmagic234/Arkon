extends Control

var main

func _process(_delta:float) -> void:
    queue_redraw()

func _draw() -> void:
    if main == null or not main.playing:
        return
    var c:=Vector2(145,size.y-92)
    draw_circle(c,68,Color(1,1,1,0.10))
    draw_arc(c,68,0,TAU,48,Color(1,1,1,0.28),2)
    draw_circle(c+main.joystick*40,27,Color(1.0,0.69,0.74,0.65))
    var f:=Vector2(size.x-157,size.y-100)
    draw_circle(f,61,Color(1.0,0.69,0.74,0.48))
    draw_arc(f,61,0,TAU,48,Color(1.0,0.85,0.86,0.7),2)
