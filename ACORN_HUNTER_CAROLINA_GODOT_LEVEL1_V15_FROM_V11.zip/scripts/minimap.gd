extends Control

var main

func _ready() -> void:
    queue_redraw()

func _process(_delta:float) -> void:
    queue_redraw()

func _draw() -> void:
    draw_style_box(_box(Color(0.025,0.05,0.04,0.9),Color(0.3,0.5,0.35,0.8)),Rect2(Vector2.ZERO,size))
    if main == null: return
    var sx := size.x/main.MAP_W
    var sy := size.y/main.MAP_H
    for y in range(main.MAP_H):
        for x in range(main.MAP_W):
            if main.MAP[y][x] == 1:
                draw_rect(Rect2(x*sx,y*sy,sx+1,sy+1),Color(0.12,0.22,0.15,1))
    for t in main.trees:
        draw_circle(Vector2(t.position.x*sx,t.position.z*sy),3.0,Color(0.3,0.75,0.36,1))
    for a in main.acorns:
        if a.visible: draw_circle(Vector2(a.position.x*sx,a.position.z*sy),3.0,Color(1.0,0.72,0.25,1))
    for e in main.squirrels:
        if e["alive"]:
            var p:Vector2=e["pos"]
            draw_circle(Vector2(p.x*sx,p.y*sy),2.5,Color(0.9,0.35,0.45,1))
    var pp:=Vector2(main.player.global_position.x*sx,main.player.global_position.z*sy)
    draw_circle(pp,4.0,Color.WHITE)
    var dir:=Vector2(-sin(main.player.rotation.y),-cos(main.player.rotation.y))*11.0
    draw_line(pp,pp+Vector2(dir.x*sx,dir.y*sy),Color.WHITE,2.0)

func _box(bg:Color,border:Color) -> StyleBoxFlat:
    var b:=StyleBoxFlat.new()
    b.bg_color=bg
    b.border_color=border
    b.set_border_width_all(2)
    b.corner_radius_top_left=10
    b.corner_radius_top_right=10
    b.corner_radius_bottom_left=10
    b.corner_radius_bottom_right=10
    return b
