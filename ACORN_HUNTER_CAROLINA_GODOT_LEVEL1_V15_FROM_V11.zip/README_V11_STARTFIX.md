# ACORN HUNTER — V11 START FIX

This build removes the diagnostic UI/script from the runtime project.
The StartButton `pressed` signal is connected at the scene level in `main.tscn`,
so gameplay entry no longer depends on `_ready()` reaching a runtime `connect()` call.

The canonical Godot Button pattern is supported by the Godot 4 documentation:
`button.pressed.connect(_button_pressed)`. Scene/editor signal connections are also a standard Godot workflow.

Expected flow:
TITLE -> tap START -> `_start_game()` -> TitleLayer hidden, GameLayer visible.
