# ACORN HUNTER — Level 1 V3 patch

Source patch on top of `ACORN_HUNTER_CAROLINA_GODOT_LEVEL1_REBUILT_V2_TOUCHFIX`.

Changes:
- Restart now restores squirrels to their original positions, scale, height and rotation.
- Restart clears movement/touch state, fire cooldown, footstep timer, weapon bob and toast timer.
- Touch release is less likely to cancel the opposite-side control in multi-touch play.
- Original Level 1 content and assets are preserved.

This is a source-project patch. An Android APK is not generated here because the supplied environment does not contain a Godot/Android export toolchain.
