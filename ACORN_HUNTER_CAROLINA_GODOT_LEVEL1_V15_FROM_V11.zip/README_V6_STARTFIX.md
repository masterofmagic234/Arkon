# ACORN HUNTER — V6 START FIX

Root cause found in V5:
- `StartButton` had an explicit `pressed` connection in `main.tscn`.
- V5 also connected the same signal again in `_ready()`.
- The second connection caused `_ready()` to stop with an "already connected" error before the rest of initialization completed.
- Result: the title screen appeared, but pressing the button did not execute the transition.

V6 removes the duplicate runtime connection and keeps the scene-level connection.
Landscape and gameplay fixes are preserved.
