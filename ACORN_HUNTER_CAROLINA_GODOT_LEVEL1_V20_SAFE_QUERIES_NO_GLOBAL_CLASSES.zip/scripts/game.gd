extends Node3D

# ACORN HUNTER — LEVEL 1
# Rebuilt from the last proven CLEAN/V6 control foundation.
# World sprites are deliberately MeshInstance3D + QuadMesh, not Sprite3D.
# UI owns touch input: joystick.gui_input + Fire.pressed.

const LevelData = preload("res://scripts/level_data.gd")
const HudView = preload("res://scripts/hud_view.gd")
const AudioController = preload("res://scripts/audio_controller.gd")
const MissionView = preload("res://scripts/mission_view.gd")
const CombatFeedbackView = preload("res://scripts/combat_feedback_view.gd")
const MessageView = preload("res://scripts/message_view.gd")
const MinimapView = preload("res://scripts/minimap_view.gd")
const NavigationController = preload("res://scripts/navigation_controller.gd")
const WorldCollision = preload("res://scripts/world_collision.gd")
const CombatQuery = preload("res://scripts/combat_query.gd")
const WorldSpriteView = preload("res://scripts/world_sprite_view.gd")
const RuntimeTimers = preload("res://scripts/runtime_timers.gd")
const PresentationSync = preload("res://scripts/presentation_sync.gd")
const PlayerView = preload("res://scripts/player_view.gd")
const WorldQueries = preload("res://scripts/world_queries.gd")
const MovementMath = preload("res://scripts/movement_math.gd")
const PickupQuery = preload("res://scripts/pickup_query.gd")
const TurnMath = preload("res://scripts/turn_math.gd")
const SquirrelMotionMath = preload("res://scripts/squirrel_motion_math.gd")
const SquirrelQuery = preload("res://scripts/squirrel_query.gd")
const ConeQuery = preload("res://scripts/cone_query.gd")
const HealthMath = preload("res://scripts/health_math.gd")
const AmmoMath = preload("res://scripts/ammo_math.gd")
const JoystickMath = preload("res://scripts/joystick_math.gd")
const MissionProgressQuery = preload("res://scripts/mission_progress_query.gd")
const FireQuery = preload("res://scripts/fire_query.gd")
const MissionStateQuery = preload("res://scripts/mission_state_query.gd")
const DeathQuery = preload("res://scripts/death_query.gd")
const SquirrelAttackQuery = preload("res://scripts/squirrel_attack_query.gd")
const SceneLookup = preload("res://scripts/scene_lookup.gd")

var move_axis := Vector2.ZERO
var joystick_touch_id := -1
var collected := 0
var ammo := LevelData.MAX_AMMO
var hp := LevelData.MAX_HP
var message_time := 0.0
var fire_cooldown := 0.0
var damage_cooldown := 0.0
var recoil_time := 0.0
var foot_timer := 0.0
var fake_cone_found := false
var mission_complete := false
var mission_failed := false
var audio_controller: AudioController
var stunned: Dictionary = {}
var squirrel_hp := LevelData.SQUIRREL_HP.duplicate()
var acorns := LevelData.ACORN_NAMES.duplicate()
var squirrels := LevelData.SQUIRREL_NAMES.duplicate()
var squirrel_home := LevelData.SQUIRREL_HOME.duplicate()
var squirrel_phase := LevelData.SQUIRREL_PHASE.duplicate()
var hud_view: HudView
var mission_view: MissionView
var combat_feedback: CombatFeedbackView
var message_view: MessageView
var minimap_view: MinimapView
var navigation_controller: NavigationController
var world_sprite_view: WorldSpriteView
var runtime_timers: RuntimeTimers
var presentation_sync: PresentationSync
var player_view: PlayerView

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var joystick: Panel = $HUD/Joystick
@onready var knob: Panel = $HUD/Joystick/Knob
@onready var fire_button: Button = $HUD/Fire
@onready var mute_button: Button = $HUD/Mute
@onready var count_label: Label = $HUD/Count
@onready var hp_ammo_label: Label = $HUD/HPAmmo
@onready var message_label: Label = $HUD/Message
@onready var mission_panel: Panel = $HUD/Mission
@onready var mission_title: Label = $HUD/Mission/Title
@onready var mission_body: Label = $HUD/Mission/Body
@onready var weapon: TextureRect = $HUD/Weapon
@onready var muzzle: ColorRect = $HUD/MuzzleFlash
@onready var hit_marker: Label = $HUD/HitMarker
@onready var carolina: TextureRect = $HUD/Carolina
@onready var music: AudioStreamPlayer = $Music
@onready var fx: AudioStreamPlayer = $FX

func _ready() -> void:
    player_view = PlayerView.new()
    player_view.setup(camera, carolina)
    player_view.apply()
    mission_panel.visible = false
    muzzle.visible = false
    hit_marker.visible = false
    knob.position = joystick.size * 0.5 - knob.size * 0.5

    # Touch is handled by the actual UI controls, not by a global input relay.
    joystick.gui_input.connect(_on_joystick_gui_input)
    fire_button.pressed.connect(_on_fire_pressed)
    mute_button.pressed.connect(_toggle_music)


    hud_view = HudView.new()
    hud_view.setup(count_label, hp_ammo_label)

    mission_view = MissionView.new()
    mission_view.setup(mission_panel, mission_title, mission_body, weapon)

    combat_feedback = CombatFeedbackView.new()
    combat_feedback.setup(weapon, muzzle, hit_marker)

    message_view = MessageView.new()
    message_view.setup(message_label)

    minimap_view = $HUD/Minimap as MinimapView

    world_sprite_view = WorldSpriteView.new()
    runtime_timers = RuntimeTimers.new()
    presentation_sync = PresentationSync.new()

    navigation_controller = NavigationController.new()
    navigation_controller.setup($HUD/Mission/Menu, get_tree())

    audio_controller = AudioController.new()
    audio_controller.setup(music, fx)
    audio_controller.start_music()
    _update_hud()
    _set_message("Парк открыт. Дубы не прячутся — жёлуди тоже.", 4.0)
    _refresh_minimap()

func _physics_process(delta: float) -> void:
    if MissionStateQuery.is_finished(mission_complete, mission_failed):
        player.velocity = Vector3.ZERO
        return

    var forward := -move_axis.y
    player.velocity = MovementMath.velocity_for_input(player.global_transform.basis, move_axis, LevelData.WALK_SPEED)
    player.move_and_slide()

    if abs(move_axis.x) > 0.04:
        player.rotate_y(TurnMath.turn_amount(move_axis.x, LevelData.TURN_SPEED, delta))

    var timers := runtime_timers.tick(delta, {
        "fire_cooldown": fire_cooldown,
        "damage_cooldown": damage_cooldown,
        "recoil_time": recoil_time,
        "message_time": message_time
    })
    fire_cooldown = timers["fire_cooldown"]
    damage_cooldown = timers["damage_cooldown"]
    recoil_time = timers["recoil_time"]
    message_time = timers["message_time"]

    if message_time <= 0.0:
        message_view.clear()
    if recoil_time <= 0.0:
        combat_feedback.set_idle_weapon()
    combat_feedback.update_muzzle(delta)

    if abs(forward) > 0.05:
        foot_timer -= delta
        if foot_timer <= 0.0:
            _footstep()
            foot_timer = 0.30
    else:
        foot_timer = 0.0

    _update_squirrels(delta)
    _collect_acorns()
    _check_fake_cone()
    _update_hud()
    _refresh_minimap()

func _on_joystick_gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            joystick_touch_id = event.index
            _update_joystick(event.position)
            joystick.accept_event()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _update_joystick(event.position)
        joystick.accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            joystick_touch_id = -2
            _update_joystick(event.position)
            joystick.accept_event()
        elif joystick_touch_id == -2:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventMouseMotion and joystick_touch_id == -2:
        _update_joystick(event.position)
        joystick.accept_event()

func _update_joystick(position: Vector2) -> void:
    var center := joystick.size * 0.5
    var delta := JoystickMath.clamped_delta(position, center, LevelData.JOYSTICK_RADIUS)
    move_axis = JoystickMath.axis_from_delta(delta, LevelData.JOYSTICK_RADIUS)
    knob.position = center - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func _on_fire_pressed() -> void:
    if not FireQuery.can_fire(mission_complete, mission_failed, fire_cooldown, ammo):
        if ammo <= 0 and not MissionStateQuery.is_finished(mission_complete, mission_failed) and fire_cooldown <= 0.0:
            _set_message("Пусто. Даже белки в шоке.", 1.2)
        return
    ammo = AmmoMath.consume_one(ammo)
    fire_cooldown = 0.18
    recoil_time = 0.10
    combat_feedback.recoil()
    combat_feedback.show_muzzle()
    audio_controller.play_fx(audio_controller.shoot_stream)

    var hit := CombatQuery.raycast(get_world_3d(), camera)
    if hit.is_empty():
        _miss()
        return

    var squirrel := _find_squirrel_from_collider(hit.get("collider"))
    if squirrel == "" or stunned.has(squirrel):
        _miss()
        return

    squirrel_hp[squirrel] = HealthMath.apply_damage(int(squirrel_hp.get(squirrel, 2)), 1)
    var target = SceneLookup.mesh_node(self, squirrel)
    audio_controller.play_fx(audio_controller.squirrel_hit_stream)
    combat_feedback.show_hit()
    if int(squirrel_hp[squirrel]) <= 0:
        stunned[squirrel] = true
        if target != null:
            world_sprite_view.apply_squirrel_stunned(target)
        _set_message(LevelData.STUN_LINES.pick_random(), 2.0)
    else:
        _set_message(LevelData.HIT_LINES.pick_random() + "\nЕщё один раз — и белка отдыхает.", 1.4)
    await get_tree().create_timer(0.35).timeout
    if MissionStateQuery.is_active(mission_complete, mission_failed):
        combat_feedback.hide_hit()

func _find_squirrel_from_collider(collider: Object) -> String:
    return WorldQueries.find_squirrel_from_collider(collider, squirrels)

func _miss() -> void:
    combat_feedback.show_miss()
    _set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await get_tree().create_timer(0.22).timeout
    if MissionStateQuery.is_active(mission_complete, mission_failed):
        combat_feedback.hide_hit()

func _update_squirrels(delta: float) -> void:
    var player_pos := Vector2(player.global_position.x, player.global_position.z)
    for name in squirrels:
        if stunned.has(name):
            continue
        var node = SceneLookup.mesh_node(self, name)
        if node == null:
            continue
        var home: Vector2 = squirrel_home[name]
        var dist := home.distance_to(player_pos)
        if SquirrelQuery.should_chase(dist):
            var proposed := SquirrelMotionMath.proposed_position(home, player_pos, delta, 0.45)
            if not _is_wall(proposed.x, proposed.y):
                squirrel_home[name] = proposed
                node.position.x = proposed.x
                node.position.z = proposed.y
        world_sprite_view.animate_squirrel(node, float(squirrel_phase[name]))
        if SquirrelAttackQuery.can_attack(dist, stunned.has(name), damage_cooldown, LevelData.SQUIRREL_ATTACK_DISTANCE):
            damage_cooldown = 0.8
            hp = HealthMath.apply_damage(hp, 12)
            audio_controller.play_fx(audio_controller.damage_stream)
            _set_message(LevelData.DAMAGE_LINES.pick_random(), 1.2)
            if DeathQuery.is_dead(hp):
                _fail()

func _is_wall(x: float, z: float) -> bool:
    return WorldCollision.is_wall(x, z)

func _collect_acorns() -> void:
    for name in acorns.duplicate():
        var node = SceneLookup.mesh_node(self, name)
        if node != null and PickupQuery.is_in_range(player.global_position, node.global_position, LevelData.ACORN_PICKUP_RADIUS):
            world_sprite_view.hide_pickup(node)
            acorns.erase(name)
            collected += 1
            if audio_controller.pickup_stream != null:
                audio_controller.play_fx(audio_controller.pickup_stream)
            _set_message(LevelData.ACORN_LINES.pick_random() + "\nЖёлуди: %d / %d" % [collected, LevelData.ACORN_COUNT], 1.8)
            if MissionProgressQuery.is_complete(collected, LevelData.ACORN_COUNT):
                _complete()

func _check_fake_cone() -> void:
    if fake_cone_found:
        return
    var cone := get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null and ConeQuery.is_in_range(player.global_position, cone.global_position):
        fake_cone_found = true
        hp = HealthMath.apply_damage(hp, 12)
        if audio_controller.damage_stream != null:
            audio_controller.play_fx(audio_controller.damage_stream)
        _set_message(LevelData.CONE_LINES.pick_random(), 2.4)
        if DeathQuery.is_dead(hp):
            _fail()

func _complete() -> void:
    mission_complete = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_view.show_complete(LevelData.ACORN_COUNT)

func _fail() -> void:
    mission_failed = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_view.show_failed()

func _update_hud() -> void:
    presentation_sync.sync_hud(hud_view, collected, LevelData.ACORN_COUNT, hp, ammo)

func _set_message(text: String, duration: float) -> void:
    message_view.set_text(text)
    message_time = duration

func _footstep() -> void:
    audio_controller.footstep()

func _toggle_music() -> void:
    var is_muted := audio_controller.toggle_music()
    mute_button.text = "×" if is_muted else "♪"
    _set_message("Музыка выключена." if is_muted else "Музыка возвращена. Белки снова слышат угрозу.", 1.6)

func _face_world_sprites() -> void:
    # Billboard materials handle camera-facing orientation.
    pass

func _refresh_minimap() -> void:
    presentation_sync.sync_minimap(minimap_view, player, acorns, squirrels, stunned)

