extends RefCounted

static func can_attack(distance, stunned, damage_cooldown, attack_distance):
    return (not stunned) and distance <= attack_distance and damage_cooldown <= 0.0
