# Acorn Hunter: Operation Жёлудь v4

A small original raycasting FPS made as a personal gift for Carolina.

- 3 levels
- first-person raycasting corridors
- acorn collection
- squirrel enemies
- fake acorns/cones as hazards
- touch joystick + action/fire button
- Carolina portrait in HUD
- supplied music loop
- immersive landscape fullscreen
- minimap and crosshair
- GitHub Actions build

The graphics and maps are original; the bundled music is the user-provided audio file.
