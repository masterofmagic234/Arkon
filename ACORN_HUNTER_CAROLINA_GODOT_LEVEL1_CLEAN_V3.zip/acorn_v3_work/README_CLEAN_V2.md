# ACORN HUNTER — CLEAN V2

First playable mechanics build after the clean restart.

Implemented:
- Landscape Android configuration.
- Standalone menu -> game transition.
- First-person camera.
- Touch joystick movement.
- Large touch fire button.
- Desktop arrow-key fallback.
- Hitscan shooting from the center crosshair.
- 4 acorns to collect.
- 3 squirrels; shooting them stuns them.
- Fake pine-cone trap.
- Acorn counter HUD.
- Minimap with player/acorn/squirrel markers.
- Weapon HUD animation on firing.
- Mission-complete screen with the Carolina/Darina joke.

Android: left stick = move, ОГОНЬ = shoot, walk into acorns to collect.
Desktop: arrow keys = move, Enter/left click = fire.

The project uses the included export_presets.cfg Android preset named Android.
