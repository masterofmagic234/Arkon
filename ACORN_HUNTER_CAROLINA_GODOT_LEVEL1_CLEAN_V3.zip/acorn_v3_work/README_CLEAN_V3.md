# ACORN HUNTER — CLEAN V3

V3 fixes the blank-gray Level 1 startup seen on Android.

Key reliability change:
- Camera3D is now a real node in `game.tscn` and is current before `game.gd` runs.
- WorldEnvironment, directional moon light, and ground mesh are also present in the scene.
- `game.gd` reuses the existing camera instead of creating it late during `_ready()`.
- The level has a visible boot label even if later gameplay construction hits an error.
- The procedural sky was replaced with a simple color environment for a safer mobile rendering path.

Gameplay remains the CLEAN V2 design: mobile joystick, fire button, acorns, squirrels, fake pine cone, minimap, weapon animation, and mission completion.

This build was statically checked in the working directory and packaged as a valid ZIP. It has not been executed locally because Godot/Android runtime is not installed in the current environment.
