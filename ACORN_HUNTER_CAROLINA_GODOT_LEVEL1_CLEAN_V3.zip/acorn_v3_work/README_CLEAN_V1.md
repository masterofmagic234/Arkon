# ACORN HUNTER — CLEAN V1

This is a genuinely fresh project. It does not reuse the previous V2-V11 scene tree or scripts.

Architecture:
- menu.tscn: a standalone Control scene with one Button.
- Button pressed signal is connected in the scene file to menu.gd.
- Start action uses get_tree().change_scene_to_file("res://game.tscn").
- game.tscn is a separate Node3D scene.
- No hidden title/game layers in one scene.
- No runtime signal registration for the start button.
- No diagnostic scripts.
- No TouchScreenButton overlay on the start button.
- Android touch-to-mouse emulation remains enabled.
- Landscape orientation remains enabled.

The first goal is to prove the foundation: MENU -> GAME SCENE.
Only after that is verified should movement, shooting, acorns, squirrels, HUD polish, audio and the full Wolfenstein mechanics be added.
