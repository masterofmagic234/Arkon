# ACORN HUNTER — CLEAN V1.1

## Build fix

The CI build failed before Godot could verify/export the project because the project did not contain `export_presets.cfg`.

Godot's command-line export requires an export preset to exist in that file. This build adds a standard Android preset named `Android` and keeps the project itself independent of the CI workflow.

The Android preset targets arm64-v8a, uses the normal prebuilt Android export template, and uses package id `com.acornhunter.carolina`.

No gameplay logic was changed in this revision.
