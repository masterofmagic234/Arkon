extends Node3D

# ACORN HUNTER — CLEAN V2
# Actual playable Level 1: movement, shooting, acorn collection,
# squirrels, fake pine cone, HUD and minimap. Built independently
# from the old diagnostic versions.

const ACORN_POSITIONS := [
    Vector3(-5.5, 0.45, -3.0),
    Vector3(1.0, 0.45, -4.8),
    Vector3(5.0, 0.45, 1.5),
    Vector3(2.5, 0.45, 4.8)
]

const TREE_POSITIONS := [
    Vector3(-7.0, 1.0, -4.5),
    Vector3(-2.0, 1.0, -5.3),
    Vector3(3.8, 1.0, -5.4),
    Vector3(7.0, 1.0, 3.8),
    Vector3(-5.8, 1.0, 5.0),
    Vector3(0.0, 1.0, 5.8)
]

const SQUIRREL_POSITIONS := [
    Vector3(-1.5, 0.75, 1.2),
    Vector3(4.0, 0.75, -1.0),
    Vector3(-4.0, 0.75, 3.2)
]

const ARENA_HALF_X := 9.0
const ARENA_HALF_Z := 6.0
const PLAYER_SPEED := 4.2
const PLAYER_RADIUS := 0.45
const FIRE_COOLDOWN := 0.22

var acorn_texture: Texture2D = preload("res://assets/acorn.png")
var tree_texture: Texture2D = preload("res://assets/oak_tree.png")
var squirrel_texture: Texture2D = preload("res://assets/squirrel.png")
var moon_texture: Texture2D = preload("res://assets/moon.png")
var star_texture: Texture2D = preload("res://assets/star.png")
var ground_texture: Texture2D = preload("res://assets/grass.png")
var weapon_texture: Texture2D = preload("res://assets/weapon.png")
var pine_texture: Texture2D = preload("res://assets/pine_tree.png")

var player: CharacterBody3D
var camera: Camera3D
var fire_timer := 0.0
var collected := 0
var stunned := 0
var mission_complete := false
var joystick_vector := Vector2.ZERO
var joystick_touch_id := -1
var message_timer := 0.0
var acorn_nodes: Array[Area3D] = []
var squirrel_nodes: Array[Area3D] = []

var status_label: Label
var message_label: Label
var count_label: Label
var crosshair: Label
var weapon_view: TextureRect
var joystick_base: Panel
var joystick_knob: Panel
var fire_button: Button
var minimap: Control
var mission_panel: Panel
var mission_title: Label
var mission_body: Label

func _ready() -> void:
    # Camera/environment are part of game.tscn so the level always has a valid
    # render target before this gameplay script starts creating dynamic content.
    camera = $Camera3D
    _add_environment()
    _add_ground()
    _add_walls()
    _add_trees()
    _add_acorns()
    _add_squirrels()
    _add_fake_pine_cone()
    _add_player()
    _add_sky_objects()
    _build_hud()
    _show_message("Парк найден. Жёлуди существуют. Белки пока ничего не подозревают.", 4.0)

func _physics_process(delta: float) -> void:
    if mission_complete:
        return
    fire_timer = maxf(0.0, fire_timer - delta)
    message_timer = maxf(0.0, message_timer - delta)

    _move_player(delta)
    _check_acorn_collection()
    _update_minimap()

    if Input.is_action_just_pressed("ui_accept"):
        _fire()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch and event.pressed:
        var pos := event.position
        if pos.x > get_viewport().get_visible_rect().size.x * 0.72 and pos.y > get_viewport().get_visible_rect().size.y * 0.62:
            _fire()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        if fire_button != null and fire_button.get_global_rect().has_point(event.position):
            _fire()

func _move_player(_delta: float) -> void:
    if player == null:
        return
    var keyboard := Vector2(
        Input.get_axis("ui_left", "ui_right"),
        Input.get_axis("ui_up", "ui_down")
    )
    var input_vec := joystick_vector
    if keyboard.length() > 0.05:
        input_vec = keyboard.normalized()
    if input_vec.length() > 1.0:
        input_vec = input_vec.normalized()

    var world_dir := Vector3(input_vec.x, 0.0, input_vec.y)
    player.velocity = world_dir * PLAYER_SPEED
    player.move_and_slide()
    player.position.x = clampf(player.position.x, -ARENA_HALF_X + PLAYER_RADIUS, ARENA_HALF_X - PLAYER_RADIUS)
    player.position.z = clampf(player.position.z, -ARENA_HALF_Z + PLAYER_RADIUS, ARENA_HALF_Z - PLAYER_RADIUS)
    player.position.y = 0.55

func _fire() -> void:
    if mission_complete or fire_timer > 0.0 or camera == null:
        return
    fire_timer = FIRE_COOLDOWN
    _animate_weapon()
    var center := get_viewport().get_visible_rect().size * 0.5
    var origin := camera.project_ray_origin(center)
    var direction := camera.project_ray_normal(center)
    var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * 18.0)
    query.collision_mask = 2
    query.collide_with_areas = true
    query.collide_with_bodies = false
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        _show_message("Мимо. Белки делают вид, что ничего не заметили.", 1.2)
        return

    var target = hit.get("collider")
    if target is Area3D and target.is_in_group("squirrel"):
        if not target.get_meta("stunned", false):
            target.set_meta("stunned", true)
            stunned += 1
            var sprite = target.get_node_or_null("Sprite")
            if sprite:
                sprite.modulate = Color(0.65, 0.8, 1.0, 1.0)
            _show_message("БЕЛКА ОГЛУШЕНА. Операция всё ещё засекречена.", 1.5)
        else:
            _show_message("Эта белка уже оглушена. Не издевайся.", 1.2)
    elif target is Area3D and target.is_in_group("fake_pine"):
        _show_message("Это шишка. Каролина, разведка докладывала о таком.", 1.8)

func _check_acorn_collection() -> void:
    if player == null:
        return
    for acorn in acorn_nodes.duplicate():
        if not is_instance_valid(acorn):
            acorn_nodes.erase(acorn)
            continue
        var distance := player.global_position.distance_to(acorn.global_position)
        if distance < 1.15:
            collected += 1
            acorn_nodes.erase(acorn)
            acorn.queue_free()
            _update_count()
            if collected == ACORN_POSITIONS.size():
                _complete_mission()
            else:
                _show_message("Жёлудь добыт. Дарина будет довольна. Ещё %d." % (ACORN_POSITIONS.size() - collected), 1.6)

func _complete_mission() -> void:
    mission_complete = true
    player.velocity = Vector3.ZERO
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    mission_body.text = "ЖЁЛУДИ: %d / %d\n\nОН СУЩЕСТВУЕТ.\n\nP.S. Данил всё это время верил в тебя." % [collected, ACORN_POSITIONS.size()]
    _show_message("Миссия выполнена. История спасения желудей завершена.", 5.0)

func _add_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(0.0, 0.55, 5.0)
    player.collision_layer = 1
    player.collision_mask = 1
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = PLAYER_RADIUS
    capsule.height = 1.1
    shape.shape = capsule
    player.add_child(shape)
    add_child(player)

    camera.reparent(player)
    camera.position = Vector3(0.0, 0.85, 0.0)
    camera.rotation_degrees = Vector3(-7.0, 0.0, 0.0)
    camera.current = true
    camera.fov = 72.0

func _add_acorns() -> void:
    for index in range(ACORN_POSITIONS.size()):
        var acorn := Area3D.new()
        acorn.name = "Acorn_%02d" % (index + 1)
        acorn.position = ACORN_POSITIONS[index]
        acorn.collision_layer = 2
        acorn.collision_mask = 0
        var collision := CollisionShape3D.new()
        var sphere := SphereShape3D.new()
        sphere.radius = 0.45
        collision.shape = sphere
        acorn.add_child(collision)
        var sprite := Sprite3D.new()
        sprite.name = "Sprite"
        sprite.texture = acorn_texture
        sprite.pixel_size = 0.01
        sprite.scale = Vector3.ONE * 0.75
        sprite.position.y = 0.15
        sprite.material_override = _sprite_material()
        acorn.add_child(sprite)
        add_child(acorn)
        acorn_nodes.append(acorn)

func _add_squirrels() -> void:
    for index in range(SQUIRREL_POSITIONS.size()):
        var squirrel := Area3D.new()
        squirrel.name = "Squirrel_%02d" % (index + 1)
        squirrel.position = SQUIRREL_POSITIONS[index]
        squirrel.collision_layer = 2
        squirrel.collision_mask = 0
        squirrel.add_to_group("squirrel")
        squirrel.set_meta("stunned", false)
        var collision := CollisionShape3D.new()
        var sphere := SphereShape3D.new()
        sphere.radius = 0.7
        collision.shape = sphere
        squirrel.add_child(collision)
        var sprite := Sprite3D.new()
        sprite.name = "Sprite"
        sprite.texture = squirrel_texture
        sprite.pixel_size = 0.01
        sprite.scale = Vector3.ONE * 1.15
        sprite.material_override = _sprite_material()
        squirrel.add_child(sprite)
        add_child(squirrel)
        squirrel_nodes.append(squirrel)

func _add_fake_pine_cone() -> void:
    var fake := Area3D.new()
    fake.name = "FakePineCone"
    fake.position = Vector3(-1.0, 0.35, -1.8)
    fake.collision_layer = 2
    fake.collision_mask = 0
    fake.add_to_group("fake_pine")
    var collision := CollisionShape3D.new()
    var sphere := SphereShape3D.new()
    sphere.radius = 0.4
    collision.shape = sphere
    fake.add_child(collision)
    var sprite := Sprite3D.new()
    sprite.name = "Sprite"
    sprite.texture = pine_texture
    sprite.pixel_size = 0.008
    sprite.scale = Vector3.ONE * 0.6
    sprite.material_override = _sprite_material()
    fake.add_child(sprite)
    add_child(fake)

func _add_trees() -> void:
    for position in TREE_POSITIONS:
        _add_billboard(tree_texture, position, 1.55)

func _add_environment() -> void:
    var environment := $WorldEnvironment
    var env := environment.environment
    if env == null:
        env = Environment.new()
        environment.environment = env
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("07101a")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("7e8aa6")
    env.ambient_light_energy = 0.75

    var moon_light := $MoonLight
    moon_light.rotation_degrees = Vector3(-55.0, -25.0, 0.0)
    moon_light.light_color = Color("9aaee8")
    moon_light.light_energy = 1.0
    moon_light.shadow_enabled = true

func _add_ground() -> void:
    var mesh := $Ground
    var plane := mesh.mesh as PlaneMesh
    if plane == null:
        plane = PlaneMesh.new()
        plane.size = Vector2(20.0, 14.0)
        mesh.mesh = plane
    var material := StandardMaterial3D.new()
    material.albedo_color = Color("182b20")
    material.albedo_texture = ground_texture
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    material.roughness = 1.0
    plane.material = material

func _add_walls() -> void:
    _add_wall(Vector3(-10.0, 1.0, 0.0), Vector3(0.5, 2.0, 14.0))
    _add_wall(Vector3(10.0, 1.0, 0.0), Vector3(0.5, 2.0, 14.0))
    _add_wall(Vector3(0.0, 1.0, -7.0), Vector3(20.0, 2.0, 0.5))
    _add_wall(Vector3(0.0, 1.0, 7.0), Vector3(20.0, 2.0, 0.5))

func _add_wall(position: Vector3, size: Vector3) -> void:
    var body := StaticBody3D.new()
    body.position = position
    body.collision_layer = 1
    body.collision_mask = 1
    var collision := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    collision.shape = box_shape
    body.add_child(collision)
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    var material := StandardMaterial3D.new()
    material.albedo_color = Color("26352c")
    box.material = material
    mesh.mesh = box
    body.add_child(mesh)
    add_child(body)

func _add_billboard(texture: Texture2D, position: Vector3, scale_value: float) -> void:
    var sprite := Sprite3D.new()
    sprite.texture = texture
    sprite.pixel_size = 0.01
    sprite.position = position
    sprite.scale = Vector3.ONE * scale_value
    sprite.material_override = _sprite_material()
    add_child(sprite)

func _sprite_material() -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    material.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    return material

func _add_sky_objects() -> void:
    var moon := Sprite3D.new()
    moon.texture = moon_texture
    moon.pixel_size = 0.003
    moon.position = Vector3(-4.0, 5.2, -5.0)
    moon.material_override = _sprite_material()
    add_child(moon)

    var rng := RandomNumberGenerator.new()
    rng.seed = 1777
    for index in range(40):
        var star := Sprite3D.new()
        star.texture = star_texture
        star.pixel_size = rng.randf_range(0.0015, 0.003)
        star.position = Vector3(rng.randf_range(-9.0, 9.0), rng.randf_range(3.0, 7.0), rng.randf_range(-6.0, -2.0))
        star.material_override = _sprite_material()
        add_child(star)

func _build_hud() -> void:
    var canvas := CanvasLayer.new()
    canvas.name = "HUD"
    add_child(canvas)

    var top := ColorRect.new()
    top.position = Vector2(24, 20)
    top.size = Vector2(460, 78)
    top.color = Color(0.03, 0.05, 0.04, 0.86)
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    canvas.add_child(top)

    var title := Label.new()
    title.position = Vector2(18, 8)
    title.size = Vector2(420, 30)
    title.text = "ACORN HUNTER — LEVEL 1"
    title.add_theme_color_override("font_color", Color("ffbac4"))
    title.add_theme_font_size_override("font_size", 21)
    top.add_child(title)

    status_label = Label.new()
    status_label.position = Vector2(18, 39)
    status_label.size = Vector2(420, 28)
    status_label.text = "ОПЕРАЦИЯ ЗАПУЩЕНА"
    status_label.add_theme_color_override("font_color", Color("d1dbd6"))
    status_label.add_theme_font_size_override("font_size", 15)
    top.add_child(status_label)

    count_label = Label.new()
    count_label.position = Vector2(500, 26)
    count_label.size = Vector2(260, 45)
    count_label.text = "ЖЁЛУДИ  0 / %d" % ACORN_POSITIONS.size()
    count_label.add_theme_color_override("font_color", Color("ffecc7"))
    count_label.add_theme_font_size_override("font_size", 23)
    canvas.add_child(count_label)

    crosshair = Label.new()
    crosshair.position = Vector2(0, 0)
    crosshair.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    crosshair.size = Vector2(80, 60)
    crosshair.position -= Vector2(40, 30)
    crosshair.text = "+"
    crosshair.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    crosshair.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    crosshair.add_theme_color_override("font_color", Color("ffe6b4"))
    crosshair.add_theme_font_size_override("font_size", 34)
    crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
    canvas.add_child(crosshair)

    message_label = Label.new()
    message_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    message_label.position = Vector2(-380, -105)
    message_label.size = Vector2(760, 48)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_color_override("font_color", Color("cbd5cf"))
    message_label.add_theme_font_size_override("font_size", 17)
    message_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    canvas.add_child(message_label)

    weapon_view = TextureRect.new()
    weapon_view.texture = weapon_texture
    weapon_view.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    weapon_view.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    weapon_view.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    weapon_view.position = Vector2(-300, -260)
    weapon_view.size = Vector2(300, 260)
    weapon_view.mouse_filter = Control.MOUSE_FILTER_IGNORE
    canvas.add_child(weapon_view)

    _build_joystick(canvas)
    _build_fire_button(canvas)
    _build_minimap(canvas)
    _build_mission_panel(canvas)

func _build_joystick(canvas: CanvasLayer) -> void:
    joystick_base = Panel.new()
    joystick_base.position = Vector2(42, -218)
    joystick_base.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    joystick_base.size = Vector2(176, 176)
    joystick_base.modulate = Color(1, 1, 1, 0.55)
    joystick_base.mouse_filter = Control.MOUSE_FILTER_STOP
    canvas.add_child(joystick_base)

    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.18, 0.24, 0.21, 0.7)
    style.corner_radius_top_left = 88
    style.corner_radius_top_right = 88
    style.corner_radius_bottom_left = 88
    style.corner_radius_bottom_right = 88
    style.border_width_left = 2
    style.border_width_top = 2
    style.border_width_right = 2
    style.border_width_bottom = 2
    style.border_color = Color(0.75, 0.84, 0.79, 0.45)
    joystick_base.add_theme_stylebox_override("panel", style)

    joystick_knob = Panel.new()
    joystick_knob.position = Vector2(53, 53)
    joystick_knob.size = Vector2(70, 70)
    joystick_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
    joystick_base.add_child(joystick_knob)
    var knob_style := StyleBoxFlat.new()
    knob_style.bg_color = Color(0.82, 0.9, 0.86, 0.75)
    knob_style.corner_radius_top_left = 35
    knob_style.corner_radius_top_right = 35
    knob_style.corner_radius_bottom_left = 35
    knob_style.corner_radius_bottom_right = 35
    joystick_knob.add_theme_stylebox_override("panel", knob_style)
    joystick_base.gui_input.connect(_on_joystick_gui_input)

func _on_joystick_gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            joystick_touch_id = event.index
            _set_joystick_from_position(event.position)
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            joystick_vector = Vector2.ZERO
            _reset_joystick()
    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _set_joystick_from_position(event.position)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _set_joystick_from_position(event.position)
        else:
            joystick_vector = Vector2.ZERO
            _reset_joystick()
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        _set_joystick_from_position(event.position)

func _set_joystick_from_position(global_pos: Vector2) -> void:
    var center := joystick_base.global_position + joystick_base.size * 0.5
    var delta := global_pos - center
    var radius := 68.0
    if delta.length() > radius:
        delta = delta.normalized() * radius
    joystick_vector = Vector2(delta.x / radius, delta.y / radius)
    joystick_knob.position = joystick_base.size * 0.5 - joystick_knob.size * 0.5 + delta

func _reset_joystick() -> void:
    joystick_knob.position = joystick_base.size * 0.5 - joystick_knob.size * 0.5

func _build_fire_button(canvas: CanvasLayer) -> void:
    fire_button = Button.new()
    fire_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    fire_button.position = Vector2(-210, -210)
    fire_button.size = Vector2(150, 150)
    fire_button.text = "ОГОНЬ"
    fire_button.add_theme_font_size_override("font_size", 24)
    fire_button.add_theme_color_override("font_color", Color("ffe8d0"))
    fire_button.mouse_filter = Control.MOUSE_FILTER_STOP
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.25, 0.13, 0.12, 0.78)
    style.corner_radius_top_left = 75
    style.corner_radius_top_right = 75
    style.corner_radius_bottom_left = 75
    style.corner_radius_bottom_right = 75
    style.border_width_left = 2
    style.border_width_top = 2
    style.border_width_right = 2
    style.border_width_bottom = 2
    style.border_color = Color(1.0, 0.78, 0.65, 0.55)
    fire_button.add_theme_stylebox_override("normal", style)
    canvas.add_child(fire_button)
    fire_button.pressed.connect(_fire)

func _build_minimap(canvas: CanvasLayer) -> void:
    minimap = Control.new()
    minimap.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    minimap.position = Vector2(-230, 115)
    minimap.size = Vector2(190, 135)
    minimap.mouse_filter = Control.MOUSE_FILTER_IGNORE
    canvas.add_child(minimap)

    var bg := ColorRect.new()
    bg.size = minimap.size
    bg.color = Color(0.02, 0.05, 0.04, 0.82)
    minimap.add_child(bg)

    var border := ColorRect.new()
    border.position = Vector2(2, 2)
    border.size = minimap.size - Vector2(4, 4)
    border.color = Color(0.25, 0.38, 0.31, 0.7)
    border.mouse_filter = Control.MOUSE_FILTER_IGNORE
    minimap.add_child(border)

    var label := Label.new()
    label.position = Vector2(10, 5)
    label.size = Vector2(170, 24)
    label.text = "МИНИКАРТА"
    label.add_theme_color_override("font_color", Color("b9c7be"))
    label.add_theme_font_size_override("font_size", 13)
    minimap.add_child(label)

func _update_minimap() -> void:
    if minimap == null or player == null:
        return
    for child in minimap.get_children():
        if child.name.begins_with("Marker"):
            child.queue_free()

    _add_map_marker("Player", player.position, Color("fff0b8"), 8)
    for acorn in acorn_nodes:
        if is_instance_valid(acorn):
            _add_map_marker("Acorn", acorn.position, Color("ffbac4"), 7)
    for squirrel in squirrel_nodes:
        if is_instance_valid(squirrel):
            var marker_color := Color("9fb8ff") if squirrel.get_meta("stunned", false) else Color("e5e5e5")
            _add_map_marker("Squirrel", squirrel.position, marker_color, 6)

func _add_map_marker(kind: String, world_pos: Vector3, color: Color, size: float) -> void:
    var marker := ColorRect.new()
    marker.name = "Marker_%s" % kind
    var x := clampf((world_pos.x + ARENA_HALF_X) / (ARENA_HALF_X * 2.0) * 178.0, 4.0, 174.0)
    var y := clampf((world_pos.z + ARENA_HALF_Z) / (ARENA_HALF_Z * 2.0) * 123.0 + 8.0, 8.0, 124.0)
    marker.position = Vector2(x - size * 0.5, y - size * 0.5)
    marker.size = Vector2(size, size)
    marker.color = color
    marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
    minimap.add_child(marker)

func _build_mission_panel(canvas: CanvasLayer) -> void:
    mission_panel = Panel.new()
    mission_panel.set_anchors_preset(Control.PRESET_CENTER)
    mission_panel.position = Vector2(-320, -190)
    mission_panel.size = Vector2(640, 380)
    mission_panel.visible = false
    canvas.add_child(mission_panel)

    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.025, 0.04, 0.035, 0.96)
    style.border_width_left = 2
    style.border_width_top = 2
    style.border_width_right = 2
    style.border_width_bottom = 2
    style.border_color = Color("d9c8a0")
    mission_panel.add_theme_stylebox_override("panel", style)

    mission_title = Label.new()
    mission_title.position = Vector2(30, 35)
    mission_title.size = Vector2(580, 60)
    mission_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    mission_title.add_theme_color_override("font_color", Color("ffbac4"))
    mission_title.add_theme_font_size_override("font_size", 31)
    mission_panel.add_child(mission_title)

    mission_body = Label.new()
    mission_body.position = Vector2(40, 115)
    mission_body.size = Vector2(560, 190)
    mission_body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    mission_body.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    mission_body.add_theme_color_override("font_color", Color("e1e7e3"))
    mission_body.add_theme_font_size_override("font_size", 21)
    mission_panel.add_child(mission_body)

    var menu_button := Button.new()
    menu_button.position = Vector2(190, 315)
    menu_button.size = Vector2(260, 45)
    menu_button.text = "В МЕНЮ"
    menu_button.pressed.connect(_on_back_pressed)
    mission_panel.add_child(menu_button)

func _update_count() -> void:
    count_label.text = "ЖЁЛУДИ  %d / %d" % [collected, ACORN_POSITIONS.size()]

func _show_message(text: String, duration: float) -> void:
    if message_label == null:
        return
    message_label.text = text
    message_timer = duration

func _animate_weapon() -> void:
    if weapon_view == null:
        return
    var original := weapon_view.position
    weapon_view.position = original + Vector2(0, 18)
    var tween := create_tween()
    tween.tween_property(weapon_view, "position", original, 0.08)

func _on_back_pressed() -> void:
    get_tree().change_scene_to_file("res://menu.tscn")
