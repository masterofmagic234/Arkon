extends Node3D

# ACORN HUNTER — LEVEL 1 / CLEAN V10
# Design reference: the original Carolina v7 build.
# The new Godot implementation preserves its gameplay language and atmosphere,
# while keeping the proven V6/V8 mobile control path.

const WALK_SPEED := 3.05
const TURN_SPEED := 2.35
const JOYSTICK_RADIUS := 58.0
const ACORN_PICKUP_RADIUS := 0.62
const FIRE_RANGE := 14.0
const WORLD_LAYER := 1
const SQUIRREL_LAYER := 2
const MAX_HP := 100
const MAX_AMMO := 38

var move_axis := Vector2.ZERO
var joystick_touch_id := -1
var mouse_joystick := false
var collected := 0
var ammo := MAX_AMMO
var hp := MAX_HP
var fire_cooldown := 0.0
var recoil_time := 0.0
var message_time := 0.0
var foot_timer := 0.0
var bob := 0.0
var fake_found := false
var mission_complete := false
var mission_failed := false
var muted := false
var stunned: Dictionary = {}
var squirrel_home := {
    "Squirrel01": Vector2(-0.8,-1.8),
    "Squirrel02": Vector2(6.3,-0.3)
}
var squirrel_phase := {"Squirrel01":0.0,"Squirrel02":1.7}
var acorns := ["Acorn01","Acorn02","Acorn03","Acorn04"]
var squirrels := ["Squirrel01","Squirrel02"]

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var joystick: Panel = $HUD/Joystick
@onready var knob: Panel = $HUD/Joystick/Knob
@onready var fire_button: Button = $HUD/Fire
@onready var count_label: Label = $HUD/Count
@onready var hp_ammo_label: Label = $HUD/HPAmmo
@onready var message_label: Label = $HUD/Message
@onready var mission_panel: Panel = $HUD/Mission
@onready var mission_title: Label = $HUD/Mission/Title
@onready var mission_body: Label = $HUD/Mission/Body
@onready var weapon: TextureRect = $HUD/Weapon
@onready var muzzle: ColorRect = $HUD/MuzzleFlash
@onready var hit_marker: Label = $HUD/HitMarker
@onready var mute_button: Button = $HUD/Mute

var music_stream = preload("res://assets/acorn_music.mp3")
var foot1_stream = preload("res://assets/footstep1.wav")
var foot2_stream = preload("res://assets/footstep2.wav")
var shoot_stream = preload("res://assets/shoot.wav")
var squirrel_hit_stream = preload("res://assets/squirrel_hit.wav")
var pickup_stream = preload("res://assets/pickup.wav")
var damage_stream = preload("res://assets/damage.wav")
var stunned_texture = preload("res://assets/squirrel_stunned.png")

var audio_music: AudioStreamPlayer
var audio_fx: AudioStreamPlayer
var rng := RandomNumberGenerator.new()

const ACORN_LINES := [
    "ЖЁЛУДЬ ДОБЫТ. Дарина, ставь чайник.",
    "Один есть. Белки нервничают.",
    "Исторический жёлудь №%d.",
    "Данил сообщает: прогресс подозрительно хороший.",
    "В карман! И никому не отдавать.",
    "Найден. Официально настоящий.",
    "Ещё один — и можно открывать музей.",
    "Жёлудь найден. Серьёзная археология."
]
const CONE_LINES := [
    "ЭТО ШИШКА. Лес тебя переиграл.",
    "Поздравляю: ты нашла не то.",
    "Дарина просила жёлуди, а не ботанику.",
    "Шишка нанесла 12 урона самолюбию.",
    "Неправильный орех. Очень неправильный.",
    "Каролина, это буквально НЕ ЖЁЛУДЬ.",
    "Лес говорит: внимательнее, пожалуйста."
]
const HIT_LINES := [
    "ПОПАЛА. Белка задумалась о жизни.",
    "Белка получила аргумент.",
    "Точно в пушистую проблему.",
    "Попадание! Белка пересматривает карьеру.",
    "Минус одна попытка украсть жёлудь.",
    "Белка: это было неожиданно.",
    "Тихо. Я всё видела. Отличный выстрел."
]
const STUN_LINES := [
    "Белка контужена. Звёздочки прилагаются.",
    "Белка прилегла подумать.",
    "Пушистый отпуск объявлен досрочно.",
    "Белка временно недееспособна. Достойно.",
    "Она не мёртвая. Она просто очень впечатлена.",
    "Звёздочки — официальный эффект поражения.",
    "Белка выбыла. Жёлуди в безопасности."
]
const DAMAGE_LINES := [
    "АЙ! Белка кусается.",
    "Урон. Пушистый террор продолжается.",
    "Белка сказала: не подходи.",
    "Это было больно. Очень по-беличьи."
]

func _ready() -> void:
    # Level horizon: no vertical look input and no hidden pitch.
    camera.rotation = Vector3.ZERO
    camera.fov = 68.0
    camera.near = 0.05
    camera.far = 35.0
    player.rotation.y = 0.0
    mission_panel.visible = false
    hit_marker.visible = false
    muzzle.visible = false
    knob.position = joystick.size * 0.5 - knob.size * 0.5
    rng.seed = 7
    _setup_audio()
    _update_hud()
    _set_message("Парк открыт. Дубы не прячутся — жёлуди тоже.", 2.8)
    _refresh_minimap()

func _setup_audio() -> void:
    audio_music = AudioStreamPlayer.new()
    audio_music.stream = music_stream
    audio_music.volume_db = -9.0
    add_child(audio_music)
    audio_fx = AudioStreamPlayer.new()
    add_child(audio_fx)
    if not muted:
        audio_music.play()

func _physics_process(delta: float) -> void:
    if mission_complete or mission_failed:
        player.velocity = Vector3.ZERO
        return

    var forward := -move_axis.y
    var turn := move_axis.x
    if abs(turn) > 0.035:
        player.rotate_y(-turn * TURN_SPEED * delta)

    var direction := -player.global_transform.basis.z
    player.velocity = direction * (forward * WALK_SPEED)
    player.velocity.y = 0.0
    player.move_and_slide()

    # Hard guarantee against accidental pitch/roll drift.
    camera.rotation.x = 0.0
    camera.rotation.z = 0.0

    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    recoil_time = maxf(0.0, recoil_time - delta)
    message_time = maxf(0.0, message_time - delta)

    if message_time <= 0.0:
        message_label.text = ""
    if recoil_time <= 0.0:
        weapon.position.y = 455.0
    if muzzle.visible:
        muzzle.modulate.a = clampf(muzzle.modulate.a - delta * 8.0, 0.0, 1.0)
        if muzzle.modulate.a <= 0.0:
            muzzle.visible = false

    if abs(forward) > 0.05:
        bob += delta * 10.0
        foot_timer -= delta
        if foot_timer <= 0.0:
            _footstep()
            foot_timer = 0.30
        weapon.position.y = 455.0 + sin(bob) * 2.5 - (0.0 if recoil_time <= 0.0 else 16.0)
    else:
        foot_timer = 0.0

    _update_squirrels(delta)
    _collect_acorns()
    _check_fake_cone()
    _update_hud()
    _refresh_minimap()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            if _point_in_rect(event.position, joystick.get_global_rect()):
                joystick_touch_id = event.index
                _update_joystick(event.position)
                get_viewport().set_input_as_handled()
            elif _point_in_rect(event.position, fire_button.get_global_rect()):
                _on_fire_pressed()
                get_viewport().set_input_as_handled()
            elif _point_in_rect(event.position, mute_button.get_global_rect()):
                _toggle_music()
                get_viewport().set_input_as_handled()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            get_viewport().set_input_as_handled()
    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _update_joystick(event.position)
        get_viewport().set_input_as_handled()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            if _point_in_rect(event.position, joystick.get_global_rect()):
                mouse_joystick = true
                _update_joystick(event.position)
            elif _point_in_rect(event.position, fire_button.get_global_rect()):
                _on_fire_pressed()
            elif _point_in_rect(event.position, mute_button.get_global_rect()):
                _toggle_music()
        elif mouse_joystick:
            mouse_joystick = false
            move_axis = Vector2.ZERO
            _reset_joystick()
    elif event is InputEventMouseMotion and mouse_joystick:
        _update_joystick(event.position)

func _point_in_rect(point: Vector2, rect: Rect2) -> bool:
    return rect.has_point(point)

func _update_joystick(position: Vector2) -> void:
    var center := joystick.get_global_rect().get_center()
    var delta := position - center
    if delta.length() > JOYSTICK_RADIUS:
        delta = delta.normalized() * JOYSTICK_RADIUS
    move_axis = Vector2(delta.x / JOYSTICK_RADIUS, delta.y / JOYSTICK_RADIUS)
    knob.position = joystick.size * 0.5 - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func _on_fire_pressed() -> void:
    if mission_complete or mission_failed or fire_cooldown > 0.0:
        return
    if ammo <= 0:
        _set_message("Щёлк. Пусто. Даже белки засмеялись.", 0.8)
        return

    ammo -= 1
    fire_cooldown = 0.20
    recoil_time = 0.10
    weapon.position.y = 471.0
    muzzle.visible = true
    muzzle.modulate.a = 1.0
    _play_fx(shoot_stream)

    var query := PhysicsRayQueryParameters3D.create(
        camera.global_position,
        camera.global_position + (-camera.global_transform.basis.z * FIRE_RANGE),
        SQUIRREL_LAYER | WORLD_LAYER
    )
    query.collide_with_areas = true
    query.collide_with_bodies = true
    var hit := get_world_3d().direct_space_state.intersect_ray(query)

    if hit.is_empty():
        _miss()
        return

    var squirrel := _find_squirrel_from_collider(hit.get("collider"))
    if squirrel == "":
        _miss()
        return

    # A squirrel can be hit only once. After that, every further shot is a miss.
    if stunned.has(squirrel):
        _miss()
        return

    stunned[squirrel] = true
    var target := get_node_or_null(squirrel) as Sprite3D
    if target:
        target.texture = stunned_texture
        target.rotation.z = deg_to_rad(-8.0)
        target.modulate = Color(1,1,1,1)
    hit_marker.visible = true
    hit_marker.text = "×"
    _play_fx(squirrel_hit_stream)
    _set_message(STUN_LINES[rng.randi_range(0, STUN_LINES.size()-1)], 1.25)
    await get_tree().create_timer(0.28).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _find_squirrel_from_collider(collider: Object) -> String:
    if collider == null:
        return ""
    var node := collider as Node
    while node:
        if squirrels.has(node.name):
            return node.name
        node = node.get_parent()
    return ""

func _miss() -> void:
    hit_marker.visible = true
    hit_marker.text = "•"
    _set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.0)
    await get_tree().create_timer(0.20).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _update_squirrels(delta: float) -> void:
    var pp := Vector2(player.global_position.x, player.global_position.z)
    for name in squirrels:
        if stunned.has(name):
            continue
        var node := get_node_or_null(name) as Sprite3D
        if node == null:
            continue
        var home: Vector2 = squirrel_home[name]
        var d := home.distance_to(pp)
        if d < 6.2 and d > 1.1:
            var away := (home - pp).normalized()
            var side := Vector2(-away.y, away.x) * sin(Time.get_ticks_msec()*0.001 + float(squirrel_phase[name])) * 0.12
            var proposed := home + (away * 0.040 + side * 0.020)
            if _can_squirrel_stand(proposed.x, proposed.y):
                squirrel_home[name] = proposed
                node.position.x = proposed.x
                node.position.z = proposed.y
        node.rotation.z = sin(Time.get_ticks_msec()*0.003 + float(squirrel_phase[name])) * 0.025
        if d < 0.70:
            hp = max(0, hp - int(18.0 * delta))
            if int(Time.get_ticks_msec()/250) % 2 == 0:
                _set_message(DAMAGE_LINES[rng.randi_range(0,DAMAGE_LINES.size()-1)], 0.55)
            if hp <= 0:
                _fail()

func _can_squirrel_stand(x: float, z: float) -> bool:
    var q := PhysicsRayQueryParameters3D.create(Vector3(x,0.9,z), Vector3(x,0.9,z))
    # Static collision is handled by CharacterBody movement; this lightweight check
    # uses the actual scene wall cells via their collision layer.
    return x > -9.1 and x < 9.1 and z > -6.1 and z < 6.1

func _collect_acorns() -> void:
    for name in acorns.duplicate():
        var node := get_node_or_null(name) as Sprite3D
        if node and node.visible and player.global_position.distance_to(node.global_position) <= ACORN_PICKUP_RADIUS:
            node.visible = false
            acorns.erase(name)
            collected += 1
            _play_fx(pickup_stream)
            var line_index := rng.randi_range(0, ACORN_LINES.size() - 1)
            var line := ACORN_LINES[line_index]
            if line_index == 2:
                line = line % collected
            _set_message(line, 1.45)
            if collected == 4:
                _complete()

func _check_fake_cone() -> void:
    if fake_found:
        return
    var cone := get_node_or_null("FakePineCone") as Sprite3D
    if cone and cone.visible and player.global_position.distance_to(cone.global_position) <= 0.78:
        fake_found = true
        cone.visible = false
        hp = max(0, hp - 12)
        _play_fx(damage_stream)
        _set_message(CONE_LINES[rng.randi_range(0,CONE_LINES.size()-1)], 1.45)
        if hp <= 0:
            _fail()

func _complete() -> void:
    mission_complete = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    mission_body.text = "ЖЁЛУДИ: 4 / 4\n\nОН СУЩЕСТВУЕТ.\n\nДарина может делать поделку.\n\nP.S. Данил всё это время верил в тебя."
    weapon.visible = false

func _fail() -> void:
    mission_failed = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ПРОВАЛЕНА"
    mission_body.text = "HP: 0\n\nБелки оказались сильнее.\nЭто позор, но кинематографично.\n\nДарина всё ещё ждёт жёлуди."
    weapon.visible = false

func _on_retry_pressed() -> void:
    get_tree().reload_current_scene()

func _on_menu_pressed() -> void:
    get_tree().change_scene_to_file("res://menu.tscn")

func _update_hud() -> void:
    count_label.text = "ЖЁЛУДИ  %d / 4" % collected
    hp_ammo_label.text = "HP %d     AMMO %d" % [hp, ammo]

func _set_message(text: String, duration: float) -> void:
    message_label.text = text
    message_time = duration

func _footstep() -> void:
    if muted:
        return
    audio_fx.stream = foot1_stream if int(Time.get_ticks_msec()/300) % 2 == 0 else foot2_stream
    audio_fx.volume_db = -12.0
    audio_fx.play()

func _play_fx(stream: AudioStream) -> void:
    if muted:
        return
    audio_fx.stream = stream
    audio_fx.volume_db = -6.0
    audio_fx.play()

func _toggle_music() -> void:
    muted = not muted
    mute_button.text = "×" if muted else "♪"
    if muted:
        audio_music.stop()
    elif not audio_music.playing:
        audio_music.play()
    _set_message("Музыка выключена." if muted else "Музыка возвращена. Белки снова слышат угрозу.", 1.3)

func _refresh_minimap() -> void:
    if $HUD/Minimap.has_method("set_game_state"):
        $HUD/Minimap.set_game_state(player.global_position, player.rotation.y, acorns, squirrels, stunned)
