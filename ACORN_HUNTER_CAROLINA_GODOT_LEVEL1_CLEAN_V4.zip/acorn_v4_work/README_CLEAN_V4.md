# ACORN HUNTER — CLEAN V4

V4 is a static-first rebuild after Android showed only the scene's static camera/ground and HUD in V3.

The visible Level 1 world is now authored directly in `game.tscn`: camera, environment, ground, trees, acorns, squirrels, fake pine cone, moon, stars, and HUD all exist before gameplay code runs. The gameplay script is deliberately small and only handles movement, collection, fire feedback, and mission completion.

This avoids making the first frame depend on a large `_ready()` construction routine.

Godot 4.7 Sprite3D billboard mode is used for the 2.5D retro sprites, and the floor uses a PlaneMesh with a StandardMaterial3D.

The project has not been executed locally because Godot/Android runtime is not installed in the current environment.
