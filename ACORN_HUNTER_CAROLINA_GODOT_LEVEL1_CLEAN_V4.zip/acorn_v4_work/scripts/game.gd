extends Node3D

const SPEED := 3.8
const ARENA_X := 8.8
const ARENA_Z := 5.8

var move_vector := Vector2.ZERO
var joystick_id := -1
var collected := 0
var stunned := 0
var message_time := 0.0
var acorns := ["Acorn01", "Acorn02", "Acorn03", "Acorn04"]
var squirrels := ["Squirrel01", "Squirrel02", "Squirrel03"]

@onready var camera = $Camera3D
@onready var count_label = $HUD/Count
@onready var message_label = $HUD/Message
@onready var mission_panel = $HUD/Mission
@onready var joystick = $HUD/Joystick
@onready var knob = $HUD/Joystick/Knob

func _ready() -> void:
    mission_panel.visible = false
    joystick.gui_input.connect(_on_joystick_input)
    _set_message("Парк найден. Жёлуди существуют. Белки пока ничего не подозревают.", 4.0)

func _process(delta: float) -> void:
    if message_time > 0.0:
        message_time -= delta
        if message_time <= 0.0:
            message_label.text = ""
    var direction := Vector3(move_vector.x, 0.0, move_vector.y)
    camera.position += direction * SPEED * delta
    camera.position.x = clamp(camera.position.x, -ARENA_X, ARENA_X)
    camera.position.z = clamp(camera.position.z, -ARENA_Z, ARENA_Z)
    _collect_acorns()

func _collect_acorns() -> void:
    for name in acorns.duplicate():
        var node = get_node_or_null(name)
        if node != null and camera.position.distance_to(node.position) < 1.25:
            node.visible = false
            acorns.erase(name)
            collected += 1
            count_label.text = "ЖЁЛУДИ  %d / 4" % collected
            if collected == 4:
                _complete()
            else:
                _set_message("Жёлудь добыт. Дарина будет довольна. Ещё %d." % (4 - collected), 1.8)

func _on_fire_pressed() -> void:
    if mission_panel.visible:
        return
    var nearest = ""
    var nearest_distance := 999.0
    for name in squirrels:
        var node = get_node_or_null(name)
        if node != null and node.visible:
            var distance = camera.position.distance_to(node.position)
            if distance < nearest_distance:
                nearest_distance = distance
                nearest = name
    if nearest != "" and nearest_distance < 8.0:
        get_node(nearest).modulate = Color(0.55, 0.72, 1.0, 1.0)
        stunned += 1
        _set_message("БЕЛКА ОГЛУШЕНА. Операция всё ещё засекречена.", 1.5)
    else:
        _set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.2)

func _on_menu_pressed() -> void:
    get_tree().change_scene_to_file("res://menu.tscn")

func _complete() -> void:
    mission_panel.visible = true
    $HUD/Mission/Title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    $HUD/Mission/Body.text = "ЖЁЛУДИ: 4 / 4\n\nОН СУЩЕСТВУЕТ.\n\nP.S. Данил всё это время верил в тебя."

func _set_message(text: String, duration: float) -> void:
    message_label.text = text
    message_time = duration

func _on_joystick_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            joystick_id = event.index
            _update_joystick(event.position)
        elif event.index == joystick_id:
            joystick_id = -1
            move_vector = Vector2.ZERO
            _reset_joystick()
    elif event is InputEventScreenDrag and event.index == joystick_id:
        _update_joystick(event.position)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _update_joystick(event.position)
        else:
            move_vector = Vector2.ZERO
            _reset_joystick()
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        _update_joystick(event.position)

func _update_joystick(position: Vector2) -> void:
    var center := joystick.global_position + joystick.size * 0.5
    var delta := position - center
    var radius := 58.0
    if delta.length() > radius:
        delta = delta.normalized() * radius
    move_vector = Vector2(delta.x / radius, delta.y / radius)
    knob.position = joystick.size * 0.5 - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5
