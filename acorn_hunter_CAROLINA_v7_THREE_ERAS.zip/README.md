ACORN HUNTER — WORLD-SPACE FLOOR V13

Classic scanline floor casting based on established raycaster technique. Grass and stone are separate world-aligned textures. The stone path is stored in map space and generated as a 4-neighbour network from the spawn to each acorn cell, so turns and intersections follow level geometry rather than the camera. Performance uses a small 360x202 floor buffer, then one scaled bitmap draw.
