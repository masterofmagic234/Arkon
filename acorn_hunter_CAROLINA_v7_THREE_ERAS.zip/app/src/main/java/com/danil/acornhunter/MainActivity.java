package com.danil.acornhunter;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import java.util.*;

/**
 * Acorn Hunter v11 — Performance Baseline.
 * V6.2 gameplay/rendering retained; only the lightweight world-space sky is updated.
 * Original raycasting renderer inspired by early 90s corridor FPS design.
 * Uses supplied Carolina portrait and supplied music, plus original pixel-art assets.
 */
public class MainActivity extends Activity {
    MediaPlayer music;
    ToneGenerator tones;
    SoundPool soundPool;
    int footstep1, footstep2, squirrelHitSound;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        hideSystemUI();
        tones = new ToneGenerator(AudioManager.STREAM_MUSIC, 45);
        soundPool = new SoundPool.Builder().setMaxStreams(4).build();
        footstep1 = soundPool.load(this, R.raw.footstep1, 1);
        footstep2 = soundPool.load(this, R.raw.footstep2, 1);
        squirrelHitSound = soundPool.load(this, R.raw.squirrel_hit, 1);
        music = MediaPlayer.create(this, R.raw.acorn_music);
        if (music != null) { music.setLooping(true); music.setVolume(0.28f, 0.28f); }
        setContentView(new GameView(this));
    }

    void hideSystemUI() {
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        w.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        }
    }

    void beep(int type) { if (tones != null) try { tones.startTone(type, 80); } catch(Exception ignored){} }

    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if(hasFocus) hideSystemUI(); }
    @Override protected void onPause() { super.onPause(); if(music!=null && music.isPlaying()) music.pause(); }
    @Override protected void onResume() { super.onResume(); hideSystemUI(); }
    @Override protected void onDestroy() { if(music!=null){music.release();music=null;} if(tones!=null){tones.release();tones=null;} if(soundPool!=null){soundPool.release();soundPool=null;} super.onDestroy(); }

    static class GameView extends View {
        final MainActivity host;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint spritePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        final Random rnd = new Random(7);
        Bitmap face, oakSprite, squirrelSprite, acornSprite, pineSprite;

        // 0 title, 1 playing, 2 level complete, 3 victory, 4 defeat
        int screen=0, level=1, found=0, hp=100, ammo=32;
        boolean muted=false, firing=false;
        long fireUntil=0, lastFrame=System.nanoTime(), lastEnemyThink=0, toastUntil=0;
        String toast="";
        double playerX=2.5, playerY=2.5, angle=0;
        float bob=0, joystickX=0, joystickY=0, touchStartX, touchStartY;
        long nextFootstep=0; boolean footToggle=false;
        boolean joystickActive=false;
        int activePointer=-1;
        float[] depth;
        // World-space floor renderer (classic horizontal scanline floor casting).
        static final int FLOOR_W=360, FLOOR_H=202;
        int[] floorPixels = new int[FLOOR_W*FLOOR_H];
        Bitmap floorBitmap;
        int[] grassPixels, stonePixels;
        int TEX=128;
        boolean[][] pathMap = new boolean[14][20];

        final int MAP_W=20, MAP_H=14;
        int[][] map;
        ArrayList<Item> acorns=new ArrayList<>(), fakes=new ArrayList<>();
        ArrayList<Enemy> enemies=new ArrayList<>();
        ArrayList<Tree> trees=new ArrayList<>();

        static class Item { double x,y; boolean alive=true; Item(double x,double y){this.x=x;this.y=y;} }
        static class Enemy { double x,y; int hp=2; boolean alive=true; long hitFlash=0; Enemy(double x,double y){this.x=x;this.y=y;} }
        static class Tree { double x,y; boolean pine; Tree(double x,double y,boolean pine){this.x=x;this.y=y;this.pine=pine;} }
        static class Sprite { double x,y,d; int type; Object obj; Sprite(double x,double y,double d,int type,Object obj){this.x=x;this.y=y;this.d=d;this.type=type;this.obj=obj;} }

        // 0 = walkable park/forest, 1 = hedge/fence boundary.
        final int[][][] MAPS = new int[][][]{
            {
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,1,1,1,0,0,0,1,1,0,0,0,0,0,1},
                {1,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,1},
                {1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1},
                {1,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1},
                {1,0,1,1,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1},
                {1,0,0,0,1,1,1,0,1,0,1,1,1,0,0,0,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
                {1,0,0,1,1,1,0,0,1,1,1,0,0,0,0,0,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
            },
            {
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,1,1,0,0,0,1,1,1,0,0,0,0,1,1,0,0,0,1},
                {1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,1},
                {1,0,0,0,1,1,0,1,0,0,1,1,1,0,0,1,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,1},
                {1,0,1,0,0,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1},
                {1,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1},
                {1,0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,1,1,1,0,0,1,1,0,1,1,0,0,0,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
            },
            {
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,1,0,1,1,0,0,0,1,1,0,0,0,1,0,1,1,0,1},
                {1,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,1},
                {1,0,1,1,1,0,1,1,1,0,0,0,1,1,1,0,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,1,1,1,0,1,1,1,0,1,1,0,0,0,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,1,1,0,1,1,0,1,1,0,0,1,1,0,1,1,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
            }
        };

        GameView(Context c){
            super(c); host=(MainActivity)c; setFocusable(true);
            face=BitmapFactory.decodeResource(getResources(),R.drawable.carolina_face);
            oakSprite=BitmapFactory.decodeResource(getResources(),R.drawable.oak_tree);
            squirrelSprite=BitmapFactory.decodeResource(getResources(),R.drawable.squirrel);
            acornSprite=BitmapFactory.decodeResource(getResources(),R.drawable.acorn);
            pineSprite=BitmapFactory.decodeResource(getResources(),R.drawable.pine_tree);
            Bitmap grassTex=BitmapFactory.decodeResource(getResources(),R.drawable.grass_tile);
            Bitmap stoneTex=BitmapFactory.decodeResource(getResources(),R.drawable.stone_path_tile);
            grassPixels=new int[TEX*TEX]; stonePixels=new int[TEX*TEX];
            grassTex.getPixels(grassPixels,0,TEX,0,0,TEX,TEX);
            stoneTex.getPixels(stonePixels,0,TEX,0,0,TEX,TEX);
            floorBitmap=Bitmap.createBitmap(FLOOR_W,FLOOR_H,Bitmap.Config.ARGB_8888);
        }

        void begin(){ screen=1; level=1; hp=100; muted=false; if(host.music!=null&&!muted&&!host.music.isPlaying())host.music.start(); loadLevel(); }

        void loadLevel(){
            screen=1;
            map=MAPS[level-1]; found=0; ammo=30+level*8; hp=Math.min(100,hp+10);
            acorns.clear();fakes.clear();enemies.clear();trees.clear();
            playerX=1.5; playerY=1.5; angle=0.0;
            buildForest();
            buildPathNetwork();
            toast = level==1 ? "Парк открыт. Ищи дубы — жёлуди рядом." : level==2 ? "Белки охраняют дубы. Не дай им помешать." : "Последний рейд. Все жёлуди — у дубов.";
            toastUntil=System.currentTimeMillis()+2600; invalidate();
        }

        void buildForest(){
            if(level==1){
                oak(5.5,2.5,true); oak(10.5,2.5,false); oak(14.5,3.5,false); oak(3.5,6.5,false); oak(8.5,6.5,false); oak(13.5,7.5,true); oak(17.5,8.5,false); oak(5.5,11.5,false); oak(12.5,11.5,false);
                acornNear(5.5,2.5,.22); acornNear(10.5,2.5,-.28); acornNear(14.5,3.5,.20); acornNear(13.5,7.5,-.22);
                squirrel(9.2,5.2); squirrel(16.3,6.7);
                fakeNear(3.5,6.5);
            } else if(level==2){
                oak(3.5,2.5,false); oak(6.5,4.5,true); oak(11.5,2.5,false); oak(15.5,3.5,false); oak(4.5,7.5,false); oak(9.5,7.5,true); oak(14.5,8.5,false); oak(17.5,11.5,false); oak(7.5,11.5,false); oak(12.5,12.0,false);
                acornNear(3.5,2.5,.20); acornNear(6.5,4.5,-.24); acornNear(11.5,2.5,.22); acornNear(14.5,8.5,-.20); acornNear(17.5,11.5,.18);
                squirrel(8.5,3.2); squirrel(13.5,5.8); squirrel(5.5,9.5); squirrel(15.5,10.5);
                fakeNear(9.5,7.5); fakeNear(12.5,12.0);
            } else {
                oak(3.5,2.5,true); oak(7.5,2.5,false); oak(12.5,2.5,false); oak(17.0,3.5,false); oak(4.5,5.5,false); oak(9.5,5.5,true); oak(14.5,6.5,false); oak(17.0,8.5,false); oak(5.5,9.5,false); oak(10.5,9.5,false); oak(15.5,11.5,true); oak(7.5,12.0,false);
                acornNear(3.5,2.5,.20); acornNear(7.5,2.5,-.22); acornNear(12.5,2.5,.20); acornNear(4.5,5.5,-.20); acornNear(9.5,5.5,.22); acornNear(15.5,11.5,-.22); acornNear(7.5,12.0,.18);
                squirrel(6.0,3.7); squirrel(11.0,4.0); squirrel(15.5,5.0); squirrel(7.0,8.0); squirrel(12.5,8.0); squirrel(16.0,10.0);
                fakeNear(14.5,6.5); fakeNear(10.5,9.5); fakeNear(5.5,9.5);
            }
        }
        void buildPathNetwork(){
            for(int y=0;y<MAP_H;y++) Arrays.fill(pathMap[y],false);
            int startX=(int)Math.floor(playerX), startY=(int)Math.floor(playerY);
            // The park's stone path is a real map-space network: connect the start
            // cell to every acorn cell with 4-neighbour shortest paths. This makes
            // branches and intersections follow the level geometry, not the camera.
            ArrayList<int[]> targets=new ArrayList<>();
            for(Item a:acorns) targets.add(new int[]{(int)Math.floor(a.x),(int)Math.floor(a.y)});
            for(int[] t:targets){
                if(t[0]<0||t[1]<0||t[0]>=MAP_W||t[1]>=MAP_H||map[t[1]][t[0]]!=0) continue;
                int[][] px=new int[MAP_H][MAP_W], py=new int[MAP_H][MAP_W];
                for(int yy=0;yy<MAP_H;yy++) Arrays.fill(px[yy],-2);
                ArrayDeque<int[]> q=new ArrayDeque<>();
                q.add(new int[]{startX,startY}); px[startY][startX]=-1; py[startY][startX]=-1;
                int[] dx={1,-1,0,0},dy={0,0,1,-1};
                boolean reached=false;
                while(!q.isEmpty()&&!reached){
                    int[] cur=q.removeFirst();
                    if(cur[0]==t[0]&&cur[1]==t[1]){reached=true;break;}
                    for(int k=0;k<4;k++){
                        int nx=cur[0]+dx[k], ny=cur[1]+dy[k];
                        if(nx<0||ny<0||nx>=MAP_W||ny>=MAP_H||map[ny][nx]!=0||px[ny][nx]!=-2) continue;
                        px[ny][nx]=cur[0]; py[ny][nx]=cur[1]; q.addLast(new int[]{nx,ny});
                    }
                }
                if(!reached) continue;
                int cx=t[0], cy=t[1];
                while(cx>=0&&cy>=0){
                    pathMap[cy][cx]=true;
                    if(cx==startX&&cy==startY) break;
                    int nx=px[cy][cx], ny=py[cy][cx];
                    cx=nx; cy=ny;
                }
            }
        }

        void oak(double x,double y,boolean pineIgnored){ trees.add(new Tree(x,y,false)); }
        void acornNear(double x,double y,double off){ acorns.add(new Item(x+Math.cos(off)*.48,y+Math.sin(off)*.48)); }
        void fakeNear(double x,double y){ fakes.add(new Item(x+.34,y+.34)); }
        void squirrel(double x,double y){ enemies.add(new Enemy(x,y)); }

        boolean wall(double x,double y){ int ix=(int)Math.floor(x),iy=(int)Math.floor(y); if(ix<0||iy<0||ix>=MAP_W||iy>=MAP_H)return true; return map[iy][ix]!=0; }
        boolean treeSolid(double x,double y){ for(Tree t:trees) if(Math.hypot(x-t.x,y-t.y)<.27)return true; return false; }
        boolean canStand(double x,double y){ double r=.14; return !wall(x-r,y-r)&&!wall(x+r,y-r)&&!wall(x-r,y+r)&&!wall(x+r,y+r)&&!treeSolid(x,y); }
        double normAngle(double a){while(a<-Math.PI)a+=Math.PI*2;while(a>Math.PI)a-=Math.PI*2;return a;}
        double dist(double x,double y,double x2,double y2){return Math.hypot(x-x2,y-y2);}

        void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.create(Typeface.DEFAULT,Typeface.BOLD):Typeface.create(Typeface.DEFAULT,Typeface.NORMAL));c.drawText(s,x,y,p);}
        void txtCenter(Canvas c,String s,float cx,float y,float size,int color,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.create(Typeface.DEFAULT,Typeface.BOLD):Typeface.create(Typeface.DEFAULT,Typeface.NORMAL));c.drawText(s,cx-p.measureText(s)/2f,y,p);}

        void playFootstep(){
            if(host.soundPool==null || muted) return;
            long now=System.currentTimeMillis();
            if(now<nextFootstep) return;
            int id=footToggle?host.footstep2:host.footstep1; footToggle=!footToggle;
            host.soundPool.play(id,0.20f,0.20f,1,0,1.0f);
            nextFootstep=now+310;
        }

        void update(float dt){
            if(screen!=1)return;
            double forward=-joystickY, turn=joystickX;
            if(joystickActive){ angle+=turn*2.45*dt; double speed=(1.45+level*.08)*forward*dt; movePlayer(Math.cos(angle)*speed,Math.sin(angle)*speed); bob+=Math.abs(speed)*18; if(Math.abs(speed)>.008) playFootstep(); }
            long now=System.currentTimeMillis();
            if(now-lastEnemyThink>90){
                lastEnemyThink=now;
                for(Enemy e:enemies) if(e.alive){
                    double d=dist(playerX,playerY,e.x,e.y);
                    if(d<5.8&&d>.72){ double step=.015; double ex=(playerX-e.x)/d*step,ey=(playerY-e.y)/d*step; if(canEnemyStand(e.x+ex,e.y+ey)){e.x+=ex;e.y+=ey;} }
                    if(d<.70){hp-=1;if(hp<=0){hp=0;screen=4;toast="Белки победили. Это позор.";toastUntil=System.currentTimeMillis()+1600;}}
                }
            }
            for(int i=acorns.size()-1;i>=0;i--) if(acorns.get(i).alive&&dist(playerX,playerY,acorns.get(i).x,acorns.get(i).y)<.40){acorns.remove(i);found++;host.beep(ToneGenerator.TONE_PROP_BEEP2);toast=found==1?"Первый жёлудь. История движется.":found==2?"Данил сообщает: прогресс исторический.":"ЖЁЛУДЬ! Дарина одобряет.";toastUntil=System.currentTimeMillis()+1300;}
            for(int i=fakes.size()-1;i>=0;i--) if(fakes.get(i).alive&&dist(playerX,playerY,fakes.get(i).x,fakes.get(i).y)<.38){fakes.remove(i);hp-=12;host.beep(ToneGenerator.TONE_PROP_NACK);toast="Это не жёлудь. Это ШИШКА.";toastUntil=System.currentTimeMillis()+1100;if(hp<=0){hp=0;screen=4;}}
            if(found>=acornGoal()){screen=2;toast="Уровень пройден.";toastUntil=System.currentTimeMillis()+1400;}
            if(firing&&System.currentTimeMillis()<fireUntil)shoot();
        }
        boolean canEnemyStand(double x,double y){double r=.14;return !wall(x-r,y-r)&&!wall(x+r,y-r)&&!wall(x-r,y+r)&&!wall(x+r,y+r)&&!treeSolid(x,y);}
        int acornGoal(){return level==1?4:level==2?5:7;}

        void movePlayer(double dx,double dy){double nx=playerX+dx,ny=playerY+dy;if(canStand(nx,playerY))playerX=nx;if(canStand(playerX,ny))playerY=ny;}

        void shoot(){
            if(ammo<=0){toast="Пусто. Даже белки в шоке.";toastUntil=System.currentTimeMillis()+700;firing=false;return;}
            ammo--;firing=false;fireUntil=System.currentTimeMillis()+120;host.beep(ToneGenerator.TONE_PROP_BEEP);
            Enemy best=null;double bestD=99;
            for(Enemy e:enemies)if(e.alive){double dx=e.x-playerX,dy=e.y-playerY,d=Math.hypot(dx,dy),rel=Math.abs(normAngle(Math.atan2(dy,dx)-angle));if(rel<.105&&d<8&&d<bestD&&clearLine(e.x,e.y)){best=e;bestD=d;}}
            if(best!=null){
                best.hp--; best.hitFlash=System.currentTimeMillis()+120;
                if(host.soundPool!=null && !muted) host.soundPool.play(host.squirrelHitSound,0.42f,0.42f,1,0,1.0f);
                if(best.hp<=0){best.alive=false;toast="БЕЛКА ПОВЕРЖЕНА.";toastUntil=System.currentTimeMillis()+900;}else{toast="ПОПАЛА.";toastUntil=System.currentTimeMillis()+500;}
            }
        }
        boolean clearLine(double tx,double ty){double dx=tx-playerX,dy=ty-playerY,d=Math.hypot(dx,dy);int steps=(int)(d*22);for(int i=1;i<steps;i++){double x=playerX+dx*i/steps,y=playerY+dy*i/steps;if(wall(x,y))return false;}return true;}

        void raycast(Canvas c,int w,int h){
            // Sky: keep the V11 world-space/twinkle treatment.
            float horizon=h*.47f;
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0,0,0,horizon,Color.rgb(10,18,35),Color.rgb(39,51,73),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,horizon,p); p.setShader(null);
            float skyCx=w*.50f;
            float skySpan=w*1.35f;
            float skyShift=(float)(angle/(Math.PI*2.0)*skySpan);
            p.setColor(Color.argb(210,245,245,225));
            int[] starsX={31,97,164,231,304,377,449,521,598,672,748,823,901,977};
            int[] starsY={44,81,29,119,67,153,38,92,137,55,108,26,146,74};
            int[] starsR={1,1,2,1,1,2,1,1,2,1,1,2,1,1};
            for(int i=0;i<starsX.length;i++){
                float sx=skyCx+starsX[i]-w*.50f-skyShift;
                while(sx<-20)sx+=skySpan; while(sx>w+20)sx-=skySpan;
                float twinkle=0.75f+0.25f*(float)Math.sin(System.nanoTime()/900000000.0+starsX[i]);
                p.setAlpha((int)(210*twinkle)); c.drawCircle(sx,starsY[i],starsR[i],p);
            }
            p.setAlpha(255);
            float moonBase=w*.76f, moonX=moonBase-skyShift*.72f;
            while(moonX<-70)moonX+=skySpan*.72f; while(moonX>w+70)moonX-=skySpan*.72f;
            float moonY=h*.15f,mr=Math.min(w,h)*.035f;
            p.setColor(Color.rgb(235,236,210));c.drawCircle(moonX,moonY,mr,p);
            p.setColor(Color.rgb(15,22,38));c.drawCircle(moonX+mr*.45f,moonY-mr*.42f,mr*.88f,p);

            renderTexturedFloor();
            c.drawBitmap(floorBitmap,null,new RectF(0,0,w,h),spritePaint);

            int rays=Math.min(520,Math.max(260,w/3)); depth=new float[rays]; double fov=Math.toRadians(68),step=fov/rays; float colW=(float)w/rays;
            for(int i=0;i<rays;i++){
                double ra=angle-fov/2+step*(i+.5),cos=Math.cos(ra),sin=Math.sin(ra),rx=playerX,ry=playerY,d=0;
                while(d<22){rx+=cos*.035;ry+=sin*.035;d+=.035;if(wall(rx,ry))break;}
                double corrected=d*Math.cos(ra-angle); depth[i]=(float)corrected;
                float wallH=(float)Math.min(h*1.55,h/(Math.max(.20,corrected))*.52),top=horizon-wallH/2f,bottom=horizon+wallH/2f;
                int shade=(int)Math.max(28,118-corrected*9);
                int r=Math.max(18,shade-55),g=Math.max(45,shade+8),b=Math.max(24,shade-28);
                p.setColor(Color.rgb(r,g,b)); c.drawRect(i*colW,top,(i+1)*colW+1,bottom,p);
                if(i%13==0){p.setColor(Color.argb(55,20,70,28));c.drawCircle(i*colW+colW*.45f,top+wallH*.38f,Math.max(3,wallH*.045f),p);}
                if(i%29==0){p.setColor(Color.argb(40,100,155,72));c.drawCircle(i*colW+colW*.55f,bottom-wallH*.35f,Math.max(2,wallH*.035f),p);}
            }
        }

        void renderTexturedFloor(){
            Arrays.fill(floorPixels,0xff1f3723);
            final float horizon=FLOOR_H*.47f;
            final float posZ=FLOOR_H*.50f;
            final double fov=Math.toRadians(68);
            final double halfPlane=Math.tan(fov/2.0);
            double dirX=Math.cos(angle), dirY=Math.sin(angle);
            double rayDirX0=dirX+dirY*halfPlane;
            double rayDirY0=dirY-dirX*halfPlane;
            double rayDirX1=dirX-dirY*halfPlane;
            double rayDirY1=dirY+dirX*halfPlane;
            int horizonRow=(int)Math.ceil(horizon);
            for(int y=horizonRow;y<FLOOR_H;y++){
                double pRow=y-horizon;
                if(pRow<0.5) continue;
                double rowDist=posZ/pRow;
                double stepX=rowDist*(rayDirX1-rayDirX0)/FLOOR_W;
                double stepY=rowDist*(rayDirY1-rayDirY0)/FLOOR_W;
                double floorX=playerX+rowDist*rayDirX0;
                double floorY=playerY+rowDist*rayDirY0;
                int base=y*FLOOR_W;
                for(int x=0;x<FLOOR_W;x++){
                    int cx=(int)Math.floor(floorX), cy=(int)Math.floor(floorY);
                    double fx=floorX-cx, fy=floorY-cy;
                    int texX=(int)(fx*TEX); if(texX<0)texX=0;if(texX>=TEX)texX=TEX-1;
                    int texY=(int)(fy*TEX); if(texY<0)texY=0;if(texY>=TEX)texY=TEX-1;
                    int color=0xff1f3723;
                    if(cx>=0&&cy>=0&&cx<MAP_W&&cy<MAP_H){
                        int[] tex=pathMap[cy][cx]?stonePixels:grassPixels;
                        color=tex[texY*TEX+texX];
                        // distance shading for the classic nocturnal depth feel
                        float shade=(float)Math.max(0.50,Math.min(1.0,1.0-rowDist*0.018));
                        int a=(color>>>24)&255,r=(int)(((color>>16)&255)*shade),g=(int)(((color>>8)&255)*shade),b=(int)((color&255)*shade);
                        color=(a<<24)|(r<<16)|(g<<8)|b;
                    }
                    floorPixels[base+x]=color;
                    floorX+=stepX; floorY+=stepY;
                }
            }
            floorBitmap.setPixels(floorPixels,0,FLOOR_W,0,0,FLOOR_W,FLOOR_H);
        }

        void renderSprites(Canvas c,int w,int h){
            ArrayList<Sprite> list=new ArrayList<>();
            for(Tree t:trees)list.add(new Sprite(t.x,t.y,dist(playerX,playerY,t.x,t.y),5,t));
            for(Item a:acorns)if(a.alive)list.add(new Sprite(a.x,a.y,dist(playerX,playerY,a.x,a.y),1,a));
            for(Item a:fakes)if(a.alive)list.add(new Sprite(a.x,a.y,dist(playerX,playerY,a.x,a.y),2,a));
            for(Enemy e:enemies)if(e.alive)list.add(new Sprite(e.x,e.y,dist(playerX,playerY,e.x,e.y),3,e));
            Collections.sort(list,(a,b)->Double.compare(b.d,a.d));
            double fov=Math.toRadians(68);
            for(Sprite s:list){
                double dx=s.x-playerX,dy=s.y-playerY,d=Math.hypot(dx,dy),rel=normAngle(Math.atan2(dy,dx)-angle);
                if(Math.abs(rel)>fov*.62 || d<.18)continue;
                int sx=(int)((.5+rel/fov)*w);
                if(s.type==5){
                    float size=(float)Math.min(h*1.18,h/(Math.max(.72,d))*.68);
                    float bw=size*(oakSprite.getWidth()/(float)oakSprite.getHeight());
                    float top=h*.49f-size*.68f, bottom=h*.49f+size*.32f;
                    drawOccludedBitmap(c,oakSprite,sx-bw/2f,top,sx+bw/2f,bottom,d,rel,w);
                    continue;
                }
                float projected=(float)(h/(Math.max(.35,d)*1.15));
                if(s.type==3){
                    int size=(int)Math.min(h*.70f,projected*.85f);
                    float bw=size*.90f;
                    float top=h*.52f-size*.55f,bottom=h*.52f+size*.45f;
                    drawOccludedBitmap(c,squirrelSprite,sx-bw/2f,top,sx+bw/2f,bottom,d,rel,w);
                    if(((Enemy)s.obj).hitFlash>System.currentTimeMillis()){
                        p.setColor(Color.argb(120,255,245,220));c.drawCircle(sx,(top+bottom)/2f,size*.30f,p);
                    }
                }else if(s.type==1){
                    // Acorns stay small and readable: a few dozen pixels even when close.
                    float half=(float)Math.max(7,Math.min(34,projected*.035f));
                    drawOccludedBitmap(c,acornSprite,sx-half,(float)(h*.52-half*.15),sx+half,(float)(h*.52+half*1.35),d,rel,w);
                }else{
                    float half=(float)Math.max(8,Math.min(26,projected*.030f));
                    drawFakeOccluded(c,sx,(float)(h*.52f),half,d,rel,w);
                }
            }
        }

        // Per-column depth test: a sprite column is drawn only when the sprite is
        // in front of the wall hit by that camera ray. This fixes sprites leaking
        // through hedge walls while preserving the classic raycasting look.
        void drawOccludedBitmap(Canvas c,Bitmap b,float left,float top,float right,float bottom,double distance,double spriteRel,int screenW){
            if(b==null||right<=left||bottom<=top||depth==null)return;
            int x0=Math.max(0,(int)Math.floor(left)),x1=Math.min(screenW-1,(int)Math.ceil(right));
            float width=right-left;
            double centerX=(left+right)*.5;
            for(int x=x0;x<=x1;x++){
                int ray=(int)(((double)x/screenW)*depth.length);
                if(ray<0)ray=0;if(ray>=depth.length)ray=depth.length-1;
                double rayRel=-Math.toRadians(68)/2.0+(((double)x+0.5)/screenW)*Math.toRadians(68);
                double corrected=distance*Math.cos(rayRel-spriteRel);
                if(corrected>depth[ray]+.06)continue;
                float u0=(x-left)/width,u1=(x+1-left)/width;
                int src0=Math.max(0,Math.min(b.getWidth()-1,(int)(u0*b.getWidth())));
                int src1=Math.max(src0+1,Math.min(b.getWidth(),(int)(u1*b.getWidth()+1)));
                Rect src=new Rect(src0,0,src1,b.getHeight());
                RectF dst=new RectF(x,top,x+1.2f,bottom);
                c.drawBitmap(b,src,dst,spritePaint);
            }
        }

        void drawFakeOccluded(Canvas c,int x,float cy,float half,double distance,double spriteRel,int screenW){
            // Draw a tiny fake item as a bitmap-like vector, with the same depth test.
            float left=x-half,right=x+half,top=cy-half*.75f,bottom=cy+half;
            int x0=Math.max(0,(int)left),x1=Math.min(screenW-1,(int)right);
            for(int px=x0;px<=x1;px++){
                int ray=(int)(((double)px/screenW)*depth.length);
                if(ray<0)ray=0;if(ray>=depth.length)ray=depth.length-1;
                double rayRel=-Math.toRadians(68)/2.0+(((double)px+0.5)/screenW)*Math.toRadians(68);
                if(distance*Math.cos(rayRel-spriteRel)>depth[ray]+.06)continue;
                p.setColor(Color.rgb(92,75,58));
                float k=(px-left)/(right-left), xx=left+k*(right-left);
                c.drawLine(xx,top+half*.20f*(float)Math.sin(k*Math.PI),xx,bottom,p);
            }
            p.setColor(Color.rgb(67,57,49));
            c.drawOval(left+half*.18f,top-half*.02f,right-half*.18f,top+half*.38f,p);
        }

        void drawWeapon(Canvas c,int w,int h){float bobY=(float)Math.sin(bob*.55)*3;p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(30,27,28));Path gun=new Path();gun.moveTo(w*.43f,h);gun.lineTo(w*.46f,h*.78f);gun.lineTo(w*.54f,h*.78f);gun.lineTo(w*.57f,h);gun.close();c.drawPath(gun,p);p.setColor(Color.rgb(91,64,44));c.drawRoundRect(w*.475f,h*.70f+bobY,w*.525f,h*.91f+bobY,10,10,p);p.setColor(Color.rgb(45,40,45));c.drawRoundRect(w*.455f,h*.83f+bobY,w*.545f,h*.99f+bobY,14,14,p);if(System.currentTimeMillis()<fireUntil){p.setColor(Color.rgb(255,215,110));Path f=new Path();f.moveTo(w*.5f,h*.66f);f.lineTo(w*.47f,h*.76f);f.lineTo(w*.5f,h*.73f);f.lineTo(w*.53f,h*.76f);f.close();c.drawPath(f,p);}}

        void drawHud(Canvas c,int w,int h){
            p.setColor(Color.argb(225,15,25,20));c.drawRect(0,0,w,64,p);
            txt(c,"ОПЕРАЦИЯ «ЖЁЛУДЬ»",18,24,17,Color.WHITE,true);txt(c,"УР. "+level+"   ЖЁЛУДИ "+found+"/"+acornGoal(),18,48,14,Color.rgb(247,214,160),true);
            if(face!=null){int r=22;float cx=w*.48f,fy=31;c.drawBitmap(face,null,new RectF(cx-r,fy-r,cx+r,fy+r),spritePaint);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);p.setColor(Color.rgb(255,176,186));c.drawCircle(cx,fy,r,p);p.setStyle(Paint.Style.FILL);txt(c,"CAROLINA",cx+r+9,26,12,Color.WHITE,true);txt(c,"ОХОТНИК",cx+r+9,43,10,Color.LTGRAY,false);}
            txt(c,"HP "+hp,w*.61f,25,16,hp<35?Color.rgb(255,110,120):Color.WHITE,true);txt(c,"AMMO "+ammo,w*.61f,48,14,Color.LTGRAY,true);
            p.setColor(Color.argb(210,240,240,240));c.drawRoundRect(w-58,10,w-12,54,18,18,p);txtCenter(c,muted?"×":"♪",w-35,40,18,Color.rgb(30,30,30),true);
            drawMiniMap(c,w,h);
            p.setColor(Color.argb(220,255,245,220));p.setStrokeWidth(2);float cy=h*.47f;c.drawLine(w/2-10,cy,w/2-3,cy,p);c.drawLine(w/2+3,cy,w/2+10,cy,p);c.drawLine(w/2,cy-10,w/2,cy-3,p);c.drawLine(w/2,cy+3,w/2,cy+10,p);
            float jcx=145,jcy=h-82;p.setColor(Color.argb(72,255,255,255));c.drawCircle(jcx,jcy,64,p);p.setColor(Color.argb(150,255,176,186));c.drawCircle(jcx+joystickX*38,jcy+joystickY*38,26,p);
            float fx=w-118,fy=h-88;p.setColor(Color.argb(165,255,176,186));c.drawCircle(fx,fy,58,p);txtCenter(c,"ВЗЯТЬ",fx,fy+5,15,Color.rgb(35,28,35),true);txtCenter(c,"/ АТАКА",fx,fy+23,12,Color.rgb(35,28,35),true);
            drawWeapon(c,w,h);
        }

        void drawMiniMap(Canvas c,int w,int h){float mw=130,mh=91,left=w-mw-74,top=70;p.setColor(Color.argb(185,12,20,15));c.drawRoundRect(left,top,left+mw,top+mh,12,12,p);if(map==null)return;float sx=mw/MAP_W,sy=mh/MAP_H;for(int yy=0;yy<MAP_H;yy++)for(int xx=0;xx<MAP_W;xx++)if(map[yy][xx]!=0){p.setColor(Color.rgb(65,82,65));c.drawRect(left+xx*sx,top+yy*sy,left+(xx+1)*sx+1,top+(yy+1)*sy+1,p);}p.setColor(Color.rgb(115,190,100));for(Tree t:trees)c.drawCircle(left+(float)t.x*sx,top+(float)t.y*sy,3,p);p.setColor(Color.rgb(255,185,100));for(Item a:acorns)c.drawCircle(left+(float)a.x*sx,top+(float)a.y*sy,2.5f,p);p.setColor(Color.rgb(225,125,70));for(Enemy e:enemies)if(e.alive)c.drawCircle(left+(float)e.x*sx,top+(float)e.y*sy,2.5f,p);p.setColor(Color.WHITE);float px=left+(float)playerX*sx,py=top+(float)playerY*sy;c.drawCircle(px,py,3.5f,p);c.drawLine(px,py,px+(float)Math.cos(angle)*9,py+(float)Math.sin(angle)*9,p);}

        void drawToast(Canvas c,int w,int h){if(System.currentTimeMillis()>toastUntil)return;p.setColor(Color.argb(235,255,248,235));c.drawRoundRect(w*.20f,76,w*.80f,130,22,22,p);txtCenter(c,toast,w/2f,111,14,Color.rgb(55,43,47),true);postInvalidateDelayed(100);}

        void drawTitle(Canvas c,int w,int h){p.setColor(Color.rgb(16,22,18));c.drawRect(0,0,w,h,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(65,95,72));c.drawRect(w*.08f,h*.10f,w*.92f,h*.86f,p);c.drawRect(w*.20f,h*.22f,w*.80f,h*.73f,p);p.setStyle(Paint.Style.FILL);txt(c,"ACORN HUNTER",w*.10f,h*.28f,34,Color.rgb(255,176,186),true);txt(c,"OPERATION «ЖЁЛУДЬ»",w*.10f,h*.36f,38,Color.WHITE,true);txt(c,"A tiny 90s-style forest FPS",w*.10f,h*.43f,17,Color.LTGRAY,false);txt(c,"для человека, который слишком долго искал жёлуди.",w*.10f,h*.48f,16,Color.LTGRAY,false);p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.62f,w*.47f,h*.73f,28,28,p);txtCenter(c,"НАЧАТЬ ОПЕРАЦИЮ",w*.285f,h*.687f,19,Color.rgb(35,28,35),true);txt(c,"Дубы в поле зрения. Жёлуди в траве. Белки в кустах.",w*.10f,h*.84f,13,Color.rgb(155,165,155),false);}

        void drawLevelComplete(Canvas c,int w,int h){p.setColor(Color.rgb(16,22,18));c.drawRect(0,0,w,h,p);txt(c,"УРОВЕНЬ "+level+" ПРОЙДЕН",w*.10f,h*.30f,34,Color.rgb(255,205,120),true);txt(c,"Жёлуди собраны: "+found+" / "+acornGoal(),w*.10f,h*.39f,20,Color.WHITE,false);String msg=level==1?"Парк пережил первый рейд.":level==2?"Белки отступают от дубов.":"Все дубы проверены. Остался финал.";txt(c,msg,w*.10f,h*.46f,17,Color.LTGRAY,false);p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.60f,w*.50f,h*.71f,28,28,p);txtCenter(c,level<3?"ИДТИ ДАЛЬШЕ":"ЗАБРАТЬ НАГРАДУ",w*.30f,h*.667f,18,Color.rgb(35,28,35),true);}

        void drawEnd(Canvas c,int w,int h){p.setColor(Color.rgb(16,22,18));c.drawRect(0,0,w,h,p);if(screen==3){txt(c,"ОПЕРАЦИЯ ЗАВЕРШЕНА",w*.10f,h*.27f,32,Color.rgb(255,205,120),true);txt(c,"ОН СУЩЕСТВУЕТ.",w*.10f,h*.37f,42,Color.WHITE,true);txt(c,"Каролина нашла легендарный жёлудь.",w*.10f,h*.46f,19,Color.WHITE,false);txt(c,"Дарина может делать поделку.",w*.10f,h*.51f,19,Color.WHITE,false);txt(c,"Белки официально проиграли.",w*.10f,h*.56f,19,Color.rgb(255,176,186),true);txt(c,"P.S. Данил всё это время верил в тебя.",w*.10f,h*.65f,17,Color.LTGRAY,false);p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.73f,w*.44f,h*.84f,28,28,p);txtCenter(c,"ЕЩЁ РАЗ?",w*.27f,h*.80f,17,Color.rgb(35,28,35),true);}else{txt(c,"ОПЕРАЦИЯ ПРОВАЛЕНА",w*.10f,h*.32f,34,Color.rgb(255,110,120),true);txt(c,"Белки оказались сильнее.",w*.10f,h*.41f,20,Color.WHITE,false);txt(c,"Но легенда о жёлуде ещё не закончена.",w*.10f,h*.47f,17,Color.LTGRAY,false);p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.68f,w*.44f,h*.79f,28,28,p);txtCenter(c,"НАЧАТЬ ЗАНОВО",w*.27f,h*.75f,17,Color.rgb(35,28,35),true);}}

        void toggleMusic(){muted=!muted;if(host.music==null)return;if(muted&&host.music.isPlaying())host.music.pause();else if(!muted&&screen>0)host.music.start();}

        @Override protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();if(w<h){drawRotatePrompt(c,w,h);postInvalidateDelayed(250);return;}if(screen==0){drawTitle(c,w,h);return;}if(screen==2){drawLevelComplete(c,w,h);return;}if(screen==3||screen==4){drawEnd(c,w,h);return;}raycast(c,w,h);renderSprites(c,w,h);drawHud(c,w,h);drawToast(c,w,h);long now=System.nanoTime();float dt=Math.min(.05f,(now-lastFrame)/1_000_000_000f);lastFrame=now;update(dt);postInvalidateDelayed(16);}

        void drawRotatePrompt(Canvas c,int w,int h){p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(16,22,18));c.drawRect(0,0,w,h,p);txtCenter(c,"ПОВЕРНИ ТЕЛЕФОН",w/2f,h*.40f,Math.min(30f,w*.07f),Color.WHITE,true);txtCenter(c,"ИГРА РАБОТАЕТ В ГОРИЗОНТАЛЬНОМ РЕЖИМЕ",w/2f,h*.48f,Math.min(15f,w*.04f),Color.LTGRAY,false);txtCenter(c,"↻",w/2f,h*.66f,Math.min(64f,w*.16f),Color.rgb(255,176,186),true);}

        @Override public boolean onTouchEvent(MotionEvent e){int action=e.getActionMasked(),idx=e.getActionIndex();float x=e.getX(idx),y=e.getY(idx);int w=getWidth(),h=getHeight();if(action==MotionEvent.ACTION_DOWN){
                if(screen==0){if(x>w*.07f&&x<w*.58f&&y>h*.55f&&y<h*.80f){begin();return true;}}
                else if(screen==2){if(x>w*.07f&&x<w*.58f&&y>h*.54f&&y<h*.80f){if(level<3){level++;loadLevel();}else screen=3;return true;}}
                else if(screen==3||screen==4){if(x>w*.07f&&x<w*.50f&&y>h*.65f){begin();return true;}}
                else if(screen==1){if(x>w-82&&y<75){toggleMusic();return true;}if(x>w*.70f&&y>h*.60f){firing=true;fireUntil=System.currentTimeMillis()+120;return true;}if(x<w*.48f&&y>h*.56f){joystickActive=true;activePointer=e.getPointerId(idx);touchStartX=x;touchStartY=y;updateJoystick(x,y);return true;}}
            } else if(action==MotionEvent.ACTION_MOVE&&screen==1){int pi=e.findPointerIndex(activePointer);if(joystickActive&&pi>=0){updateJoystick(e.getX(pi),e.getY(pi));return true;}}
            else if((action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL)&&screen==1){if(e.getPointerId(idx)==activePointer){joystickActive=false;joystickX=joystickY=0;activePointer=-1;}return true;}return true;}
        void updateJoystick(float x,float y){float dx=(x-touchStartX)/70f,dy=(y-touchStartY)/70f,len=(float)Math.hypot(dx,dy);if(len>1){dx/=len;dy/=len;}joystickX=dx;joystickY=dy;}
    }
}
