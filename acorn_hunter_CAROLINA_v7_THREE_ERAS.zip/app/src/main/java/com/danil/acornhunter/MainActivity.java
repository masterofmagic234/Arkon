package com.danil.acornhunter;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import java.util.*;

/**
 * Acorn Hunter v9 — Forest Hunt Polish Pass.
 * Original raycasting renderer inspired by early 90s corridor FPS design.
 * Uses supplied Carolina portrait and supplied music, plus original pixel-art assets.
 */
public class MainActivity extends Activity {
    MediaPlayer music;
    ToneGenerator tones;
    SoundPool soundPool;
    int footstep1, footstep2, squirrelHitSound, shotSound, pickupSound, damageSound;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        hideSystemUI();
        tones = new ToneGenerator(AudioManager.STREAM_MUSIC, 45);
        soundPool = new SoundPool.Builder().setMaxStreams(4).build();
        footstep1 = soundPool.load(this, R.raw.footstep1, 1);
        footstep2 = soundPool.load(this, R.raw.footstep2, 1);
        squirrelHitSound = soundPool.load(this, R.raw.squirrel_hit, 1);
        shotSound = soundPool.load(this, R.raw.shot, 1);
        pickupSound = soundPool.load(this, R.raw.pickup, 1);
        damageSound = soundPool.load(this, R.raw.damage, 1);
        music = MediaPlayer.create(this, R.raw.acorn_music);
        if (music != null) { music.setLooping(true); music.setVolume(0.28f, 0.28f); }
        setContentView(new GameView(this));
    }

    void hideSystemUI() {
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        w.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        }
    }

    void beep(int type) { if (tones != null) try { tones.startTone(type, 80); } catch(Exception ignored){} }

    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if(hasFocus) hideSystemUI(); }
    @Override protected void onPause() { super.onPause(); if(music!=null && music.isPlaying()) music.pause(); }
    @Override protected void onResume() { super.onResume(); hideSystemUI(); }
    @Override protected void onDestroy() { if(music!=null){music.release();music=null;} if(tones!=null){tones.release();tones=null;} if(soundPool!=null){soundPool.release();soundPool=null;} super.onDestroy(); }

    static class GameView extends View {
        final MainActivity host;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint spritePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        final Random rnd = new Random(17);
        Bitmap face, oakSprite, squirrelSprite, squirrelStunnedSprite, acornSprite, pineSprite, pineConeSprite, berriesSprite, pistolSprite;

        // 0 title, 1 playing, 2 level complete, 3 victory, 4 defeat
        int screen=0, level=1, found=0, hp=100, ammo=32;
        boolean muted=false, firing=false;
        long fireUntil=0, lastFrame=System.nanoTime(), lastEnemyThink=0, toastUntil=0, shotCooldownUntil=0;
        String toast="";
        double playerX=2.5, playerY=2.5, angle=0;
        float bob=0, joystickX=0, joystickY=0, touchStartX, touchStartY;
        long nextFootstep=0; boolean footToggle=false;
        boolean joystickActive=false;
        int activePointer=-1;
        float[] depth;

        final int MAP_W=20, MAP_H=14;
        int[][] map;
        ArrayList<Item> acorns=new ArrayList<>(), fakes=new ArrayList<>();
        ArrayList<Enemy> enemies=new ArrayList<>();
        ArrayList<Tree> trees=new ArrayList<>();

        static class Item { double x,y; boolean alive=true; Item(double x,double y){this.x=x;this.y=y;} }
        static class Enemy { double x,y; int hp=2; boolean alive=true, stunned=false; long hitFlash=0; Enemy(double x,double y){this.x=x;this.y=y;} }
        static class Tree { double x,y; boolean pine; Tree(double x,double y,boolean pine){this.x=x;this.y=y;this.pine=pine;} }
        static class Sprite { double x,y,d; int type; Object obj; Sprite(double x,double y,double d,int type,Object obj){this.x=x;this.y=y;this.d=d;this.type=type;this.obj=obj;} }

        // 0 = walkable park/forest, 1 = hedge/fence boundary.
        final int[][][] MAPS = new int[][][]{
            {
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,1,1,1,0,0,0,1,1,0,0,0,0,0,1},
                {1,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,1},
                {1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1},
                {1,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1},
                {1,0,1,1,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1},
                {1,0,0,0,1,1,1,0,1,0,1,1,1,0,0,0,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
                {1,0,0,1,1,1,0,0,1,1,1,0,0,0,0,0,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
            },
            {
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,1,1,0,0,0,1,1,1,0,0,0,0,1,1,0,0,0,1},
                {1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,1},
                {1,0,0,0,1,1,0,1,0,0,1,1,1,0,0,1,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,1},
                {1,0,1,0,0,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1},
                {1,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1},
                {1,0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,1,1,1,0,0,1,1,0,1,1,0,0,0,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
            },
            {
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,1,0,1,1,0,0,0,1,1,0,0,0,1,0,1,1,0,1},
                {1,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,1},
                {1,0,1,1,1,0,1,1,1,0,0,0,1,1,1,0,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,1,1,1,0,1,1,1,0,1,1,0,0,0,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,1,1,0,1,1,0,1,1,0,0,1,1,0,1,1,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
            }
        };

        GameView(Context c){
            super(c); host=(MainActivity)c; setFocusable(true);
            face=BitmapFactory.decodeResource(getResources(),R.drawable.carolina_face);
            oakSprite=BitmapFactory.decodeResource(getResources(),R.drawable.oak_tree);
            squirrelSprite=BitmapFactory.decodeResource(getResources(),R.drawable.squirrel);
            squirrelStunnedSprite=BitmapFactory.decodeResource(getResources(),R.drawable.squirrel_stunned);
            acornSprite=BitmapFactory.decodeResource(getResources(),R.drawable.acorn);
            pineSprite=BitmapFactory.decodeResource(getResources(),R.drawable.pine_tree);
            pineConeSprite=BitmapFactory.decodeResource(getResources(),R.drawable.pine_cone);
            berriesSprite=BitmapFactory.decodeResource(getResources(),R.drawable.hedge_berries);
            pistolSprite=BitmapFactory.decodeResource(getResources(),R.drawable.pistol);
        }

        void begin(){ screen=1; level=1; hp=100; muted=false; if(host.music!=null&&!muted&&!host.music.isPlaying())host.music.start(); loadLevel(); }

        void loadLevel(){
            screen=1;
            map=MAPS[level-1]; found=0; ammo=30+level*8; hp=Math.min(100,hp+10);
            acorns.clear();fakes.clear();enemies.clear();trees.clear();
            playerX=1.5; playerY=1.5; angle=0.0; bob=0; shotCooldownUntil=0;
            buildForest();
            repairPlacements();
            toast = level==1 ? "Парк открыт. Дубы не прячутся — жёлуди тоже." : level==2 ? "Белки объявили войну желудям. Плохая идея." : "Финальный рейд. Дарина ждёт добычу.";
            toastUntil=System.currentTimeMillis()+2800; invalidate();
        }

        void buildForest(){
            if(level==1){
                oak(5.5,2.5,true); oak(10.5,2.5,false); oak(14.5,3.5,false); oak(3.5,6.5,false); oak(8.5,6.5,false); oak(13.5,7.5,true); oak(17.5,8.5,false); oak(5.5,11.5,false); oak(12.5,11.5,false);
                acornNear(5.5,2.5,.22); acornNear(10.5,2.5,-.28); acornNear(14.5,3.5,.20); acornNear(13.5,7.5,-.22);
                squirrel(9.2,5.2); squirrel(16.3,6.7);
                fakeNear(3.5,6.5);
            } else if(level==2){
                oak(3.5,2.5,false); oak(6.5,4.5,true); oak(11.5,2.5,false); oak(15.5,3.5,false); oak(4.5,7.5,false); oak(9.5,7.5,true); oak(14.5,8.5,false); oak(17.5,11.5,false); oak(7.5,11.5,false); oak(12.5,12.0,false);
                acornNear(3.5,2.5,.20); acornNear(6.5,4.5,-.24); acornNear(11.5,2.5,.22); acornNear(14.5,8.5,-.20); acornNear(17.5,11.5,.18);
                squirrel(8.5,3.2); squirrel(13.5,5.8); squirrel(5.5,9.5); squirrel(15.5,10.5);
                fakeNear(9.5,7.5); fakeNear(12.5,12.0);
            } else {
                oak(3.5,2.5,true); oak(7.5,2.5,false); oak(12.5,2.5,false); oak(17.0,3.5,false); oak(4.5,5.5,false); oak(9.5,5.5,true); oak(14.5,6.5,false); oak(17.0,8.5,false); oak(5.5,9.5,false); oak(10.5,9.5,false); oak(15.5,11.5,true); oak(7.5,12.0,false);
                acornNear(3.5,2.5,.20); acornNear(7.5,2.5,-.22); acornNear(12.5,2.5,.20); acornNear(4.5,5.5,-.20); acornNear(9.5,5.5,.22); acornNear(15.5,11.5,-.22); acornNear(7.5,12.0,.18);
                squirrel(6.0,3.7); squirrel(11.0,4.0); squirrel(15.5,5.0); squirrel(7.0,8.0); squirrel(12.5,8.0); squirrel(16.0,10.0);
                fakeNear(14.5,6.5); fakeNear(10.5,9.5); fakeNear(5.5,9.5);
            }
        }
        void oak(double x,double y,boolean pineIgnored){ trees.add(new Tree(x,y,false)); }
        void acornNear(double x,double y,double off){ acorns.add(new Item(x+Math.cos(off)*.48,y+Math.sin(off)*.48)); }
        void fakeNear(double x,double y){ fakes.add(new Item(x+.34,y+.34)); }
        void squirrel(double x,double y){ enemies.add(new Enemy(x,y)); }

        boolean wallSafe(double x,double y,double r){
            return !wall(x-r,y-r)&&!wall(x+r,y-r)&&!wall(x-r,y+r)&&!wall(x+r,y+r);
        }
        boolean nearTree(double x,double y,double minDist){
            for(Tree t:trees) if(dist(x,y,t.x,t.y)<minDist) return true;
            return false;
        }
        boolean nearItem(double x,double y,ArrayList<Item> items,double minDist){
            for(Item a:items) if(dist(x,y,a.x,a.y)<minDist) return true;
            return false;
        }
        void repairPlacements(){
            // Level 2 originally contained several coordinates that landed directly in hedge cells.
            // Repair every object against the actual collision map before gameplay starts.
            for(int i=0;i<trees.size();i++){
                Tree t=trees.get(i);
                if(!wallSafe(t.x,t.y,.24) || nearOtherTree(t.x,t.y,i,.62)){
                    double[] q=findSafeTreePoint(t.x,t.y,i); t.x=q[0]; t.y=q[1];
                }
            }
            for(Item a:acorns){
                if(!wallSafe(a.x,a.y,.08) || nearTree(a.x,a.y,.34)){
                    double[] q=findSafeItemPoint(a.x,a.y); a.x=q[0]; a.y=q[1];
                }
            }
            for(Item a:fakes){
                if(!wallSafe(a.x,a.y,.08) || nearTree(a.x,a.y,.30)){
                    double[] q=findSafeItemPoint(a.x,a.y); a.x=q[0]; a.y=q[1];
                }
            }
            for(Enemy e:enemies){
                if(!wallSafe(e.x,e.y,.14) || nearTree(e.x,e.y,.42)){
                    double[] q=findSafeEnemyPoint(e.x,e.y); e.x=q[0]; e.y=q[1];
                }
            }
        }
        boolean nearOtherTree(double x,double y,int ignore,double minDist){
            for(int i=0;i<trees.size();i++) if(i!=ignore && dist(x,y,trees.get(i).x,trees.get(i).y)<minDist)return true;
            return false;
        }
        double[] findSafeTreePoint(double x,double y,int ignore){
            int bx=(int)Math.floor(x),by=(int)Math.floor(y);
            for(int r=0;r<9;r++) for(int dy=-r;dy<=r;dy++) for(int dx=-r;dx<=r;dx++){
                int cx=bx+dx,cy=by+dy; if(cx<1||cy<1||cx>=MAP_W-1||cy>=MAP_H-1)continue;
                double px=cx+.5,py=cy+.5;
                if(wallSafe(px,py,.24)){
                    if(!nearOtherTree(px,py,ignore,.62)&&dist(px,py,playerX,playerY)>.65)return new double[]{px,py};
                }
            }
            return new double[]{1.5,1.5};
        }
        double[] findSafeItemPoint(double x,double y){
            int bx=(int)Math.floor(x),by=(int)Math.floor(y);
            // Prefer a point just outside the nearest oak, so the collectible remains visibly associated with it.
            Tree nearest=null;double nd=99;for(Tree t:trees){double d=dist(x,y,t.x,t.y);if(d<nd){nd=d;nearest=t;}}
            if(nearest!=null){
                double base=Math.atan2(y-nearest.y,x-nearest.x);
                for(int k=0;k<16;k++){double a=base+k*Math.PI/8;double px=nearest.x+Math.cos(a)*.55,py=nearest.y+Math.sin(a)*.55;if(wallSafe(px,py,.08)&&!nearTree(px,py,.34)&&dist(px,py,playerX,playerY)>.55)return new double[]{px,py};}
            }
            for(int r=0;r<9;r++)for(int dy=-r;dy<=r;dy++)for(int dx=-r;dx<=r;dx++){int cx=bx+dx,cy=by+dy;if(cx<1||cy<1||cx>=MAP_W-1||cy>=MAP_H-1)continue;double px=cx+.5,py=cy+.5;if(wallSafe(px,py,.08)&&!nearTree(px,py,.34)&&dist(px,py,playerX,playerY)>.55)return new double[]{px,py};}
            return new double[]{1.7,1.5};
        }
        double[] findSafeEnemyPoint(double x,double y){
            int bx=(int)Math.floor(x),by=(int)Math.floor(y);
            for(int r=0;r<9;r++)for(int dy=-r;dy<=r;dy++)for(int dx=-r;dx<=r;dx++){int cx=bx+dx,cy=by+dy;if(cx<1||cy<1||cx>=MAP_W-1||cy>=MAP_H-1)continue;double px=cx+.5,py=cy+.5;if(wallSafe(px,py,.14)&&!nearTree(px,py,.42)&&dist(px,py,playerX,playerY)>1.0)return new double[]{px,py};}
            return new double[]{2.5,1.5};
        }

        boolean wall(double x,double y){ int ix=(int)Math.floor(x),iy=(int)Math.floor(y); if(ix<0||iy<0||ix>=MAP_W||iy>=MAP_H)return true; return map[iy][ix]!=0; }
        boolean treeSolid(double x,double y){ for(Tree t:trees) if(Math.hypot(x-t.x,y-t.y)<.27)return true; return false; }
        boolean canStand(double x,double y){ double r=.14; return !wall(x-r,y-r)&&!wall(x+r,y-r)&&!wall(x-r,y+r)&&!wall(x+r,y+r)&&!treeSolid(x,y); }
        double normAngle(double a){while(a<-Math.PI)a+=Math.PI*2;while(a>Math.PI)a-=Math.PI*2;return a;}
        double dist(double x,double y,double x2,double y2){return Math.hypot(x-x2,y-y2);}

        void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.create(Typeface.DEFAULT,Typeface.BOLD):Typeface.create(Typeface.DEFAULT,Typeface.NORMAL));c.drawText(s,x,y,p);}
        void txtCenter(Canvas c,String s,float cx,float y,float size,int color,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.create(Typeface.DEFAULT,Typeface.BOLD):Typeface.create(Typeface.DEFAULT,Typeface.NORMAL));c.drawText(s,cx-p.measureText(s)/2f,y,p);}

        void playFootstep(){
            if(host.soundPool==null || muted) return;
            long now=System.currentTimeMillis();
            if(now<nextFootstep) return;
            int id=footToggle?host.footstep2:host.footstep1; footToggle=!footToggle;
            host.soundPool.play(id,0.20f,0.20f,1,0,1.0f);
            nextFootstep=now+310;
        }

        String pick(String[] a){return a[rnd.nextInt(a.length)];}
        final String[] ACORN_LINES={
            "ЖЁЛУДЬ ДОБЫТ. Дарина, ставь чайник.","Один есть. Белки нервничают.","Исторический жёлудь №%d.","Данил сообщает: прогресс подозрительно хороший.","В карман! И никому не отдавать.","Найден. Официально настоящий.","Ещё один — и можно открывать музей.","Жёлудь найден. Серьёзная археология."
        };
        final String[] CONE_LINES={
            "ЭТО ШИШКА. Лес тебя переиграл.","Поздравляю: ты нашла не то.","Дарина просила жёлуди, а не ботанику.","Шишка нанесла 12 урона самолюбию.","Неправильный орех. Очень неправильный.","Каролина, это буквально НЕ ЖЁЛУДЬ.","Лес говорит: внимательнее, пожалуйста."
        };
        final String[] HIT_LINES={
            "ПОПАЛА. Белка задумалась о жизни.","Белка получила аргумент.","Точно в пушистую проблему.","Попадание! Белка пересматривает карьеру.","Минус одна попытка украсть жёлудь.","Белка: это было неожиданно.","Тихо. Я всё видела. Отличный выстрел."
        };
        final String[] STUN_LINES={
            "Белка контужена. Звёздочки прилагаются.","Белка прилегла подумать.","Пушистый отпуск объявлен досрочно.","Белка временно недееспособна. Достойно.","Она не мёртвая. Она просто очень впечатлена.","Звёздочки — официальный эффект поражения.","Белка выбыла. Жёлуди в безопасности."
        };

        void update(float dt){
            if(screen!=1)return;
            double forward=-joystickY, turn=joystickX;
            if(joystickActive){ angle+=turn*2.45*dt; double speed=(1.45+level*.08)*forward*dt; movePlayer(Math.cos(angle)*speed,Math.sin(angle)*speed); bob+=Math.abs(speed)*18; if(Math.abs(speed)>.008) playFootstep(); }
            long now=System.currentTimeMillis();
            if(now-lastEnemyThink>65){
                lastEnemyThink=now;
                for(Enemy e:enemies) if(e.alive){
                    double d=dist(playerX,playerY,e.x,e.y);
                    if(d<6.2&&d>.72){ double step=.026; double ex=(playerX-e.x)/d*step,ey=(playerY-e.y)/d*step; if(canEnemyStand(e.x+ex,e.y+ey)){e.x+=ex;e.y+=ey;} }
                    if(d<.70){hp-=2;if(host.soundPool!=null&&!muted)host.soundPool.play(host.damageSound,.65f,.65f,1,0,1); toast=pick(new String[]{"АЙ! Белка кусается.","Урон. Пушистый террор продолжается.","Белка сказала: не подходи.","Это было больно. Очень по-беличьи."});toastUntil=now+900;if(hp<=0){hp=0;screen=4;toast="Белки победили. Позор, но кинематографично.";toastUntil=now+1600;}}
                }
            }
            for(int i=acorns.size()-1;i>=0;i--) if(acorns.get(i).alive&&dist(playerX,playerY,acorns.get(i).x,acorns.get(i).y)<.40){acorns.remove(i);found++;if(host.soundPool!=null&&!muted)host.soundPool.play(host.pickupSound,.55f,.55f,1,0,1);host.beep(ToneGenerator.TONE_PROP_BEEP2);toast=String.format(pick(ACORN_LINES),found);toastUntil=now+1500;}
            for(int i=fakes.size()-1;i>=0;i--) if(fakes.get(i).alive&&dist(playerX,playerY,fakes.get(i).x,fakes.get(i).y)<.38){fakes.remove(i);hp-=12;if(host.soundPool!=null&&!muted)host.soundPool.play(host.damageSound,.72f,.72f,1,0,1);host.beep(ToneGenerator.TONE_PROP_NACK);toast=pick(CONE_LINES);toastUntil=now+1400;if(hp<=0){hp=0;screen=4;}}
            if(found>=acornGoal()){screen=2;toast="Уровень пройден. Белки этого не переживут.";toastUntil=now+1400;}
            if(firing&&now<fireUntil)shoot();
        }
        boolean canEnemyStand(double x,double y){double r=.14;return !wall(x-r,y-r)&&!wall(x+r,y-r)&&!wall(x-r,y+r)&&!wall(x+r,y+r)&&!treeSolid(x,y);}
        int acornGoal(){return level==1?4:level==2?5:7;}

        void movePlayer(double dx,double dy){double nx=playerX+dx,ny=playerY+dy;if(canStand(nx,playerY))playerX=nx;if(canStand(playerX,ny))playerY=ny;}

        void shoot(){
            long now=System.currentTimeMillis();
            if(now<shotCooldownUntil)return;
            if(ammo<=0){toast="Щёлк. Пусто. Даже белки засмеялись.";toastUntil=now+700;firing=false;return;}
            ammo--; firing=false; fireUntil=now+155; shotCooldownUntil=now+210;
            if(host.soundPool!=null&&!muted)host.soundPool.play(host.shotSound,.85f,.85f,1,0,1.0f);
            host.beep(ToneGenerator.TONE_PROP_BEEP);
            Enemy best=null;double bestD=99;
            for(Enemy e:enemies)if(e.alive){double dx=e.x-playerX,dy=e.y-playerY,d=Math.hypot(dx,dy),rel=Math.abs(normAngle(Math.atan2(dy,dx)-angle));if(rel<.11&&d<8&&d<bestD&&clearLine(e.x,e.y)){best=e;bestD=d;}}
            if(best!=null){
                best.hp--; best.hitFlash=now+130;
                if(host.soundPool!=null&&!muted) host.soundPool.play(host.squirrelHitSound,0.48f,0.48f,1,0,1.0f);
                if(best.hp<=0){best.alive=false;best.stunned=true;toast=pick(STUN_LINES);toastUntil=now+1250;}else{toast=pick(HIT_LINES);toastUntil=now+750;}
            }
        }
        boolean clearLine(double tx,double ty){double dx=tx-playerX,dy=ty-playerY,d=Math.hypot(dx,dy);int steps=(int)(d*22);for(int i=1;i<steps;i++){double x=playerX+dx*i/steps,y=playerY+dy*i/steps;if(wall(x,y))return false;}return true;}

        void drawSky(Canvas c,int w,int h,float horizon){
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0,0,0,horizon,Color.rgb(6,12,27),Color.rgb(43,61,91),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,horizon,p); p.setShader(null);
            double fov=Math.toRadians(68);
            // Stars are world-fixed: rotating the camera moves them across the sky.
            for(int i=0;i<52;i++){
                double world=-Math.PI+((i*137.0)%360.0)*Math.PI/180.0;
                double rel=normAngle(world-angle); if(Math.abs(rel)>fov*.52)continue;
                float sx=(float)(w*.5+rel/fov*w);
                float sy=18+(float)(((i*47)%100)/100.0)*(horizon*.72f);
                float tw=1.0f+(float)(0.8*Math.sin(System.currentTimeMillis()/430.0+i));
                p.setColor(Color.argb((int)(130+55*Math.max(0,tw-1)),235,241,255));c.drawCircle(sx,sy,Math.max(1,1.1f*tw),p);
            }
            double moonWorld=Math.toRadians(58); double moonRel=normAngle(moonWorld-angle);
            if(Math.abs(moonRel)<fov*.52){
                float mx=(float)(w*.5+moonRel/fov*w), my=horizon*.23f; float mr=Math.min(w,h)*.035f;
                p.setColor(Color.rgb(244,241,205));c.drawCircle(mx,my,mr,p);
                p.setColor(Color.rgb(70,82,106));c.drawCircle(mx+mr*.28f,my-mr*.18f,mr*.82f,p);
            }
        }

        void drawParkFloor(Canvas c,int w,int h,float horizon){
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(34,67,39));c.drawRect(0,horizon,w,h,p);
            // Perspective stone path: vanishing point follows the world-space path direction.
            double pathWorld=0.0, rel=normAngle(pathWorld-angle);
            float vx=(float)(w*.5+rel/Math.toRadians(68)*w*.42);
            for(int band=0;band<26;band++){
                float t0=band/26f,t1=(band+1)/26f;
                float y0=horizon+(float)Math.pow(t0,1.75)*(h-horizon), y1=horizon+(float)Math.pow(t1,1.75)*(h-horizon);
                float width0=8+t0*w*.24f, width1=8+t1*w*.24f;
                p.setColor(band%2==0?Color.rgb(105,106,101):Color.rgb(91,93,89));
                Path stone=new Path(); stone.moveTo(vx-width0/2,y0);stone.lineTo(vx+width0/2,y0);stone.lineTo(vx+width1/2,y1);stone.lineTo(vx-width1/2,y1);stone.close();c.drawPath(stone,p);
                p.setColor(Color.argb(75,35,35,35));p.setStrokeWidth(1);c.drawLine(vx-width1/2,y1,vx+width1/2,y1,p);
            }
            // subtle grass texture on both sides
            p.setColor(Color.argb(35,165,200,115));
            for(int i=0;i<70;i++){float x=(i*97)%w;float y=horizon+25+(i*53)%(Math.max(1,h-(int)horizon-25));c.drawLine(x,y,x+2,y-5,p);}
        }

        void raycast(Canvas c,int w,int h){
            float horizon=h*.45f; drawSky(c,w,h,horizon); drawParkFloor(c,w,h,horizon);
            int rays=Math.min(560,Math.max(300,w/3)); depth=new float[rays]; double fov=Math.toRadians(68),step=fov/rays; float colW=(float)w/rays;
            for(int i=0;i<rays;i++){
                double ra=angle-fov/2+step*(i+.5),cos=Math.cos(ra),sin=Math.sin(ra),rx=playerX,ry=playerY,d=0;
                while(d<22){rx+=cos*.035;ry+=sin*.035;d+=.035;if(wall(rx,ry))break;}
                double corrected=d*Math.cos(ra-angle); depth[i]=(float)corrected;
                float wallH=(float)Math.min(h*1.55,h/(Math.max(.20,corrected))*.52),top=horizon-wallH/2f,bottom=horizon+wallH/2f;
                int shade=(int)Math.max(28,126-corrected*8); int r=Math.max(18,shade-58),g=Math.max(48,shade+8),b=Math.max(26,shade-28);
                p.setColor(Color.rgb(r,g,b)); c.drawRect(i*colW,top,(i+1)*colW+1,bottom,p);
                // hedge leaves and berries tied to the wall surface
                if(i%11==0){p.setColor(Color.argb(95,38,91,39));c.drawCircle(i*colW+colW*.5f,top+wallH*.32f,Math.max(3,wallH*.06f),p);}
                if(i%37==0){p.setColor(Color.argb(190,145,47,62));c.drawCircle(i*colW+colW*.55f,top+wallH*.46f,Math.max(2,wallH*.028f),p);}
                if(i%53==0){p.setColor(Color.argb(140,25,70,28));c.drawLine(i*colW+colW*.4f,top+wallH*.62f,i*colW+colW*.75f,bottom-wallH*.18f,p);}
            }
        }

        void renderSprites(Canvas c,int w,int h){
            ArrayList<Sprite> list=new ArrayList<>();
            for(Tree t:trees)list.add(new Sprite(t.x,t.y,dist(playerX,playerY,t.x,t.y),5,t));
            for(Item a:acorns)if(a.alive)list.add(new Sprite(a.x,a.y,dist(playerX,playerY,a.x,a.y),1,a));
            for(Item a:fakes)if(a.alive)list.add(new Sprite(a.x,a.y,dist(playerX,playerY,a.x,a.y),2,a));
            for(Enemy e:enemies)list.add(new Sprite(e.x,e.y,dist(playerX,playerY,e.x,e.y),e.alive?3:4,e));
            Collections.sort(list,(a,b)->Double.compare(b.d,a.d));
            double fov=Math.toRadians(68); float horizon=h*.45f;
            for(Sprite s:list){
                double dx=s.x-playerX,dy=s.y-playerY,d=Math.hypot(dx,dy),rel=normAngle(Math.atan2(dy,dx)-angle);
                if(Math.abs(rel)>fov*.52 || d<.18)continue;
                int sx=(int)((.5+rel/fov)*w);
                if(s.type==5){
                    float size=(float)Math.min(h*1.20,h/(Math.max(.72,d))*.72); float bw=size*(oakSprite.getWidth()/(float)oakSprite.getHeight());
                    float bottom=horizon+size*.42f, top=bottom-size; drawOccludedBitmap(c,oakSprite,sx-bw/2f,top,sx+bw/2f,bottom,d,rel,w); continue;
                }
                float projected=(float)(h/(Math.max(.35,d)*1.10));
                if(s.type==3 || s.type==4){
                    Bitmap b=s.type==4?squirrelStunnedSprite:squirrelSprite; int size=(int)Math.min(h*.72f,projected*.92f); float bw=size*(b.getWidth()/(float)b.getHeight());
                    float bottom=horizon+size*.46f, top=bottom-size; drawOccludedBitmap(c,b,sx-bw/2f,top,sx+bw/2f,bottom,d,rel,w);
                    if(s.type==3 && ((Enemy)s.obj).hitFlash>System.currentTimeMillis()){p.setColor(Color.argb(130,255,245,220));c.drawCircle(sx,(top+bottom)/2f,size*.30f,p);}
                }else if(s.type==1){
                    float half=(float)Math.max(9,Math.min(44,projected*.055f)); float bottom=horizon+half*.22f;
                    drawOccludedBitmap(c,acornSprite,sx-half,bottom-half*1.85f,sx+half,bottom,d,rel,w);
                }else if(s.type==2){
                    float size=(float)Math.max(15,Math.min(48,projected*.075f)); float bottom=horizon+size*.15f;
                    drawOccludedBitmap(c,pineConeSprite,sx-size*.55f,bottom-size,sx+size*.55f,bottom,d,rel,w);
                }
            }
        }

        // Per-column depth test: a sprite column is drawn only when the sprite is
        // in front of the wall hit by that camera ray. This fixes sprites leaking
        // through hedge walls while preserving the classic raycasting look.
        void drawOccludedBitmap(Canvas c,Bitmap b,float left,float top,float right,float bottom,double distance,double spriteRel,int screenW){
            if(b==null||right<=left||bottom<=top||depth==null)return;
            int x0=Math.max(0,(int)Math.floor(left)),x1=Math.min(screenW-1,(int)Math.ceil(right));
            float width=right-left;
            double centerX=(left+right)*.5;
            for(int x=x0;x<=x1;x++){
                int ray=(int)(((double)x/screenW)*depth.length);
                if(ray<0)ray=0;if(ray>=depth.length)ray=depth.length-1;
                double rayRel=-Math.toRadians(68)/2.0+(((double)x+0.5)/screenW)*Math.toRadians(68);
                double corrected=distance*Math.cos(rayRel-spriteRel);
                if(corrected>depth[ray]+.06)continue;
                float u0=(x-left)/width,u1=(x+1-left)/width;
                int src0=Math.max(0,Math.min(b.getWidth()-1,(int)(u0*b.getWidth())));
                int src1=Math.max(src0+1,Math.min(b.getWidth(),(int)(u1*b.getWidth()+1)));
                Rect src=new Rect(src0,0,src1,b.getHeight());
                RectF dst=new RectF(x,top,x+1.2f,bottom);
                c.drawBitmap(b,src,dst,spritePaint);
            }
        }

        void drawFakeOccluded(Canvas c,int x,float cy,float half,double distance,double spriteRel,int screenW){
            // Draw a tiny fake item as a bitmap-like vector, with the same depth test.
            float left=x-half,right=x+half,top=cy-half*.75f,bottom=cy+half;
            int x0=Math.max(0,(int)left),x1=Math.min(screenW-1,(int)right);
            for(int px=x0;px<=x1;px++){
                int ray=(int)(((double)px/screenW)*depth.length);
                if(ray<0)ray=0;if(ray>=depth.length)ray=depth.length-1;
                double rayRel=-Math.toRadians(68)/2.0+(((double)px+0.5)/screenW)*Math.toRadians(68);
                if(distance*Math.cos(rayRel-spriteRel)>depth[ray]+.06)continue;
                p.setColor(Color.rgb(92,75,58));
                float k=(px-left)/(right-left), xx=left+k*(right-left);
                c.drawLine(xx,top+half*.20f*(float)Math.sin(k*Math.PI),xx,bottom,p);
            }
            p.setColor(Color.rgb(67,57,49));
            c.drawOval(left+half*.18f,top-half*.02f,right-half*.18f,top+half*.38f,p);
        }

        void drawWeapon(Canvas c,int w,int h){
            float walkBob=(float)Math.sin(bob*.55)*4f; boolean recoil=System.currentTimeMillis()<fireUntil; float kick=recoil?-16f:0f;
            // Hands first, so the pistol reads as something actually being held.
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(181,121,88));
            Path left=new Path();left.moveTo(w*.37f,h);left.lineTo(w*.43f,h*.84f+walkBob);left.lineTo(w*.47f,h*.88f+walkBob);left.lineTo(w*.43f,h);left.close();c.drawPath(left,p);
            Path right=new Path();right.moveTo(w*.63f,h);right.lineTo(w*.57f,h*.84f+walkBob);right.lineTo(w*.53f,h*.88f+walkBob);right.lineTo(w*.57f,h);right.close();c.drawPath(right,p);
            if(pistolSprite!=null){float bw=w*.32f,bh=bw*(pistolSprite.getHeight()/(float)pistolSprite.getWidth());float leftX=w*.5f-bw/2f;float top=h-bh*.82f+walkBob+kick; c.drawBitmap(pistolSprite,null,new RectF(leftX,top,leftX+bw,top+bh),spritePaint);}
            if(recoil){p.setColor(Color.argb(245,255,224,126));Path f=new Path();f.moveTo(w*.5f,h*.35f);f.lineTo(w*.485f,h*.52f);f.lineTo(w*.5f,h*.47f);f.lineTo(w*.515f,h*.52f);f.close();c.drawPath(f,p);}
        }

        void panel(Canvas c,float l,float t,float r,float b,int color){p.setColor(color);c.drawRoundRect(l,t,r,b,14,14,p);}
        void bar(Canvas c,float l,float t,float r,float b,float value,int fillColor){p.setColor(Color.argb(90,255,255,255));c.drawRoundRect(l,t,r,b,6,6,p);p.setColor(fillColor);c.drawRoundRect(l,t,l+(r-l)*Math.max(0,Math.min(1,value)),b,6,6,p);}

        void drawHud(Canvas c,int w,int h){
            // Compact tactical HUD, deliberately separated from the playfield.
            panel(c,12,10,w-12,74,Color.argb(218,8,15,23));
            if(face!=null)c.drawBitmap(face,null,new RectF(24,18,72,66),spritePaint);
            txt(c,"CAROLINA",84,31,15,Color.WHITE,true);txt(c,"ОПЕРАЦИЯ «ЖЁЛУДЬ»",84,54,12,Color.rgb(186,198,212),false);
            txt(c,"ЖЁЛУДИ",w*.47f,30,11,Color.rgb(180,193,207),true);txt(c,found+" / "+acornGoal(),w*.47f,56,22,Color.rgb(255,207,116),true);
            txt(c,"ЗДОРОВЬЕ",w*.62f,30,11,Color.rgb(180,193,207),true);bar(c,w*.62f,38,w*.75f,50,hp/100f,hp<35?Color.rgb(238,91,95):Color.rgb(91,194,112));txt(c,hp+"",w*.76f,51,18,Color.WHITE,true);
            txt(c,"ПАТРОНЫ",w*.83f,30,11,Color.rgb(180,193,207),true);txt(c,String.format("%02d",ammo),w*.83f,56,22,Color.WHITE,true);
            p.setColor(Color.argb(150,255,255,255));c.drawCircle(w-26,42,15,p);txtCenter(c,muted?"×":"♪",w-26,48,14,Color.rgb(25,30,36),true);
            drawMiniMap(c,w,h);
            float cy=h*.45f;p.setColor(Color.argb(230,255,248,225));p.setStrokeWidth(2);c.drawLine(w/2-11,cy,w/2-3,cy,p);c.drawLine(w/2+3,cy,w/2+11,cy,p);c.drawLine(w/2,cy-11,w/2,cy-3,p);c.drawLine(w/2,cy+3,w/2,cy+11,p);
            float jcx=100,jcy=h-86;p.setColor(Color.argb(55,255,255,255));c.drawCircle(jcx,jcy,62,p);p.setColor(Color.argb(120,220,238,220));c.drawCircle(jcx+joystickX*36,jcy+joystickY*36,24,p);
            float fx=w-106,fy=h-88;p.setColor(Color.argb(135,255,255,255));c.drawCircle(fx,fy,58,p);txtCenter(c,"ОГОНЬ",fx,fy+5,15,Color.rgb(24,29,35),true);txtCenter(c,"ТАП",fx,fy+24,10,Color.rgb(75,82,89),true);
            drawWeapon(c,w,h);
        }

        void drawMiniMap(Canvas c,int w,int h){
            float mw=154,mh=108,left=w-mw-18,top=84; panel(c,left,top,left+mw,top+mh,Color.argb(188,8,16,12));
            if(map==null)return; float sx=mw/MAP_W,sy=mh/MAP_H;
            for(int yy=0;yy<MAP_H;yy++)for(int xx=0;xx<MAP_W;xx++)if(map[yy][xx]!=0){p.setColor(Color.rgb(53,78,59));c.drawRect(left+xx*sx,top+yy*sy,left+(xx+1)*sx+1,top+(yy+1)*sy+1,p);}
            p.setColor(Color.rgb(88,151,79));for(Tree t:trees)c.drawCircle(left+(float)t.x*sx,top+(float)t.y*sy,3.5f,p);
            p.setColor(Color.rgb(255,200,100));for(Item a:acorns)c.drawCircle(left+(float)a.x*sx,top+(float)a.y*sy,3,p);
            p.setColor(Color.rgb(218,90,90));for(Enemy e:enemies)if(e.alive)c.drawCircle(left+(float)e.x*sx,top+(float)e.y*sy,3,p);
            p.setColor(Color.rgb(145,145,145));for(Enemy e:enemies)if(!e.alive)c.drawCircle(left+(float)e.x*sx,top+(float)e.y*sy,2.5f,p);
            p.setColor(Color.WHITE);float px=left+(float)playerX*sx,py=top+(float)playerY*sy;c.drawCircle(px,py,4,p);c.drawLine(px,py,px+(float)Math.cos(angle)*10,py+(float)Math.sin(angle)*10,p);
        }

        void drawToast(Canvas c,int w,int h){if(System.currentTimeMillis()>toastUntil)return;float l=w*.18f,r=w*.82f,t=h*.18f,b=t+52;panel(c,l,t,r,b,Color.argb(232,250,246,232));txtCenter(c,toast,w/2f,t+32,14,Color.rgb(46,43,48),true);postInvalidateDelayed(100);}

        void drawTitle(Canvas c,int w,int h){p.setColor(Color.rgb(16,22,18));c.drawRect(0,0,w,h,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(65,95,72));c.drawRect(w*.08f,h*.10f,w*.92f,h*.86f,p);c.drawRect(w*.20f,h*.22f,w*.80f,h*.73f,p);p.setStyle(Paint.Style.FILL);txt(c,"ACORN HUNTER",w*.10f,h*.28f,34,Color.rgb(255,176,186),true);txt(c,"OPERATION «ЖЁЛУДЬ»",w*.10f,h*.36f,38,Color.WHITE,true);txt(c,"A tiny 90s-style forest FPS",w*.10f,h*.43f,17,Color.LTGRAY,false);txt(c,"для человека, который слишком долго искал жёлуди.",w*.10f,h*.48f,16,Color.LTGRAY,false);p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.62f,w*.47f,h*.73f,28,28,p);txtCenter(c,"НАЧАТЬ ОПЕРАЦИЮ",w*.285f,h*.687f,19,Color.rgb(35,28,35),true);txt(c,"Дубы в поле зрения. Жёлуди в траве. Белки в кустах.",w*.10f,h*.84f,13,Color.rgb(155,165,155),false);}

        void drawLevelComplete(Canvas c,int w,int h){p.setColor(Color.rgb(16,22,18));c.drawRect(0,0,w,h,p);txt(c,"УРОВЕНЬ "+level+" ПРОЙДЕН",w*.10f,h*.30f,34,Color.rgb(255,205,120),true);txt(c,"Жёлуди собраны: "+found+" / "+acornGoal(),w*.10f,h*.39f,20,Color.WHITE,false);String msg=level==1?"Парк пережил первый рейд.":level==2?"Белки отступают от дубов.":"Все дубы проверены. Остался финал.";txt(c,msg,w*.10f,h*.46f,17,Color.LTGRAY,false);p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.60f,w*.50f,h*.71f,28,28,p);txtCenter(c,level<3?"ИДТИ ДАЛЬШЕ":"ЗАБРАТЬ НАГРАДУ",w*.30f,h*.667f,18,Color.rgb(35,28,35),true);}

        void drawEnd(Canvas c,int w,int h){p.setColor(Color.rgb(16,22,18));c.drawRect(0,0,w,h,p);if(screen==3){txt(c,"ОПЕРАЦИЯ ЗАВЕРШЕНА",w*.10f,h*.27f,32,Color.rgb(255,205,120),true);txt(c,"ОН СУЩЕСТВУЕТ.",w*.10f,h*.37f,42,Color.WHITE,true);txt(c,"Каролина нашла легендарный жёлудь.",w*.10f,h*.46f,19,Color.WHITE,false);txt(c,"Дарина может делать поделку.",w*.10f,h*.51f,19,Color.WHITE,false);txt(c,"Белки официально проиграли.",w*.10f,h*.56f,19,Color.rgb(255,176,186),true);txt(c,"P.S. Данил всё это время верил в тебя.",w*.10f,h*.65f,17,Color.LTGRAY,false);p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.73f,w*.44f,h*.84f,28,28,p);txtCenter(c,"ЕЩЁ РАЗ?",w*.27f,h*.80f,17,Color.rgb(35,28,35),true);}else{txt(c,"ОПЕРАЦИЯ ПРОВАЛЕНА",w*.10f,h*.32f,34,Color.rgb(255,110,120),true);txt(c,"Белки оказались сильнее.",w*.10f,h*.41f,20,Color.WHITE,false);txt(c,"Но легенда о жёлуде ещё не закончена.",w*.10f,h*.47f,17,Color.LTGRAY,false);p.setColor(Color.rgb(255,176,186));c.drawRoundRect(w*.10f,h*.68f,w*.44f,h*.79f,28,28,p);txtCenter(c,"НАЧАТЬ ЗАНОВО",w*.27f,h*.75f,17,Color.rgb(35,28,35),true);}}

        void toggleMusic(){muted=!muted;if(host.music==null)return;if(muted&&host.music.isPlaying())host.music.pause();else if(!muted&&screen>0)host.music.start();}

        @Override protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();if(w<h){drawRotatePrompt(c,w,h);postInvalidateDelayed(250);return;}if(screen==0){drawTitle(c,w,h);return;}if(screen==2){drawLevelComplete(c,w,h);return;}if(screen==3||screen==4){drawEnd(c,w,h);return;}raycast(c,w,h);renderSprites(c,w,h);drawHud(c,w,h);drawToast(c,w,h);long now=System.nanoTime();float dt=Math.min(.05f,(now-lastFrame)/1_000_000_000f);lastFrame=now;update(dt);postInvalidateDelayed(16);}

        void drawRotatePrompt(Canvas c,int w,int h){p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(16,22,18));c.drawRect(0,0,w,h,p);txtCenter(c,"ПОВЕРНИ ТЕЛЕФОН",w/2f,h*.40f,Math.min(30f,w*.07f),Color.WHITE,true);txtCenter(c,"ИГРА РАБОТАЕТ В ГОРИЗОНТАЛЬНОМ РЕЖИМЕ",w/2f,h*.48f,Math.min(15f,w*.04f),Color.LTGRAY,false);txtCenter(c,"↻",w/2f,h*.66f,Math.min(64f,w*.16f),Color.rgb(255,176,186),true);}

        @Override public boolean onTouchEvent(MotionEvent e){int action=e.getActionMasked(),idx=e.getActionIndex();float x=e.getX(idx),y=e.getY(idx);int w=getWidth(),h=getHeight();if(action==MotionEvent.ACTION_DOWN){
                if(screen==0){if(x>w*.07f&&x<w*.58f&&y>h*.55f&&y<h*.80f){begin();return true;}}
                else if(screen==2){if(x>w*.07f&&x<w*.58f&&y>h*.54f&&y<h*.80f){if(level<3){level++;loadLevel();}else screen=3;return true;}}
                else if(screen==3||screen==4){if(x>w*.07f&&x<w*.50f&&y>h*.65f){begin();return true;}}
                else if(screen==1){if(x>w-82&&y<75){toggleMusic();return true;}if(x>w*.70f&&y>h*.60f){firing=true;fireUntil=System.currentTimeMillis()+155;shoot();return true;}if(x<w*.48f&&y>h*.56f){joystickActive=true;activePointer=e.getPointerId(idx);touchStartX=x;touchStartY=y;updateJoystick(x,y);return true;}}
            } else if(action==MotionEvent.ACTION_MOVE&&screen==1){int pi=e.findPointerIndex(activePointer);if(joystickActive&&pi>=0){updateJoystick(e.getX(pi),e.getY(pi));return true;}}
            else if((action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL)&&screen==1){if(e.getPointerId(idx)==activePointer){joystickActive=false;joystickX=joystickY=0;activePointer=-1;}return true;}return true;}
        void updateJoystick(float x,float y){float dx=(x-touchStartX)/70f,dy=(y-touchStartY)/70f,len=(float)Math.hypot(dx,dy);if(len>1){dx/=len;dy/=len;}joystickX=dx;joystickY=dy;}
    }
}
