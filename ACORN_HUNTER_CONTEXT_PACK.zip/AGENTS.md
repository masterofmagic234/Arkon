# AGENTS.md — ACORN HUNTER

## Mission
Maintain and develop ACORN HUNTER — ОПЕРАЦИЯ «ЖЁЛУДЬ».

The project is a personal romantic gift game. Preserve its existing humor, atmosphere, gameplay and canonical Level 1 design unless the task explicitly requests a change.

## Before editing
- Read `PROJECT_CONTEXT.md`.
- Read `ARCHITECTURE.md`.
- Inspect the current repository state and scene/resource dependencies.
- Do not assume that a proposed fix works on Android just because it parses or builds.

## Critical rules
- Never rewrite unrelated systems.
- Never silently change the canonical map.
- Never silently change object positions.
- Never remove or rewrite established joke/dialogue text.
- Keep the canonical Level 1 gameplay intact.
- Prefer isolated changes over large rewrites.
- Preserve scene/node/resource contracts during refactors.
- Do not duplicate map, spawn or mutable state definitions.
- Do not put subsystem logic into `game.gd` unless it is orchestration.

## Input safety
Touch input has historically broken during refactors.
Treat the V19/V22 input path as the proven conceptual baseline until a replacement has been verified on Android.
Any input change must include:
- exact files changed,
- reason for change,
- static validation,
- Android test requirement.

## Runtime claims
Do not say "fixed", "working" or "verified on Android" unless the relevant runtime test actually happened.
A successful headless import/export only proves the project can be processed by Godot; it does not prove touch input or visual behavior works on a physical phone.

## Architecture
Follow `ARCHITECTURE.md`.
Keep:
- state in `core/game_state.gd`
- static level data in `core/level_data.gd`
- input in `controllers/input_controller.gd`
- player movement in `controllers/player_controller.gd`
- squirrel AI in `controllers/squirrel_controller.gd`
- pickups in `controllers/pickup_controller.gd`
- HUD in `controllers/hud_controller.gd`
- audio in `controllers/audio_controller.gd`
- orchestration in `game.gd`

## Git
- Work on a dedicated branch for non-trivial changes.
- Keep `main` stable.
- Make small, meaningful commits.
- Do not add multiple root ZIP files that CI might accidentally select.
- Prefer source-tree builds over ZIP-as-source builds.

## Validation
For every code change:
1. Check syntax/project structure.
2. Check references to renamed/moved nodes/scripts.
3. Check that no duplicate source of truth was introduced.
4. Run available Godot headless checks.
5. Export Android APK if CI supports it.
6. Report exactly what was and was not tested.

## Communication
When reporting work:
- summarize changed files,
- explain architectural impact,
- list validation performed,
- explicitly list anything that still requires physical-device testing.
