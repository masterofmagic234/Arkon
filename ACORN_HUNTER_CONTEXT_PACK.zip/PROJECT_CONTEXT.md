# ACORN HUNTER — PROJECT CONTEXT

## Purpose
ACORN HUNTER — ОПЕРАЦИЯ «ЖЁЛУДЬ» is a personal romantic gift game for Carolina.

The project is a trilogy:
1. Level 1 — Wolfenstein 3D-inspired parody: night park, maze, weapon, squirrels, acorns, HUD and minimap.
2. Level 2 — NES Ferrari Grand Prix Challenge-inspired.
3. Level 3 — modern 3D.

This document is the canonical high-level context for Level 1 work. Preserve the game's existing character, humor, atmosphere and gameplay unless a task explicitly changes them.

## Canonical Level 1 concept
Carolina hunts legendary acorns for Darina. The park contains oaks, acorns, squirrels and a fake pine cone. The tone is affectionate, absurd and playful.

End screen text:
ОПЕРАЦИЯ ЗАВЕРШЕНА
ОН СУЩЕСТВУЕТ.
Каролина нашла легендарный жёлудь.
Дарина может делать поделку.
Белки официально проиграли.
P.S. Данил всё это время верил в тебя.

Initial toast:
"Парк открыт. Дубы не прячутся — жёлуди тоже."

## Canonical Level 1 map
20×14 grid. `1` = wall, `0` = walkable.

11111111111111111111
10000000000000000001
10000011100001100001
10000010100001000001
10001010101010111001
10001000001000100001
10111000001000100001
10000000100000100101
10001110101110000101
10000000000000000101
10011101110000000101
10000000000000000001
10000000000000000001
11111111111111111111

## Canonical Level 1 object positions
Raycaster reference coordinates:

Oaks:
(5.5,2.5)
(10.5,2.5)
(14.5,3.5)
(3.5,6.5)
(8.5,6.5)
(13.5,7.5)
(17.5,8.5)
(5.5,11.5)
(12.5,11.5)

Acorns:
(5.5,2.5, .22)
(10.5,2.5, -.28)
(14.5,3.5, .20)
(13.5,7.5, -.22)

Squirrels:
(9.2,5.2)
(16.3,6.7)

Fake pine cone:
(3.5,6.5)

## Gameplay constants
Level 1:
- Ammo: 38
- Required acorns: 4
- Squirrel HP: 2
- Squirrel attack damage: 12 HP
- Squirrel attack cooldown: about 0.8 s
- Squirrels hunt the player using BFS.
- On the second successful hit, squirrel becomes stunned and uses a stunned sprite.

## Player spawn
The original native Android Level 1 reference used:
playerX = 1.5
playerY = 1.5
angle = 0.0

The equivalent 3D spawn used in the Godot migration was approximately:
(-8.5, 0.9, -5.5), with Y rotation corresponding to angle 0.

Treat the old native Android build as the conceptual/gameplay reference.

## Visual direction
Level 1 should feel like a high-quality modern reinterpretation of a Wolfenstein-like maze, not pixel art.

The night sky was rebuilt as a high-resolution equirectangular panorama with stars, Milky Way and moon. Texture filtering should remain high quality.

## Important historical builds
Known working / reference progression:
- V19: canonical map/input reference; known working controls.
- V20: described as very good, playable and completable.
- V21: controls broke.
- V22: rebuilt from V19 to preserve proven input and added high-quality night sky, squirrel BFS AI and stunned state.
- V23: attempted input/spawn fixes; reported by user as unchanged.
- V24: restored original spawn and tried `make_input_local`; runtime result must be verified on device.

Never claim Android runtime success without actually testing the APK on a device.

## Engineering philosophy
The main goal is to stop unrelated changes from breaking other systems.

Preferred separation:
- game.gd = orchestration only
- core/game_state.gd = mutable runtime state
- core/level_data.gd = map, constants, spawn and level text
- controllers/input_controller.gd = touch / joystick input
- controllers/player_controller.gd = player movement
- controllers/audio_controller.gd = audio
- controllers/hud_controller.gd = HUD
- controllers/squirrel_controller.gd = squirrel AI/combat
- controllers/pickup_controller.gd = acorns/fake object
- minimap.gd = minimap
- menu.gd = menus

Changing joystick/input should not require editing game state, HUD or squirrel AI.
Changing HP/ammo should not require changing map or movement code.
Changing the map should have one canonical source.

## Non-negotiable preservation rules
1. Do not silently redesign gameplay.
2. Do not replace the canonical map unless explicitly instructed.
3. Do not change object positions merely to make implementation easier.
4. Preserve existing phrases and joke tone.
5. Preserve the proven touch-input behavior until a replacement is verified on Android.
6. Avoid giant rewrites when a small isolated change is sufficient.
7. Before changing architecture, identify the existing scene/resource contracts.
8. Never claim a fix is verified unless it has been tested in the relevant environment.
