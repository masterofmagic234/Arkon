# ACORN HUNTER — ARCHITECTURE

## Goal
Keep systems isolated so changing one subsystem does not cascade into unrelated bugs.

## Layers

### 1. Data
`core/level_data.gd`
- canonical map
- spawn
- object positions
- level constants
- static texts

`core/game_state.gd`
- player HP
- ammo
- collected acorns
- completion/death state
- other mutable runtime state

Data files must not own rendering or input.

### 2. Controllers
`controllers/input_controller.gd`
- receives touch/mouse input
- translates raw input into intent
- joystick state
- fire/look/action intents

`controllers/player_controller.gd`
- consumes movement/look intent
- collision-aware player movement
- player orientation

`controllers/squirrel_controller.gd`
- squirrel state
- BFS pathfinding
- chase
- attack cooldown
- damage
- hit/stun state

`controllers/pickup_controller.gd`
- acorn collection
- fake pine cone interaction

`controllers/hud_controller.gd`
- reads game state
- updates HUD
- does not own game rules

`controllers/audio_controller.gd`
- music and sound effects
- no gameplay state ownership

### 3. Presentation
Scenes, meshes, textures, sprites, UI and environment should present state and receive commands from controllers.

## game.gd
`game.gd` is the composition/orchestration layer.

It should:
- create/connect systems
- pass references/dependencies
- react to major state transitions
- start/reset the level

It should NOT become a dumping ground for:
- joystick implementation
- BFS algorithm
- HUD formatting
- hard-coded map
- scattered HP/ammo mutation
- object-specific behavior

## Dependency rule
Preferred dependency direction:

Level data → controllers → presentation

Game state is shared runtime state.

Avoid circular dependencies.

If Controller A needs something from Controller B, prefer:
1. a small signal/event,
2. a narrow interface/function,
3. shared game state,
rather than direct access to B's internal variables.

## Single source of truth
There must be one canonical source for:
- map
- spawn
- level constants
- mutable player state

Do not duplicate these in multiple scripts.

## Safe change protocol
Before editing:
1. Identify which subsystem owns the behavior.
2. Inspect scene/resource references.
3. Change the smallest isolated set of files.
4. Run static/project checks.
5. Build APK.
6. Test on Android when the change affects runtime/input/rendering.
7. Only then merge.

## Backward compatibility
During refactoring, preserve existing node names, scene paths, exported properties and resource contracts whenever possible.

Do not combine architecture refactor with visual redesign unless explicitly requested.

## Refactor order
1. Add context/docs.
2. Preserve a known-good baseline.
3. Extract game state.
4. Extract level data.
5. Extract input.
6. Extract player movement.
7. Extract squirrel AI.
8. Extract pickups.
9. Extract HUD/audio.
10. Simplify game.gd.
11. Change CI from ZIP-based build to source-tree build.
12. Verify APK.

Do one stage at a time. Keep each stage buildable.
