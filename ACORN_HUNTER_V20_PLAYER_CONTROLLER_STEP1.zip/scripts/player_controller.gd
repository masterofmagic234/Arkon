extends RefCounted

# Player movement controller. Touch input remains in game.gd and feeds move_axis here.
# This keeps the proven input path unchanged while isolating player motion.
const LevelData = preload("res://scripts/level_data.gd")
const MovementMath = preload("res://scripts/movement_math.gd")
const TurnMath = preload("res://scripts/turn_math.gd")

var player

func setup(player_node) -> void:
    player = player_node

func update(delta: float, move_axis: Vector2) -> void:
    if player == null:
        return
    player.velocity = MovementMath.velocity_for_input(player.global_transform.basis, move_axis, LevelData.WALK_SPEED)
    player.move_and_slide()
    if abs(move_axis.x) > 0.04:
        player.rotate_y(TurnMath.turn_amount(move_axis.x, LevelData.TURN_SPEED, delta))

func stop() -> void:
    if player != null:
        player.velocity = Vector3.ZERO
