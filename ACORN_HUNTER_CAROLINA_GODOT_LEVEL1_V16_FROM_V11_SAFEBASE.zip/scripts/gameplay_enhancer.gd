extends Node

# V16 gameplay layer.
# IMPORTANT: this script deliberately sits on top of the proven V11 runtime.
# The V11 main script, scene structure, touch path, and world construction are untouched.

const MAX_AMMO := 38
const MAX_HP := 100
const FAKE_DAMAGE := 12

const ACORN_LINES := [
    "ЖЁЛУДЬ ДОБЫТ. Дарина, ставь чайник.",
    "Один есть. Белки нервничают.",
    "Исторический жёлудь №%d.",
    "Данил сообщает: прогресс подозрительно хороший.",
    "В карман! И никому не отдавать.",
    "Найден. Официально настоящий.",
    "Ещё один — и можно открывать музей.",
    "Жёлудь найден. Серьёзная археология."
]

const CONE_LINES := [
    "ЭТО ШИШКА. Лес тебя переиграл.",
    "Поздравляю: ты нашла не то.",
    "Дарина просила жёлуди, а не ботанику.",
    "Шишка нанесла 12 урона самолюбию.",
    "Неправильный орех. Очень неправильный.",
    "Каролина, это буквально НЕ ЖЁЛУДЬ.",
    "Лес говорит: внимательнее, пожалуйста."
]

const STUN_LINES := [
    "Белка контужена. Звёздочки прилагаются.",
    "Белка прилегла подумать.",
    "Пушистый отпуск объявлен досрочно.",
    "Белка временно недееспособна. Достойно.",
    "Она не мёртвая. Она просто очень впечатлена.",
    "Звёздочки — официальный эффект поражения.",
    "Белка выбыла. Жёлуди в безопасности."
]

const DAMAGE_LINES := [
    "АЙ! Белка кусается.",
    "Урон. Пушистый террор продолжается.",
    "Белка сказала: не подходи.",
    "Это было больно. Очень по-беличьи."
]

var main
var pickup_sound = preload("res://assets/pickup.wav")
var damage_sound = preload("res://assets/damage.wav")
var stunned_texture = preload("res://assets/squirrel_stunned.png")
var pine_cone_tex = preload("res://assets/pine_cone.png")

var last_found := 0
var last_hp := 100
var hit_once := {}
var patched_fake_hp := {}
var last_playing := false

func _ready() -> void:
    main = get_parent()
    # Parent _ready() already completed before this child is readied.
    # Reuse all V11 nodes and touch behaviour; only patch gameplay values.
    _normalize_positions()
    _connect_start_after_parent()
    _replace_fire_button()
    _set_level_state()
    last_found = int(main.found)
    last_hp = int(main.hp)
    last_playing = bool(main.playing)

func _connect_start_after_parent() -> void:
    var start_button = main.start_button
    if not start_button.pressed.is_connected(_on_start_pressed):
        start_button.pressed.connect(_on_start_pressed)

func _replace_fire_button() -> void:
    var fire_button = main.fire_button
    var parent_fire := Callable(main, "_fire")
    if fire_button.pressed.is_connected(parent_fire):
        fire_button.pressed.disconnect(parent_fire)
    if not fire_button.pressed.is_connected(_fire):
        fire_button.pressed.connect(_fire)

func _on_start_pressed() -> void:
    # Let the proven V11 start flow run first, then normalize the level state.
    call_deferred("_set_level_state")

func _set_level_state() -> void:
    main.hp = MAX_HP
    main.ammo = MAX_AMMO
    main.found = 0
    last_found = 0
    last_hp = MAX_HP
    hit_once.clear()
    patched_fake_hp.clear()
    _normalize_positions()

func _normalize_positions() -> void:
    var acorns = main.acorns
    var wanted := [
        Vector2(5.5, 2.5),
        Vector2(10.5, 2.5),
        Vector2(14.5, 3.5),
        Vector2(13.5, 7.5)
    ]
    for i in range(min(acorns.size(), wanted.size())):
        acorns[i].position = Vector3(wanted[i].x, 0.22, wanted[i].y)

    for i in range(main.squirrels.size()):
        var e: Dictionary = main.squirrels[i]
        var s = e["node"]
        var start = main.SQUIRREL_POS[i]
        s.position = Vector3(start.x, 0.58, start.y)
        e["pos"] = start
        e["hp"] = 1
        e["stunned"] = 0.0
        e["alive"] = true
        e["dead"] = false
        e["stunned_once"] = false
        hit_once[i] = false

    # V11 stores the fake object as a Sprite3D with the "fake" metadata.
    for child in main.world_root.get_children():
        if child is Sprite3D and child.has_meta("fake"):
            child.position = Vector3(3.5, 0.30, 6.5)
            child.texture = pine_cone_tex
            child.visible = true

func _physics_process(_delta: float) -> void:
    if not is_instance_valid(main):
        return

    if bool(main.playing) and not last_playing:
        _set_level_state()
    last_playing = bool(main.playing)

    _enforce_squirrel_rule()
    _enforce_fake_damage()
    _watch_pickups()
    _watch_hp()
    last_found = int(main.found)
    last_hp = int(main.hp)

func _enforce_squirrel_rule() -> void:
    for i in range(main.squirrels.size()):
        var e: Dictionary = main.squirrels[i]
        var s = e["node"]
        if e.get("stunned_once", false):
            e["alive"] = true
            e["dead"] = false
            e["hp"] = 1
        if e.get("stunned_once", false) and is_instance_valid(s):
            if e.get("stunned", 0.0) <= 0.0 and not hit_once.get(i, false):
                # Keep the original V11 visual, only the state is persistent.
                s.rotation.z = 0.0

func _enforce_fake_damage() -> void:
    for child in main.world_root.get_children():
        if not (child is Sprite3D) or not child.has_meta("fake"):
            continue
        var id = child.get_instance_id()
        if not child.visible and not patched_fake_hp.has(id):
            # V11 subtracts 15. Restore 3, making the net loss exactly 12.
            main.hp = min(MAX_HP, int(main.hp) + 3)
            patched_fake_hp[id] = true
            _say(CONE_LINES[randi() % CONE_LINES.size()])
            _play_fx(damage_sound)
        elif child.visible and patched_fake_hp.has(id):
            patched_fake_hp.erase(id)

func _watch_pickups() -> void:
    if int(main.found) <= last_found:
        return
    var n := int(main.found)
    _play_fx(pickup_sound)
    var line: String = ACORN_LINES[randi() % ACORN_LINES.size()]
    if "%d" in line:
        _say(line % n)
    else:
        _say(line)

func _watch_hp() -> void:
    if int(main.hp) < last_hp and int(main.hp) > 0:
        _play_fx(damage_sound)
        _say(DAMAGE_LINES[randi() % DAMAGE_LINES.size()])

func _fire() -> void:
    if not main.playing or main.fire_cooldown > 0.0:
        return
    if int(main.ammo) <= 0:
        _say("Пусто. Даже белки в шоке.")
        return

    main.ammo -= 1
    main.fire_cooldown = 0.20
    _play_fx(main.shoot_sound)
    main._weapon_kick()

    var best_index := -1
    var best_d := 999.0
    var forward := Vector2(-sin(main.player.rotation.y), -cos(main.player.rotation.y))
    var pp := Vector2(main.player.global_position.x, main.player.global_position.z)

    for i in range(main.squirrels.size()):
        var e: Dictionary = main.squirrels[i]
        var p: Vector2 = e["pos"]
        var d := p.distance_to(pp)
        if d > 9.0 or d < 0.2:
            continue
        var v := p - pp
        var align := forward.dot(v.normalized())
        if align > 0.985 and d < best_d and main._clear_shot(p):
            best_index = i
            best_d = d

    if best_index < 0:
        return

    var e: Dictionary = main.squirrels[best_index]
    var s = e["node"]
    # Only the first hit has a gameplay effect. Every later shot is a miss.
    if e.get("stunned_once", false):
        _say("Белка уже огребла. Этот выстрел считается промахом.")
        return

    e["stunned_once"] = true
    hit_once[best_index] = true
    e["stunned"] = 1.5
    e["alive"] = true
    e["dead"] = false
    e["hp"] = 1
    s.texture = stunned_texture
    main._add_stars(e)
    _play_fx(main.squirrel_hit)
    _say(STUN_LINES[randi() % STUN_LINES.size()])

func _say(text: String) -> void:
    main._say(text)

func _play_fx(stream: AudioStream) -> void:
    if main.muted:
        return
    main.audio_fx.stream = stream
    main.audio_fx.play()
