extends Node3D

# ACORN HUNTER — LEVEL 1
# Rebuilt from the last proven CLEAN/V6 control foundation.
# World sprites are deliberately MeshInstance3D + QuadMesh, not Sprite3D.
# UI owns touch input: joystick.gui_input + Fire.pressed.

const WALK_SPEED := 3.4
const TURN_SPEED := 2.15
const JOYSTICK_RADIUS := 58.0
const ACORN_PICKUP_RADIUS := 1.25
const FIRE_RANGE := 18.0
const SQUIRREL_LAYER := 2
const WORLD_LAYER := 1
const MAX_AMMO := 38
const MAX_HP := 100

var move_axis := Vector2.ZERO
var joystick_touch_id := -1
var collected := 0
var ammo := MAX_AMMO
var hp := MAX_HP
var message_time := 0.0
var fire_cooldown := 0.0
var damage_cooldown := 0.0
var recoil_time := 0.0
var foot_timer := 0.0
var fake_cone_found := false
var mission_complete := false
var mission_failed := false
var muted := false
var stunned: Dictionary = {}
var squirrel_hp := {"Squirrel01": 2, "Squirrel02": 2}
var squirrel_repath_timer := 0.0
var squirrel_next_cells := {"Squirrel01": Vector2i(-1, -1), "Squirrel02": Vector2i(-1, -1)}
var acorns := ["Acorn01", "Acorn02", "Acorn03", "Acorn04"]
var squirrels := ["Squirrel01", "Squirrel02"]
var squirrel_home := {
    "Squirrel01": Vector2(-1.5, 1.2),
    "Squirrel02": Vector2(4.0, -1.0)
}
var squirrel_phase := {"Squirrel01": 0.0, "Squirrel02": 1.7}

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var joystick: Panel = $HUD/Joystick
@onready var knob: Panel = $HUD/Joystick/Knob
@onready var fire_button: Button = $HUD/Fire
@onready var mute_button: Button = $HUD/Mute
@onready var count_label: Label = $HUD/Count
@onready var hp_ammo_label: Label = $HUD/HPAmmo
@onready var message_label: Label = $HUD/Message
@onready var mission_panel: Panel = $HUD/Mission
@onready var mission_title: Label = $HUD/Mission/Title
@onready var mission_body: Label = $HUD/Mission/Body
@onready var weapon: TextureRect = $HUD/Weapon
@onready var muzzle: ColorRect = $HUD/MuzzleFlash
@onready var hit_marker: Label = $HUD/HitMarker
@onready var carolina: TextureRect = $HUD/Carolina
@onready var music: AudioStreamPlayer = $Music
@onready var fx: AudioStreamPlayer = $FX

var foot1_stream = preload("res://assets/footstep1.wav")
var foot2_stream = preload("res://assets/footstep2.wav")
var shoot_stream = preload("res://assets/shoot.wav")
var squirrel_hit_stream = preload("res://assets/squirrel_hit.wav")
var pickup_stream = preload("res://assets/pickup.wav")
var damage_stream = preload("res://assets/damage.wav")

const ACORN_LINES := [
    "ЖЁЛУДЬ ДОБЫТ. Дарина, ставь чайник.",
    "Один есть. Белки нервничают.",
    "Исторический жёлудь №%d.",
    "Данил сообщает: прогресс подозрительно хороший.",
    "В карман! И никому не отдавать.",
    "Найден. Официально настоящий.",
    "Ещё один — и можно открывать музей.",
    "Жёлудь найден. Серьёзная археология."
]
const CONE_LINES := [
    "ЭТО ШИШКА. Лес тебя переиграл.",
    "Поздравляю: ты нашла не то.",
    "Дарина просила жёлуди, а не ботанику.",
    "Шишка нанесла 12 урона самолюбию.",
    "Неправильный орех. Очень неправильный.",
    "Каролина, это буквально НЕ ЖЁЛУДЬ.",
    "Лес говорит: внимательнее, пожалуйста."
]
const HIT_LINES := [
    "ПОПАЛА. Белка задумалась о жизни.",
    "Белка получила аргумент.",
    "Точно в пушистую проблему.",
    "Попадание! Белка пересматривает карьеру.",
    "Минус одна попытка украсть жёлудь.",
    "Белка: это было неожиданно.",
    "Тихо. Я всё видела. Отличный выстрел."
]
const STUN_LINES := [
    "Белка контужена. Звёздочки прилагаются.",
    "Белка прилегла подумать.",
    "Пушистый отпуск объявлен досрочно.",
    "Белка временно недееспособна. Достойно.",
    "Она не мёртвая. Она просто очень впечатлена.",
    "Звёздочки — официальный эффект поражения.",
    "Белка выбыла. Жёлуди в безопасности."
]
const DAMAGE_LINES := [
    "АЙ! Белка кусается.",
    "Урон. Пушистый террор продолжается.",
    "Белка сказала: не подходи.",
    "Это было больно. Очень по-беличьи."
]

func _ready() -> void:
    camera.rotation = Vector3.ZERO
    camera.fov = 72.0
    camera.near = 0.05
    camera.far = 40.0
    carolina.texture = load("res://assets/carolina_face.png")
    mission_panel.visible = false
    muzzle.visible = false
    hit_marker.visible = false
    knob.position = joystick.size * 0.5 - knob.size * 0.5

    # Touch is handled by the actual UI controls, not by a global input relay.
    joystick.gui_input.connect(_on_joystick_gui_input)
    fire_button.pressed.connect(_on_fire_pressed)
    mute_button.pressed.connect(_toggle_music)
    $HUD/Mission/Menu.pressed.connect(_on_menu_pressed)

    music.volume_db = -9.0
    music.play()
    _update_hud()
    _set_message("Парк открыт. Дубы не прячутся — жёлуди тоже.", 4.0)
    _refresh_minimap()
    _face_world_sprites()

func _physics_process(delta: float) -> void:
    if mission_complete or mission_failed:
        player.velocity = Vector3.ZERO
        return

    var forward := -move_axis.y
    player.velocity = -player.global_transform.basis.z * (forward * WALK_SPEED)
    player.velocity.y = 0.0
    player.move_and_slide()

    if abs(move_axis.x) > 0.04:
        player.rotate_y(-move_axis.x * TURN_SPEED * delta)

    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    damage_cooldown = maxf(0.0, damage_cooldown - delta)
    recoil_time = maxf(0.0, recoil_time - delta)
    message_time = maxf(0.0, message_time - delta)

    if message_time <= 0.0:
        message_label.text = ""
    if recoil_time <= 0.0:
        weapon.position.y = 455.0
    if muzzle.visible:
        muzzle.modulate.a = clampf(muzzle.modulate.a - delta * 7.0, 0.0, 1.0)
        if muzzle.modulate.a <= 0.0:
            muzzle.visible = false

    if abs(forward) > 0.05:
        foot_timer -= delta
        if foot_timer <= 0.0:
            _footstep()
            foot_timer = 0.30
    else:
        foot_timer = 0.0

    _update_squirrels(delta)
    _collect_acorns()
    _check_fake_cone()
    _face_world_sprites()
    _update_hud()
    _refresh_minimap()

func _on_joystick_gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            joystick_touch_id = event.index
            _update_joystick(event.position)
            joystick.accept_event()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _update_joystick(event.position)
        joystick.accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            joystick_touch_id = -2
            _update_joystick(event.position)
            joystick.accept_event()
        elif joystick_touch_id == -2:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventMouseMotion and joystick_touch_id == -2:
        _update_joystick(event.position)
        joystick.accept_event()

func _update_joystick(position: Vector2) -> void:
    var center := joystick.size * 0.5
    var delta := position - center
    if delta.length() > JOYSTICK_RADIUS:
        delta = delta.normalized() * JOYSTICK_RADIUS
    move_axis = Vector2(delta.x / JOYSTICK_RADIUS, delta.y / JOYSTICK_RADIUS)
    knob.position = center - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func _on_fire_pressed() -> void:
    if mission_complete or mission_failed or fire_cooldown > 0.0:
        return
    if ammo <= 0:
        _set_message("Пусто. Даже белки в шоке.", 1.2)
        return

    ammo -= 1
    fire_cooldown = 0.18
    recoil_time = 0.10
    weapon.position.y = 470.0
    muzzle.visible = true
    muzzle.modulate.a = 1.0
    _play_fx(shoot_stream)

    var query := PhysicsRayQueryParameters3D.create(
        camera.global_position,
        camera.global_position + (-camera.global_transform.basis.z * FIRE_RANGE),
        SQUIRREL_LAYER | WORLD_LAYER
    )
    query.collide_with_areas = true
    query.collide_with_bodies = true
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        _miss()
        return

    var squirrel := _find_squirrel_from_collider(hit.get("collider"))
    if squirrel == "" or stunned.has(squirrel):
        _miss()
        return

    squirrel_hp[squirrel] = int(squirrel_hp.get(squirrel, 2)) - 1
    var target := get_node_or_null(squirrel) as MeshInstance3D
    hit_marker.visible = true
    hit_marker.text = "×"
    _play_fx(squirrel_hit_stream)
    if int(squirrel_hp[squirrel]) <= 0:
        stunned[squirrel] = true
        if target != null:
            var stunned_texture := load("res://assets/squirrel_stunned.png")
            if stunned_texture != null and target.mesh is QuadMesh:
                var base_mat := (target.mesh as QuadMesh).material as StandardMaterial3D
                if base_mat != null:
                    var unique_mat := base_mat.duplicate() as StandardMaterial3D
                    unique_mat.albedo_texture = stunned_texture
                    target.set_surface_override_material(0, unique_mat)
            target.rotation.z = deg_to_rad(-7.0)
            target.scale = Vector3(1.0, 0.82, 1.0)
        _set_message(STUN_LINES.pick_random(), 2.0)
    else:
        _set_message("%s\nЕщё одно попадание — и белка отдыхает." % HIT_LINES.pick_random(), 1.4)
    await get_tree().create_timer(0.35).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _find_squirrel_from_collider(collider: Object) -> String:
    var node := collider as Node
    while node != null:
        if squirrels.has(node.name):
            return node.name
        node = node.get_parent()
    return ""

func _miss() -> void:
    hit_marker.visible = true
    hit_marker.text = "•"
    _set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await get_tree().create_timer(0.22).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _update_squirrels(delta: float) -> void:
    squirrel_repath_timer = maxf(0.0, squirrel_repath_timer - delta)
    var player_pos := Vector2(player.global_position.x, player.global_position.z)
    var player_cell := _world_to_cell(player_pos)
    for name in squirrels:
        if stunned.has(name):
            continue
        var node := get_node_or_null(name) as MeshInstance3D
        if node == null:
            continue
        var squirrel_pos := Vector2(node.global_position.x, node.global_position.z)
        var dist := squirrel_pos.distance_to(player_pos)
        if dist > 0.9:
            var squirrel_cell := _world_to_cell(squirrel_pos)
            if squirrel_repath_timer <= 0.0 or squirrel_next_cells[name] == Vector2i(-1, -1):
                squirrel_next_cells[name] = _next_cell_toward(squirrel_cell, player_cell)
            var next_cell: Vector2i = squirrel_next_cells[name]
            var target_pos := player_pos if next_cell == squirrel_cell else _cell_to_world(next_cell)
            var direction := target_pos - squirrel_pos
            if direction.length() > 0.03:
                direction = direction.normalized()
                var proposed := squirrel_pos + direction * 1.25 * delta
                if _can_squirrel_occupy(proposed):
                    node.global_position.x = proposed.x
                    node.global_position.z = proposed.y
                else:
                    squirrel_next_cells[name] = _next_cell_toward(squirrel_cell, player_cell)
        node.rotation.z = sin(Time.get_ticks_msec() * 0.003 + float(squirrel_phase[name])) * 0.03
        if dist < 0.95 and damage_cooldown <= 0.0:
            damage_cooldown = 0.8
            hp = max(0, hp - 12)
            _play_fx(damage_stream)
            _set_message(DAMAGE_LINES.pick_random(), 1.2)
            if hp <= 0:
                _fail()
    if squirrel_repath_timer <= 0.0:
        squirrel_repath_timer = 0.18

func _world_to_cell(pos: Vector2) -> Vector2i:
    return Vector2i(int(floor(pos.x + 10.0)), int(floor(pos.y + 7.0)))

func _cell_to_world(cell: Vector2i) -> Vector2:
    return Vector2(float(cell.x) - 9.5, float(cell.y) - 6.5)

func _cell_is_free(cell: Vector2i) -> bool:
    if cell.x < 0 or cell.x >= 20 or cell.y < 0 or cell.y >= 14:
        return false
    return CANONICAL_MAP[cell.y].substr(cell.x, 1) == "0"

func _next_cell_toward(start: Vector2i, goal: Vector2i) -> Vector2i:
    if not _cell_is_free(start):
        return start
    if not _cell_is_free(goal):
        return start
    if start == goal:
        return start
    var queue: Array[Vector2i] = [start]
    var parent := {start: Vector2i(-999, -999)}
    var head := 0
    var dirs := [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1)]
    while head < queue.size():
        var current: Vector2i = queue[head]
        head += 1
        if current == goal:
            break
        for d in dirs:
            var nxt := current + d
            if _cell_is_free(nxt) and not parent.has(nxt):
                parent[nxt] = current
                queue.append(nxt)
    if not parent.has(goal):
        return start
    var step := goal
    while parent[step] != start and parent[step] != Vector2i(-999, -999):
        step = parent[step]
    return step

func _can_squirrel_occupy(pos: Vector2) -> bool:
    var r := 0.28
    for offset in [Vector2.ZERO, Vector2(r,0), Vector2(-r,0), Vector2(0,r), Vector2(0,-r)]:
        if _is_wall(pos.x + offset.x, pos.y + offset.y):
            return false
    return true

const CANONICAL_MAP := [
    "11111111111111111111",
    "10000000000000000001",
    "10000011100001100001",
    "10000010100001000001",
    "10001010101010111001",
    "10001000001000100001",
    "10111000001000100001",
    "10000000100000100101",
    "10001110101110000101",
    "10000000000000000101",
    "10011101110000000101",
    "10000000000000000001",
    "10000000000000000001",
    "11111111111111111111"
]

func _is_wall(x: float, z: float) -> bool:
    var cell_x := int(floor(x + 10.0))
    var cell_z := int(floor(z + 7.0))
    if cell_x < 0 or cell_x >= 20 or cell_z < 0 or cell_z >= 14:
        return true
    return CANONICAL_MAP[cell_z].substr(cell_x, 1) == "1"

func _collect_acorns() -> void:
    for name in acorns.duplicate():
        var node := get_node_or_null(name) as MeshInstance3D
        if node != null and player.global_position.distance_to(node.global_position) <= ACORN_PICKUP_RADIUS:
            node.visible = false
            acorns.erase(name)
            collected += 1
            if pickup_stream != null:
                _play_fx(pickup_stream)
            _set_message(ACORN_LINES.pick_random() + "\nЖёлуди: %d / 4" % collected, 1.8)
            if collected == 4:
                _complete()

func _check_fake_cone() -> void:
    if fake_cone_found:
        return
    var cone := get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null and player.global_position.distance_to(cone.global_position) <= 1.2:
        fake_cone_found = true
        hp = max(0, hp - 12)
        if damage_stream != null:
            _play_fx(damage_stream)
        _set_message(CONE_LINES.pick_random(), 2.4)
        if hp <= 0:
            _fail()

func _complete() -> void:
    mission_complete = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    mission_body.text = "ЖЁЛУДИ: 4 / 4\n\nОН СУЩЕСТВУЕТ.\n\nКаролина нашла легендарный жёлудь.\nДарина может делать поделку.\nБелки официально проиграли.\n\nP.S. Данил всё это время верил в тебя."
    weapon.visible = false

func _fail() -> void:
    mission_failed = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ПРОВАЛЕНА"
    mission_body.text = "HP: 0\n\nБелки победили.\nЭто позор.\n\nНо Дарина всё ещё ждёт жёлуди."
    weapon.visible = false

func _update_hud() -> void:
    count_label.text = "ЖЁЛУДИ  %d / 4" % collected
    hp_ammo_label.text = "HP %d     AMMO %d" % [hp, ammo]

func _set_message(text: String, duration: float) -> void:
    message_label.text = text
    message_time = duration

func _footstep() -> void:
    if muted:
        return
    fx.stream = foot1_stream if int(Time.get_ticks_msec() / 300) % 2 == 0 else foot2_stream
    fx.play()

func _play_fx(stream: AudioStream) -> void:
    if muted or stream == null:
        return
    fx.stream = stream
    fx.play()

func _toggle_music() -> void:
    muted = not muted
    mute_button.text = "×" if muted else "♪"
    if muted:
        music.stop()
    elif not music.playing:
        music.play()
    _set_message("Музыка выключена." if muted else "Музыка возвращена. Белки снова слышат угрозу.", 1.6)

func _face_world_sprites() -> void:
    for name in ["Tree01", "Tree02", "Tree03", "Tree04", "Tree05", "Tree06", "Acorn01", "Acorn02", "Acorn03", "Acorn04", "Squirrel01", "Squirrel02", "FakePineCone", "Moon", "Star01", "Star02", "Star03"]:
        var node := get_node_or_null(name) as MeshInstance3D
        if node != null:
            var target := camera.global_position
            target.y = node.global_position.y
            node.look_at(target, Vector3.UP)

func _refresh_minimap() -> void:
    $HUD/Minimap.set_game_state(player.global_position, player.rotation.y, acorns, squirrels, stunned)

func _on_menu_pressed() -> void:
    get_tree().change_scene_to_file("res://menu.tscn")
