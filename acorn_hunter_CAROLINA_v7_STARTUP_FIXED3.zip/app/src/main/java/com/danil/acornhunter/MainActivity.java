package com.danil.acornhunter;

import android.app.*;import android.os.*;import android.content.*;import android.content.pm.ActivityInfo;import android.graphics.*;import android.graphics.drawable.*;import android.media.*;import android.opengl.GLES20;import android.opengl.GLSurfaceView;import android.opengl.Matrix;import android.view.*;import android.widget.FrameLayout;import android.widget.TextView;import java.io.PrintWriter;import java.io.StringWriter;import java.nio.*;import java.util.*;import javax.microedition.khronos.egl.EGLConfig;import javax.microedition.khronos.opengles.GL10;import android.opengl.GLES20;

public class MainActivity extends Activity{
 MediaPlayer music; SoundPool sounds; int step1,step2,hit; GameManager gm;
 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
  try{
   immersive();
   gm=new GameManager(this);
   setContentView(gm);
  }catch(Throwable e){
   showStartupError(e);
  }
 }
 void showStartupError(Throwable e){
  StringWriter sw=new StringWriter();
  e.printStackTrace(new PrintWriter(sw));
  android.util.Log.e("ACORN_HUNTER_CRASH","Startup crash",e);
  TextView tv=new TextView(this);
  tv.setBackgroundColor(Color.rgb(10,10,12));
  tv.setTextColor(Color.WHITE);
  tv.setTextSize(14);
  tv.setPadding(32,32,32,32);
  tv.setText("ACORN HUNTER — STARTUP ERROR\n\n"+sw.toString());
  setContentView(new FrameLayout(this){{addView(tv,new FrameLayout.LayoutParams(-1,-1));}});
 }
 void initAudio(){if(sounds==null){sounds=new SoundPool.Builder().setMaxStreams(8).build();step1=sounds.load(this,R.raw.footstep1,1);step2=sounds.load(this,R.raw.footstep2,1);hit=sounds.load(this,R.raw.squirrel_hit,1);}}

 void immersive(){getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);getWindow().getDecorView().setSystemUiVisibility(5894);if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false);}
 @Override public void onWindowFocusChanged(boolean f){super.onWindowFocusChanged(f);if(f)immersive();}
 @Override protected void onPause(){super.onPause();if(music!=null)music.pause();}
 @Override protected void onResume(){super.onResume();immersive();}
 @Override protected void onDestroy(){if(music!=null)music.release();if(sounds!=null)sounds.release();super.onDestroy();}
 void playMusic(boolean race){initAudio();if(music!=null){try{music.stop();}catch(Exception ignored){}music.release();}music=MediaPlayer.create(this,race?R.raw.race_music:R.raw.acorn_music);if(music!=null){music.setLooping(true);music.setVolume(.24f,.24f);music.start();}}

 class GameManager extends FrameLayout{
  View current; int level=0; Bitmap face;
  GameManager(Context c){super(c);face=BitmapFactory.decodeResource(getResources(),R.drawable.carolina_face);showTitle();}
  void showTitle(){level=0;current=new TitleView(MainActivity.this);removeAllViews();addView(current);}
  void start(){level=1;initAudio();playMusic(false);setLevel1();}
  void setLevel1(){current=new FPSView(MainActivity.this);removeAllViews();addView(current);}
  void setLevel2(){level=2;playMusic(true);current=new RaceView(MainActivity.this);removeAllViews();addView(current);}
  void setLevel3(){level=3;playMusic(false);current=new Modern3DView(MainActivity.this);removeAllViews();addView(current);}
  void finish(){if(music!=null)music.pause();current=new EndingView(MainActivity.this);removeAllViews();addView(current);}
 }

 class Base extends View{Paint p=new Paint(3);Bitmap face;Base(Context c){super(c);face=BitmapFactory.decodeResource(getResources(),R.drawable.carolina_face);setFocusable(true);}void t(Canvas c,String s,float x,float y,float z,int col,boolean b){p.setColor(col);p.setTextSize(z);p.setTypeface(b?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);}void tc(Canvas c,String s,float x,float y,float z,int col,boolean b){p.setTextSize(z);p.setTypeface(b?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);t(c,s,x-p.measureText(s)/2,y,z,col,b);}void panel(Canvas c,float l,float top,float r,float bot,int col){p.setColor(col);p.setStyle(Paint.Style.FILL);c.drawRect(l,top,r,bot,p);}}

 class TitleView extends Base{
  TitleView(Context c){super(c);setClickable(true);}
  protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();c.drawColor(Color.rgb(7,10,18));tc(c,"ACORN HUNTER",w/2f,h*.25f,Math.min(w,h)*.105f,Color.WHITE,true);tc(c,"A JOURNEY THROUGH GAMING HISTORY",w/2f,h*.34f,Math.min(w,h)*.035f,0xffb9c6d6,false);tc(c,"1992  →  1993  →  2026",w/2f,h*.43f,Math.min(w,h)*.045f,0xffffcf67,true);panel(c,w*.37f,h*.57f,w*.63f,h*.70f,0xff2b3342);tc(c,"НАЧАТЬ",w/2f,h*.655f,Math.min(w,h)*.045f,Color.WHITE,true);tc(c,"Три уровня. Три эпохи. Один жёлудь.",w/2f,h*.82f,Math.min(w,h)*.028f,0xff93a0b1,false);}
  @Override public boolean onTouchEvent(MotionEvent e){
    if(e.getAction()==MotionEvent.ACTION_UP){
      float w=getWidth(),h=getHeight();
      if(e.getX()>=w*.37f && e.getX()<=w*.63f && e.getY()>=h*.57f && e.getY()<=h*.70f){
        gm.start();
      }
      return true;
    }
    return true;
  }
 }

 class FPSView extends Base{
  Paint sp=new Paint(3);Bitmap oak,squirrel,acorn;Random r=new Random(9);int W=18,H=12;int[][] map=new int[H][W];double x=1.6,y=1.6,a=0;float jx,jy;boolean joy;int found=0,goal=5,hp=100,ammo=24;ArrayList<P> trees=new ArrayList<>(),nuts=new ArrayList<>(),sq=new ArrayList<>();long nextStep;boolean fire;
  class P{double x,y;boolean live=true;P(double X,double Y){x=X;y=Y;}}
  FPSView(Context c){super(c);oak=load(R.drawable.oak_tree);squirrel=load(R.drawable.squirrel);acorn=load(R.drawable.acorn);for(int yy=0;yy<H;yy++)for(int xx=0;xx<W;xx++)map[yy][xx]=(xx==0||yy==0||xx==W-1||yy==H-1||((xx==5||xx==12)&&yy>2&&yy<9))?1:0;map[6][5]=0;map[7][12]=0;tree(3.5,3);tree(7.5,3);tree(14.5,3);tree(3.5,8.5);tree(8.5,9);tree(15,8);tree(10,4.5);for(P q:trees)nuts.add(new P(q.x+.38,q.y+.1));sq.add(new P(6,5));sq.add(new P(13,7));sq.add(new P(15,5));}
  Bitmap load(int id){return BitmapFactory.decodeResource(getResources(),id);}void tree(double X,double Y){trees.add(new P(X,Y));}
  boolean wall(double X,double Y){int ix=(int)Math.floor(X),iy=(int)Math.floor(Y);return ix<0||iy<0||ix>=W||iy>=H||map[iy][ix]==1;}boolean ok(double X,double Y){return !wall(X-.16,Y-.16)&&!wall(X+.16,Y+.16)&&!wall(X-.16,Y+.16)&&!wall(X+.16,Y-.16);}
  void move(double dx,double dy){double nx=x+dx,ny=y+dy;if(ok(nx,y))x=nx;if(ok(x,ny))y=ny;}
  protected void onDraw(Canvas c){int w=getWidth(),h=getHeight();float hor=h*.47f;p.setShader(new LinearGradient(0,0,0,hor,0xff071021,0xff34435e,Shader.TileMode.CLAMP));c.drawRect(0,0,w,hor,p);p.setShader(null);p.setColor(0xff183b24);c.drawRect(0,hor,w,h,p);p.setColor(0xffe9e9c9);c.drawCircle(w*.82f,h*.13f,Math.min(w,h)*.035f,p);int rays=Math.min(480,Math.max(260,w/3));float[] dep=new float[rays];double fov=Math.toRadians(68);for(int i=0;i<rays;i++){double ra=a-fov/2+fov*(i+.5)/rays;double d=0,rx=x,ry=y,cs=Math.cos(ra),sn=Math.sin(ra);while(d<20&&!wall(rx,ry)){rx+=cs*.035;ry+=sn*.035;d+=.035;}d*=Math.cos(ra-a);dep[i]=(float)d;float wh=(float)Math.min(h*1.6,h/(d*.75));int shade=(int)Math.max(25,150-d*12);p.setColor(Color.rgb(18,shade,42));float cw=(float)w/rays;c.drawRect(i*cw,(h-wh)/2,(i+1)*cw,(h+wh)/2,p);}ArrayList<P> all=new ArrayList<>();all.addAll(trees);all.addAll(nuts);all.addAll(sq);all.sort((u,v)->Double.compare(dist(v.x,v.y),dist(u.x,u.y)));for(P q:all){if(!q.live)continue;double dx=q.x-x,dy=q.y-y,d=Math.hypot(dx,dy),rel=norm(Math.atan2(dy,dx)-a);if(Math.abs(rel)>fov/2+.3)continue;int sx=(int)((.5+rel/fov)*w);int idx=Math.max(0,Math.min(rays-1,(int)((double)sx/w*rays)));if(d>dep[idx]+.2)continue;int size=(int)Math.min(h*.75,h/(d*.72));int top=h/2-size/2;Bitmap b=trees.contains(q)?oak:(sq.contains(q)?squirrel:acorn);c.drawBitmap(b,null,new Rect(sx-size/2,top,sx+size/2,top+size),sp);}hud(c,w,h);if(fire){p.setColor(Color.WHITE);c.drawRect(w*.47f,h*.49f,w*.53f,h*.51f,p);}}
  double dist(double X,double Y){return Math.hypot(X-x,Y-y);}double norm(double z){while(z>Math.PI)z-=Math.PI*2;while(z<-Math.PI)z+=Math.PI*2;return z;}
  void hud(Canvas c,int w,int h){panel(c,0,0,w,h*.12f,0xaa071018);c.drawBitmap(face,null,new Rect((int)(w*.39f),8,(int)(w*.39f+h*.095f), (int)(h*.105f)),p);t(c,"CAROLINA",w*.47f,h*.045f,Math.min(w,h)*.028f,Color.WHITE,true);t(c,"HP "+hp,w*.62f,h*.045f,Math.min(w,h)*.028f,0xff82e58a,true);t(c,"ЖЁЛУДИ "+found+"/"+goal,w*.76f,h*.045f,Math.min(w,h)*.026f,0xffffd66b,true);t(c,"AMMO "+ammo,w*.76f,h*.085f,Math.min(w,h)*.023f,0xffd7e1ef,false);p.setColor(0x66111111);c.drawCircle(w*.12f,h*.84f,h*.105f,p);c.drawCircle(w*.88f,h*.84f,h*.08f,p);tc(c,"АТАКА",w*.88f,h*.855f,h*.027f,Color.WHITE,true);}
  public boolean onTouchEvent(android.view.MotionEvent e){float X=e.getX(),Y=e.getY();if(e.getAction()==0){if(X<getWidth()*.3&&Y>getHeight()*.65){joy=true;jx=(X-getWidth()*.12f)/(getWidth()*.12f);jy=(Y-getHeight()*.84f)/(getHeight()*.105f);return true;}if(X>getWidth()*.75&&Y>getHeight()*.68){shoot();return true;}}if(e.getAction()==2&&joy){jx=Math.max(-1,Math.min(1,(X-getWidth()*.12f)/(getWidth()*.12f)));jy=Math.max(-1,Math.min(1,(Y-getHeight()*.84f)/(getHeight()*.105f)));return true;}if(e.getAction()==1){joy=false;jx=jy=0;}return true;}
  void shoot(){if(ammo<=0)return;ammo--;double best=9;P hitP=null;for(P q:sq)if(q.live){double d=dist(q.x,q.y),rel=Math.abs(norm(Math.atan2(q.y-y,q.x-x)-a));if(rel<.12&&d<best){best=d;hitP=q;}}if(hitP!=null){hitP.live=false;sounds.play(MainActivity.this.hit,.55f,.55f,1,0,1);}}
  void update(){if(!joy)return;double dt=.028; a+=jx*2.6*dt;double sp=-jy*1.65*dt;move(Math.cos(a)*sp,Math.sin(a)*sp);if(Math.abs(sp)>.005&&System.currentTimeMillis()>nextStep){sounds.play((System.currentTimeMillis()/310%2==0)?step1:step2,.18f,.18f,1,0,1);nextStep=System.currentTimeMillis()+310;}for(P q:nuts)if(q.live&&dist(q.x,q.y)<.38){q.live=false;found++;}for(P q:sq)if(q.live&&dist(q.x,q.y)<.75){hp-=1;}if(found>=goal){gm.setLevel2();return;}invalidate();}
  @Override protected void onAttachedToWindow(){super.onAttachedToWindow();post(() -> tick());}void tick(){update();postDelayed(()->tick(),28);}
 }

 class RaceView extends Base{
  float playerX=0,road=0,speed=0;int pos=4,lap=1;long start=System.currentTimeMillis();Random r=new Random(2);ArrayList<Float> rivals=new ArrayList<>();
  RaceView(Context c){super(c);for(int i=0;i<4;i++)rivals.add(1.8f+i*.55f);}
  protected void onDraw(Canvas c){int w=getWidth(),h=getHeight();c.drawColor(0xff8bc7e8);p.setColor(0xff173d22);c.drawRect(0,h*.45f,w,h,p);float horizon=h*.43f;for(int i=0;i<28;i++){float y=horizon+(float)Math.pow(i/28.0,1.8)*h*.57f;float half=40+i*i*3.3f;float center=w/2f+(float)Math.sin((road+i*.28)*.65)*w*.08f;p.setColor(0xff565656);c.drawRect(center-half,y,center+half,y+8,p);p.setColor(0xffe8dfb8);c.drawRect(center-half,y,center-half+5,y+8,p);c.drawRect(center+half-5,y,center+half,y+8,p);if(i%3==0){p.setColor(0xffffffff);c.drawRect(center-4,y,center+4,y+18,p);}}// trees
 for(int i=0;i<10;i++){float yy=horizon+20+i*55;float s=18+i*7;float lx=w*.16f-i*3+(float)Math.sin(road+i)*18,rx=w*.84f+i*3;drawTree(c,lx,yy,s);drawTree(c,rx,yy,s);}
  // rivals
  for(int i=0;i<rivals.size();i++){float yy=h*.70f-rivals.get(i)*h*.04f;float xx=w/2f+(i-2)*w*.13f+(float)Math.sin(road*.5+i)*30;car(c,xx,yy,Math.min(w,h)*.07f,0xffd5d5d5);}
  car(c,w/2+playerX*w*.22f,h*.80f,Math.min(w,h)*.095f,0xffc92f35);panel(c,0,0,w,h*.13f,0xaa10151e);t(c,"CAROLINA GRAND PRIX",w*.03f,h*.055f,Math.min(w,h)*.03f,Color.WHITE,true);t(c,"POS "+pos+"/5",w*.68f,h*.055f,Math.min(w,h)*.028f,Color.WHITE,true);t(c,"LAP "+lap+"/3",w*.82f,h*.055f,Math.min(w,h)*.028f,0xffffd36a,true);panel(c,w*.04f,h*.83f,w*.25f,h*.96f,0x6610161d);tc(c,"◀  STEER  ▶",w*.145f,h*.91f,Math.min(w,h)*.026f,Color.WHITE,true);panel(c,w*.76f,h*.82f,w*.95f,h*.96f,0x66301010);tc(c,"GAS",w*.855f,h*.91f,Math.min(w,h)*.04f,Color.WHITE,true);}
  void drawTree(Canvas c,float x,float y,float s){p.setColor(0xff5b351d);c.drawRect(x-s*.16f,y-s*.2f,x+s*.16f,y+s*.35f,p);p.setColor(0xff214f2a);c.drawCircle(x,y-s*.2f,s*.65f,p);}
  void car(Canvas c,float x,float y,float s,int col){p.setColor(col);Path q=new Path();q.moveTo(x-s*.45f,y+s*.5f);q.lineTo(x-s*.3f,y-s*.5f);q.lineTo(x+s*.3f,y-s*.5f);q.lineTo(x+s*.45f,y+s*.5f);q.close();c.drawPath(q,p);p.setColor(0xff22252a);c.drawRect(x-s*.23f,y-s*.25f,x+s*.23f,y-.02f,p);}
  public boolean onTouchEvent(MotionEvent e){if(e.getAction()==0||e.getAction()==2){float nx=(e.getX()/getWidth()-.5f)*2;playerX=Math.max(-1,Math.min(1,nx));if(e.getY()>getHeight()*.72f)speed=.08f;invalidate();}if(e.getAction()==1)speed=.025f;return true;}
  @Override protected void onAttachedToWindow(){super.onAttachedToWindow();post(() -> tick());}void tick(){road+=.05f+speed;for(int i=0;i<rivals.size();i++)rivals.set(i,rivals.get(i)+.002f+(i==0?.001f:0));if(System.currentTimeMillis()-start>28000){gm.setLevel3();return;}invalidate();postDelayed(()->tick(),30);}
 }

 class Modern3DView extends GLSurfaceView{
  GLR r;float tx,ty;Modern3DView(Context c){super(c);setEGLContextClientVersion(2);r=new GLR();setRenderer(r);setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);}
  public boolean onTouchEvent(MotionEvent e){if(e.getAction()==0||e.getAction()==2){tx=(e.getX()/getWidth()-.5f)*2;ty=(e.getY()/getHeight()-.5f)*2;r.steer=tx;r.forward=ty;}if(e.getAction()==1){r.forward=0;r.steer=0;}return true;}
  class GLR implements GLSurfaceView.Renderer{float px=0,pz=5,ang=3.14f,steer,forward;int prog;FloatBuffer vb;int[] tex=new int[1];
   float[] verts={-20,0,-20, 20,0,-20, 20,0,20, -20,0,20};
   public void onSurfaceCreated(GL10 g,EGLConfig c){GLES20.glClearColor(.03f,.05f,.09f,1);String vs="attribute vec3 a;uniform mat4 m;void main(){gl_Position=m*vec4(a,1.0);}";String fs="precision mediump float;uniform vec4 c;void main(){gl_FragColor=c;}";prog=prog(vs,fs);}
   int prog(String v,String f){int a=GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER);GLES20.glShaderSource(a,v);GLES20.glCompileShader(a);int b=GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER);GLES20.glShaderSource(b,f);GLES20.glCompileShader(b);int p=GLES20.glCreateProgram();GLES20.glAttachShader(p,a);GLES20.glAttachShader(p,b);GLES20.glLinkProgram(p);return p;}
   public void onSurfaceChanged(GL10 g,int w,int h){GLES20.glViewport(0,0,w,h);}
   public void onDrawFrame(GL10 g){px+=(float)(Math.sin(ang)*forward*.035);pz+=(float)(Math.cos(ang)*forward*.035);ang+=steer*.025;GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);GLES20.glEnable(GLES20.GL_DEPTH_TEST);float[] proj=new float[16],view=new float[16],m=new float[16];Matrix.frustumM(proj,0,-1,1,-.6f,.6f,1,60);Matrix.setLookAtM(view,0,px,1.6f,pz,px+(float)Math.sin(ang),1.3f,pz+(float)Math.cos(ang),0,1,0);Matrix.multiplyMM(m,0,proj,0,view,0);GLES20.glUseProgram(prog);int loc=GLES20.glGetUniformLocation(prog,"m"),cl=GLES20.glGetUniformLocation(prog,"c");GLES20.glUniformMatrix4fv(loc,1,false,m,0);for(int z=-18;z<15;z+=3)for(int x=-15;x<=15;x+=5){drawCube(m,cl,x,1,z,(x%10==0)?0xff254d2b:0xff5b3b24);}drawCube(m,cl,0,.5f,-8,0xff8b5a2b);}
   void drawCube(float[] base,int cl,float x,float y,float z,int color){float[] q=base.clone();Matrix.translateM(q,0,x,y,z);Matrix.scaleM(q,0,.7f,1.8f,.7f);GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog,"m"),1,false,q,0);GLES20.glUniform4f(cl,((color>>16)&255)/255f,((color>>8)&255)/255f,(color&255)/255f,1);float[] a={-.5f,-.5f,-.5f,.5f,-.5f,-.5f,.5f,.5f,-.5f,-.5f,.5f,-.5f};vb=ByteBuffer.allocateDirect(a.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();vb.put(a).position(0);int pos=GLES20.glGetAttribLocation(prog,"a");GLES20.glEnableVertexAttribArray(pos);GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,0,vb);GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN,0,4);GLES20.glDisableVertexAttribArray(pos);}
  }
  @Override protected void onAttachedToWindow(){super.onAttachedToWindow();postDelayed(()->{},1000);}
 }

 class EndingView extends Base{EndingView(Context c){super(c);}protected void onDraw(Canvas c){int w=getWidth(),h=getHeight();c.drawColor(0xff07120b);tc(c,"ЖЁЛУДЬ НАЙДЕН.",w/2f,h*.28f,Math.min(w,h)*.075f,0xffffd66b,true);tc(c,"ОПЕРАЦИЯ ЗАВЕРШЕНА",w/2f,h*.40f,Math.min(w,h)*.04f,Color.WHITE,true);c.drawBitmap(face,null,new Rect((int)(w*.46f),(int)(h*.48f),(int)(w*.54f),(int)(h*.70f)),p);tc(c,"Каролина, ты искала его несколько месяцев.",w/2f,h*.77f,Math.min(w,h)*.026f,0xffd8e4dd,false);tc(c,"Я решил, что если жёлудь сам к тебе не пришёл —",w/2f,h*.82f,Math.min(w,h)*.026f,0xffd8e4dd,false);tc(c,"придётся сделать игру.",w/2f,h*.87f,Math.min(w,h)*.026f,0xffffd66b,true);}}
}
