# ACORN HUNTER — V24

V24 fixes the mobile joystick using Godot's documented `CanvasItem.make_input_local()` conversion, instead of comparing stretched viewport coordinates with Control canvas coordinates. The Level 1 start is restored to the exact original Android raycaster spawn `(1.5, 1.5)`, mapped to `(-8.5, 0.9, -5.5)` in the centered 3D map.

Runtime Android testing is not available in this environment because Godot is not installed.
