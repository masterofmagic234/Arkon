# ACORN HUNTER — CLEAN V5

This build fixes two concrete problems observed on Android:

1. Sprite3D textures were being replaced by a generic white material because `material_override` was used without assigning the sprite texture to that material. Godot documents that `GeometryInstance3D.material_override` overrides the Sprite3D texture.
2. Gameplay touch input is handled at the scene level with raw `InputEventScreenTouch` / `InputEventScreenDrag`, with explicit hit testing for the joystick and fire button. Touch-to-mouse emulation is disabled to avoid duplicate input paths.

The level remains scene-authored so the visual world is available even if gameplay logic changes.
