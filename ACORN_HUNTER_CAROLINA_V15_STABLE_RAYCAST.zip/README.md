# ACORN HUNTER — Carolina v14

Raycaster build focused on a correct world-space park floor and grounded projection.

- World-space grass and stone path textures
- Path generated from the actual walkable map using shortest routes to objectives
- Shared camera/floor/wall horizon to prevent floating walls and sprites
- Dynamic world-direction sky with moving moon/stars
- Distinct high-resolution hedge wall textures
