extends Node3D

# ACORN HUNTER — LEVEL 1 — CLEAN V12
# Foundation: proven V11 QuadMesh/mobile touch build.
# This version restores the canonical Level 1 layout from the original concept
# while keeping the working V11 input/audio architecture intact.

const WALK_SPEED := 3.25
const TURN_SPEED := 2.35
const JOYSTICK_RADIUS := 58.0
const ACORN_PICKUP_RADIUS := 0.48
const FIRE_RANGE := 18.0
const SQUIRREL_LAYER := 2
const WORLD_LAYER := 1
const MAX_AMMO := 38
const MAX_HP := 100
const SQUIRREL_DAMAGE := 2
const SQUIRREL_BITE_RADIUS := 0.72
const SQUIRREL_SPEED := 0.42

const LEVEL1_MAP := [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1],
    [1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1],
    [1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
    [1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
]


var move_axis := Vector2.ZERO
var joystick_touch_id := -1
var collected := 0
var ammo := MAX_AMMO
var hp := MAX_HP
var message_time := 0.0
var fire_cooldown := 0.0
var damage_cooldown := 0.0
var recoil_time := 0.0
var foot_timer := 0.0
var fake_cone_found := false
var mission_complete := false
var mission_failed := false
var muted := false
var stunned: Dictionary = {}
var acorns := ["Acorn01", "Acorn02", "Acorn03", "Acorn04"]
var squirrels := ["Squirrel01", "Squirrel02"]
var squirrel_home := {
    "Squirrel01": Vector2(-0.3, -1.3),
    "Squirrel02": Vector2(6.8, 0.2)
}
var squirrel_phase := {"Squirrel01": 0.0, "Squirrel02": 1.7}

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var joystick: Panel = $HUD/Joystick
@onready var knob: Panel = $HUD/Joystick/Knob
@onready var fire_button: Button = $HUD/Fire
@onready var mute_button: Button = $HUD/Mute
@onready var count_label: Label = $HUD/Count
@onready var hp_ammo_label: Label = $HUD/HPAmmo
@onready var message_label: Label = $HUD/Message
@onready var mission_panel: Panel = $HUD/Mission
@onready var mission_title: Label = $HUD/Mission/Title
@onready var mission_body: Label = $HUD/Mission/Body
@onready var retry_button: Button = $HUD/Mission/Retry
@onready var weapon: TextureRect = $HUD/Weapon
@onready var muzzle: ColorRect = $HUD/MuzzleFlash
@onready var hit_marker: Label = $HUD/HitMarker
@onready var carolina: TextureRect = $HUD/Carolina
@onready var music: AudioStreamPlayer = $Music
@onready var fx: AudioStreamPlayer = $FX

var foot1_stream = preload("res://assets/footstep1.wav")
var foot2_stream = preload("res://assets/footstep2.wav")
var shoot_stream = preload("res://assets/shoot.wav")
var squirrel_hit_stream = preload("res://assets/squirrel_hit.wav")
var pickup_stream = preload("res://assets/pickup.wav")
var damage_stream = preload("res://assets/damage.wav")
var stunned_texture = preload("res://assets/squirrel_stunned.png")

const ACORN_LINES := [
    "ЖЁЛУДЬ ДОБЫТ. Дарина, ставь чайник.",
    "Один есть. Белки нервничают.",
    "Исторический жёлудь №%d.",
    "Данил сообщает: прогресс подозрительно хороший.",
    "В карман! И никому не отдавать.",
    "Найден. Официально настоящий.",
    "Ещё один — и можно открывать музей.",
    "Жёлудь найден. Серьёзная археология."
]
const CONE_LINES := [
    "ЭТО ШИШКА. Лес тебя переиграл.",
    "Поздравляю: ты нашла не то.",
    "Дарина просила жёлуди, а не ботанику.",
    "Шишка нанесла 12 урона самолюбию.",
    "Неправильный орех. Очень неправильный.",
    "Каролина, это буквально НЕ ЖЁЛУДЬ.",
    "Лес говорит: внимательнее, пожалуйста."
]
const HIT_LINES := [
    "ПОПАЛА. Белка задумалась о жизни.",
    "Белка получила аргумент.",
    "Точно в пушистую проблему.",
    "Попадание! Белка пересматривает карьеру.",
    "Минус одна попытка украсть жёлудь.",
    "Белка: это было неожиданно.",
    "Тихо. Я всё видела. Отличный выстрел."
]
const STUN_LINES := [
    "Белка контужена. Звёздочки прилагаются.",
    "Белка прилегла подумать.",
    "Пушистый отпуск объявлен досрочно.",
    "Белка временно недееспособна. Достойно.",
    "Она не мёртвая. Она просто очень впечатлена.",
    "Звёздочки — официальный эффект поражения.",
    "Белка выбыла. Жёлуди в безопасности."
]
const DAMAGE_LINES := [
    "АЙ! Белка кусается.",
    "Урон. Пушистый террор продолжается.",
    "Белка сказала: не подходи.",
    "Это было больно. Очень по-беличьи."
]

func _ready() -> void:
    camera.rotation = Vector3.ZERO
    camera.fov = 68.0
    camera.near = 0.05
    camera.far = 40.0
    carolina.texture = load("res://assets/carolina_face.png")
    mission_panel.visible = false
    muzzle.visible = false
    hit_marker.visible = false
    knob.position = joystick.size * 0.5 - knob.size * 0.5

    joystick.gui_input.connect(_on_joystick_gui_input)
    fire_button.pressed.connect(_on_fire_pressed)
    mute_button.pressed.connect(_toggle_music)
    $HUD/Mission/Menu.pressed.connect(_on_menu_pressed)
    retry_button.pressed.connect(_on_retry_pressed)

    music.volume_db = -9.0
    if not music.playing:
        music.play()
    _update_hud()
    _set_message("Парк открыт. Дубы не прячутся — жёлуди тоже.", 4.0)
    _refresh_minimap()
    _face_world_sprites()

func _physics_process(delta: float) -> void:
    if mission_complete or mission_failed:
        player.velocity = Vector3.ZERO
        return

    var forward := -move_axis.y
    player.velocity = -player.global_transform.basis.z * (forward * WALK_SPEED)
    player.velocity.y = 0.0
    player.move_and_slide()

    if abs(move_axis.x) > 0.04:
        player.rotate_y(-move_axis.x * TURN_SPEED * delta)

    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    damage_cooldown = maxf(0.0, damage_cooldown - delta)
    recoil_time = maxf(0.0, recoil_time - delta)
    message_time = maxf(0.0, message_time - delta)

    if message_time <= 0.0:
        message_label.text = ""
    if recoil_time <= 0.0:
        weapon.position.y = 455.0
    if muzzle.visible:
        muzzle.modulate.a = clampf(muzzle.modulate.a - delta * 7.0, 0.0, 1.0)
        if muzzle.modulate.a <= 0.0:
            muzzle.visible = false

    if abs(forward) > 0.05:
        foot_timer -= delta
        if foot_timer <= 0.0:
            _footstep()
            foot_timer = 0.30
    else:
        foot_timer = 0.0

    _update_squirrels(delta)
    _collect_acorns()
    _check_fake_cone()
    _face_world_sprites()
    _update_hud()
    _refresh_minimap()

func _on_joystick_gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            joystick_touch_id = event.index
            _update_joystick(event.position)
            joystick.accept_event()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _update_joystick(event.position)
        joystick.accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            joystick_touch_id = -2
            _update_joystick(event.position)
            joystick.accept_event()
        elif joystick_touch_id == -2:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventMouseMotion and joystick_touch_id == -2:
        _update_joystick(event.position)
        joystick.accept_event()

func _update_joystick(position: Vector2) -> void:
    var center := joystick.size * 0.5
    var delta := position - center
    if delta.length() > JOYSTICK_RADIUS:
        delta = delta.normalized() * JOYSTICK_RADIUS
    move_axis = Vector2(delta.x / JOYSTICK_RADIUS, delta.y / JOYSTICK_RADIUS)
    knob.position = center - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func _on_fire_pressed() -> void:
    if mission_complete or mission_failed or fire_cooldown > 0.0:
        return
    if ammo <= 0:
        _set_message("Щёлк. Пусто. Даже белки засмеялись.", 1.0)
        return

    ammo -= 1
    fire_cooldown = 0.18
    recoil_time = 0.10
    weapon.position.y = 470.0
    muzzle.visible = true
    muzzle.modulate.a = 1.0
    _play_fx(shoot_stream)

    var query := PhysicsRayQueryParameters3D.create(
        camera.global_position,
        camera.global_position + (-camera.global_transform.basis.z * FIRE_RANGE),
        SQUIRREL_LAYER | WORLD_LAYER
    )
    query.collide_with_areas = true
    query.collide_with_bodies = true
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        _miss()
        return

    var squirrel := _find_squirrel_from_collider(hit.get("collider"))
    if squirrel == "" or stunned.has(squirrel):
        _miss()
        return

    stunned[squirrel] = true
    var target := get_node_or_null(squirrel) as MeshInstance3D
    if target != null:
        target.mesh = _make_stunned_quad()
        target.modulate = Color(0.82, 0.9, 1.0, 1.0)
        target.rotation.z = deg_to_rad(-8.0)
    hit_marker.visible = true
    hit_marker.text = "×"
    _play_fx(squirrel_hit_stream)
    _set_message("%s\n%s" % [HIT_LINES.pick_random(), STUN_LINES.pick_random()], 2.0)
    await get_tree().create_timer(0.35).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _make_stunned_quad() -> QuadMesh:
    var mat := StandardMaterial3D.new()
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
    mat.shading_mode = BaseMaterial3D.SHADING_UNSHADED
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.albedo_texture = stunned_texture
    var quad := QuadMesh.new()
    quad.material = mat
    quad.size = Vector2(1.55, 1.55)
    return quad

func _find_squirrel_from_collider(collider: Object) -> String:
    var node := collider as Node
    while node != null:
        if squirrels.has(node.name):
            return node.name
        node = node.get_parent()
    return ""

func _miss() -> void:
    hit_marker.visible = true
    hit_marker.text = "•"
    _set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await get_tree().create_timer(0.22).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _update_squirrels(delta: float) -> void:
    var player_pos := Vector2(player.global_position.x, player.global_position.z)
    for name in squirrels:
        if stunned.has(name):
            continue
        var node := get_node_or_null(name) as MeshInstance3D
        if node == null:
            continue
        var squirrel_pos := Vector2(node.global_position.x, node.global_position.z)
        var dist := squirrel_pos.distance_to(player_pos)

        # The squirrels approach the player, but stop before contact.
        if dist < 6.2 and dist > 0.82:
            var toward := (player_pos - squirrel_pos).normalized()
            var proposed := squirrel_pos + toward * SQUIRREL_SPEED * delta
            if not _is_wall(proposed.x, proposed.y) and proposed.distance_to(player_pos) > 0.70:
                node.position.x = proposed.x
                node.position.z = proposed.y
                squirrel_home[name] = proposed
        node.rotation.z = sin(Time.get_ticks_msec() * 0.003 + float(squirrel_phase[name])) * 0.03

        if dist < SQUIRREL_BITE_RADIUS and damage_cooldown <= 0.0:
            damage_cooldown = 0.65
            hp = max(0, hp - SQUIRREL_DAMAGE)
            _play_fx(damage_stream)
            _set_message(DAMAGE_LINES.pick_random(), 1.0)
            if hp <= 0:
                _fail()

func _is_wall(x: float, z: float) -> bool:
    var ix := int(floor(x + 10.0))
    var iy := int(floor(z + 7.0))
    if ix < 0 or iy < 0 or ix >= 20 or iy >= 14:
        return true
    return LEVEL1_MAP[iy][ix] != 0

func _collect_acorns() -> void:
    for name in acorns.duplicate():
        var node := get_node_or_null(name) as MeshInstance3D
        if node != null and player.global_position.distance_to(node.global_position) <= ACORN_PICKUP_RADIUS:
            node.visible = false
            acorns.erase(name)
            collected += 1
            _play_fx(pickup_stream)
            var line := ACORN_LINES.pick_random()
            if line.find("%d") >= 0:
                line = line % collected
            _set_message(line + "\nЖёлуди: %d / 4" % collected, 1.8)
            if collected == 4:
                _complete()

func _check_fake_cone() -> void:
    if fake_cone_found:
        return
    var cone := get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null and player.global_position.distance_to(cone.global_position) <= 0.70:
        fake_cone_found = true
        cone.visible = false
        hp = max(0, hp - 12)
        _play_fx(damage_stream)
        _set_message(CONE_LINES.pick_random(), 2.4)
        if hp <= 0:
            _fail()

func _complete() -> void:
    mission_complete = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    mission_body.text = "ЖЁЛУДИ: 4 / 4\n\nОН СУЩЕСТВУЕТ.\n\nКаролина нашла легендарный жёлудь.\nДарина может делать поделку.\nБелки официально проиграли.\n\nP.S. Данил всё это время верил в тебя."
    retry_button.visible = false
    weapon.visible = false

func _fail() -> void:
    mission_failed = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ПРОВАЛЕНА"
    mission_body.text = "HP: 0\n\nБелки победили.\nЭто позор.\n\nНо Дарина всё ещё ждёт жёлуди."
    retry_button.visible = true
    weapon.visible = false

func _update_hud() -> void:
    count_label.text = "ЖЁЛУДИ  %d / 4" % collected
    hp_ammo_label.text = "HP %d     AMMO %d" % [hp, ammo]

func _set_message(text: String, duration: float) -> void:
    message_label.text = text
    message_time = duration

func _footstep() -> void:
    if muted:
        return
    fx.stream = foot1_stream if int(Time.get_ticks_msec() / 300) % 2 == 0 else foot2_stream
    fx.play()

func _play_fx(stream: AudioStream) -> void:
    if muted or stream == null:
        return
    fx.stream = stream
    fx.play()

func _toggle_music() -> void:
    muted = not muted
    mute_button.text = "×" if muted else "♪"
    if muted:
        music.stop()
    elif not music.playing:
        music.play()
    _set_message("Музыка выключена." if muted else "Музыка возвращена. Белки снова слышат угрозу.", 1.6)

func _face_world_sprites() -> void:
    for name in ["Tree01", "Tree02", "Tree03", "Tree04", "Tree05", "Tree06", "Tree07", "Tree08", "Tree09", "Acorn01", "Acorn02", "Acorn03", "Acorn04", "Squirrel01", "Squirrel02", "FakePineCone", "Moon", "Star01", "Star02", "Star03"]:
        var node := get_node_or_null(name) as MeshInstance3D
        if node != null and node.visible:
            var target := camera.global_position
            target.y = node.global_position.y
            node.look_at(target, Vector3.UP)

func _refresh_minimap() -> void:
    $HUD/Minimap.set_game_state(player.global_position, player.rotation.y, acorns, squirrels, stunned)

func _on_retry_pressed() -> void:
    get_tree().reload_current_scene()

func _on_menu_pressed() -> void:
    get_tree().change_scene_to_file("res://menu.tscn")
