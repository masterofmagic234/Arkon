extends Node3D

# ACORN HUNTER — Level 1 rebuilt as a real 3D scene in Godot 4.
# The original Java prototype's map, object placements, gameplay and audio are preserved,
# while projection/collision/occlusion are delegated to Godot's 3D renderer and physics.

const MAP_W := 20
const MAP_H := 14
const CELL := 1.0
const PLAYER_SPEED := 4.1
const LOOK_SENS := 0.0045
const ACORN_GOAL := 4

const MAP := [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,1,1,1,0,0,0,1,1,0,0,0,0,0,1],
    [1,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,1],
    [1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1],
    [1,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1],
    [1,0,1,1,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1],
    [1,0,0,0,1,1,1,0,1,0,1,1,1,0,0,0,0,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1],
    [1,0,0,1,1,1,0,0,1,1,1,0,0,0,0,0,0,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

const ACORN_POS := [Vector2(5.5,2.5), Vector2(10.5,2.5), Vector2(14.5,3.5), Vector2(13.5,7.5)]
const TREE_POS := [Vector2(5.5,2.5), Vector2(10.5,2.5), Vector2(14.5,3.5), Vector2(3.5,6.5), Vector2(8.5,6.5), Vector2(13.5,7.5), Vector2(17.5,8.5), Vector2(5.5,11.5), Vector2(12.5,11.5)]
const SQUIRREL_POS := [Vector2(9.2,5.2), Vector2(16.3,6.7)]

var player: CharacterBody3D
var camera: Camera3D
var world: Node3D
var objects: Node3D
var enemies: Array[Dictionary] = []
var acorns: Array[Node3D] = []
var fakes: Array[Node3D] = []
var path_cells: Dictionary = {}

var yaw := 0.0
var pitch := -0.035
var move_input := Vector2.ZERO
var hp := 100
var ammo := 38
var found := 0
var fire_cooldown := 0.0
var muzzle_time := 0.0
var footstep_time := 0.0
var toast_time := 0.0
var toast_text := ""
var dead := false

var hud_hp: Label
var hud_ammo: Label
var hud_acorns: Label
var hud_toast: Label
var minimap: MiniMap
var muzzle: MeshInstance3D
var music: AudioStreamPlayer
var foot1: AudioStreamPlayer
var foot2: AudioStreamPlayer
var squirrel_hit: AudioStreamPlayer
var foot_toggle := false

var tex_grass = preload("res://assets/grass_tile.png")
var tex_stone = preload("res://assets/stone_path_tile.png")
var tex_acorn = preload("res://assets/acorn.png")
var tex_tree = preload("res://assets/oak_tree.png")
var tex_squirrel = preload("res://assets/squirrel.png")
var tex_face = preload("res://assets/carolina_face.png")
var tex_walls = [
    preload("res://assets/hedge_wall_0.png"),
    preload("res://assets/hedge_wall_1.png"),
    preload("res://assets/hedge_wall_2.png"),
    preload("res://assets/hedge_wall_3.png")
]

func _ready() -> void:
    _build_environment()
    _build_level()
    _build_player()
    _build_hud()
    _build_audio()
    _show_toast("Парк открыт. Ищи дубы — жёлуди рядом.", 2.8)

func _process(delta: float) -> void:
    if dead:
        return
    _update_player(delta)
    _update_enemies(delta)
    _check_pickups()
    _update_weapon(delta)
    _update_hud()
    if toast_time > 0.0:
        toast_time -= delta
        if toast_time <= 0.0:
            hud_toast.text = ""

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        _look(event.relative)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        _shoot()
    elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _build_environment() -> void:
    world = Node3D.new()
    world.name = "World"
    add_child(world)
    objects = Node3D.new()
    objects.name = "Objects"
    world.add_child(objects)

    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color("07142d")
    sky_mat.sky_horizon_color = Color("243b57")
    sky_mat.ground_bottom_color = Color("08120d")
    sky_mat.ground_horizon_color = Color("183020")
    sky_mat.sun_angle_max = 8.0
    sky.material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.7
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env_node.environment = env
    world.add_child(env_node)

    var moon := MeshInstance3D.new()
    moon.name = "Moon"
    var sphere := SphereMesh.new()
    sphere.radius = 1.6
    sphere.height = 3.2
    moon.mesh = sphere
    var moon_mat := StandardMaterial3D.new()
    moon_mat.albedo_color = Color("d9e6ff")
    moon_mat.emission_enabled = true
    moon_mat.emission = Color("9fb9e8")
    moon_mat.emission_energy_multiplier = 1.4
    moon.material_override = moon_mat
    moon.position = Vector3(-12.0, 15.0, -18.0)
    world.add_child(moon)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48.0, -25.0, 0.0)
    sun.light_energy = 0.72
    sun.light_color = Color("b8c9ff")
    sun.shadow_enabled = true
    world.add_child(sun)

func _build_level() -> void:
    # Real floor geometry: one world-space tile per walkable cell.
    for y in range(MAP_H):
        for x in range(MAP_W):
            if MAP[y][x] == 0:
                var stone := path_cells.has(Vector2i(x,y))
                _make_floor_tile(x, y, stone)
            else:
                _make_wall(x, y)

    # Build the path after the map exists, using the exact original start-to-acorn routes.
    _rebuild_path_cells()
    for child in world.get_children():
        if child.name.begins_with("Floor_"):
            var parts := child.name.split("_")
            if parts.size() >= 3:
                var px := int(parts[1])
                var py := int(parts[2])
                var m := child as MeshInstance3D
                m.material_override = _floor_material(path_cells.has(Vector2i(px,py)))

    for p in TREE_POS:
        _add_tree(p)
    for p in ACORN_POS:
        _add_acorn(p)
    _add_fake(Vector2(3.84, 6.84))
    for p in SQUIRREL_POS:
        _add_squirrel(p)

func _rebuild_path_cells() -> void:
    path_cells.clear()
    var start := Vector2i(1,1)
    for target_world in ACORN_POS:
        var target := Vector2i(int(floor(target_world.x)), int(floor(target_world.y)))
        var q: Array[Vector2i] = [start]
        var prev := {}
        prev[start] = Vector2i(-999,-999)
        var found_target := false
        while not q.is_empty():
            var cur: Vector2i = q.pop_front()
            if cur == target:
                found_target = true
                break
            for d in [Vector2i(1,0),Vector2i(-1,0),Vector2i(0,1),Vector2i(0,-1)]:
                var n := cur + d
                if n.x < 0 or n.y < 0 or n.x >= MAP_W or n.y >= MAP_H:
                    continue
                if MAP[n.y][n.x] != 0 or prev.has(n):
                    continue
                prev[n] = cur
                q.append(n)
        if found_target:
            var c := target
            while c != Vector2i(-999,-999):
                path_cells[c] = true
                c = prev[c]
    var widened := path_cells.duplicate()
    for cell in path_cells.keys():
        for d in [Vector2i(1,0),Vector2i(-1,0),Vector2i(0,1),Vector2i(0,-1)]:
            var n: Vector2i = cell + d
            if n.x >= 0 and n.y >= 0 and n.x < MAP_W and n.y < MAP_H and MAP[n.y][n.x] == 0:
                widened[n] = true
    path_cells = widened

func _make_floor_tile(x: int, y: int, stone: bool) -> void:
    var m := MeshInstance3D.new()
    m.name = "Floor_%d_%d" % [x,y]
    var plane := PlaneMesh.new()
    plane.size = Vector2(1.02,1.02)
    plane.subdivide_width = 1
    plane.subdivide_depth = 1
    m.mesh = plane
    m.position = Vector3(x + 0.5, 0.0, y + 0.5)
    m.material_override = _floor_material(stone)
    world.add_child(m)

    var body := StaticBody3D.new()
    body.position = m.position + Vector3(0,-0.05,0)
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(1.02,0.1,1.02)
    shape.shape = box
    body.add_child(shape)
    world.add_child(body)

func _floor_material(stone: bool) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_texture = tex_stone if stone else tex_grass
    mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    mat.roughness = 1.0
    mat.uv1_scale = Vector3(1.0,1.0,1.0)
    return mat

func _make_wall(x: int, y: int) -> void:
    var m := MeshInstance3D.new()
    m.name = "Wall_%d_%d" % [x,y]
    var boxmesh := BoxMesh.new()
    boxmesh.size = Vector3(1.0, 2.4, 1.0)
    m.mesh = boxmesh
    m.position = Vector3(x + 0.5, 1.2, y + 0.5)
    var mat := StandardMaterial3D.new()
    mat.albedo_texture = tex_walls[(x * 31 + y * 17) % tex_walls.size()]
    mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    mat.roughness = 0.95
    m.material_override = mat
    world.add_child(m)

    var body := StaticBody3D.new()
    body.position = m.position
    var shape := CollisionShape3D.new()
    var col := BoxShape3D.new()
    col.size = Vector3(1.0, 2.4, 1.0)
    shape.shape = col
    body.add_child(shape)
    world.add_child(body)

func _add_tree(p: Vector2) -> void:
    var s := Sprite3D.new()
    s.name = "OakTree"
    s.texture = tex_tree
    s.pixel_size = 0.010
    s.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    s.no_depth_test = false
    s.position = Vector3(p.x, 1.4, p.y)
    s.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
    s.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    objects.add_child(s)
    var body := StaticBody3D.new()
    body.position = Vector3(p.x, 0.7, p.y)
    var shape := CollisionShape3D.new()
    var cyl := CylinderShape3D.new()
    cyl.radius = 0.27
    cyl.height = 1.4
    shape.shape = cyl
    body.add_child(shape)
    objects.add_child(body)

func _add_acorn(p: Vector2) -> void:
    var s := Sprite3D.new()
    s.name = "Acorn"
    s.texture = tex_acorn
    s.pixel_size = 0.0046
    s.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    s.position = Vector3(p.x + 0.48 * cos(0.22), 0.32, p.y + 0.48 * sin(0.22))
    s.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
    s.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    objects.add_child(s)
    acorns.append(s)

func _add_fake(p: Vector2) -> void:
    var mesh := MeshInstance3D.new()
    mesh.name = "FakePineCone"
    var cone := CylinderMesh.new()
    cone.top_radius = 0.03
    cone.bottom_radius = 0.16
    cone.height = 0.38
    cone.radial_segments = 8
    cone.rings = 2
    mesh.mesh = cone
    mesh.position = Vector3(p.x, 0.19, p.y)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color("654126")
    mat.roughness = 1.0
    mesh.material_override = mat
    objects.add_child(mesh)
    fakes.append(mesh)

func _add_squirrel(p: Vector2) -> void:
    var s := Sprite3D.new()
    s.name = "Squirrel"
    s.texture = tex_squirrel
    s.pixel_size = 0.0064
    s.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    s.position = Vector3(p.x, 0.62, p.y)
    s.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
    s.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    objects.add_child(s)
    enemies.append({"node":s,"hp":2,"alive":true,"velocity":Vector3.ZERO,"dead_time":0.0})

func _build_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(1.5, 0.92, 1.5)
    add_child(player)

    var col := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.23
    capsule.height = 1.72
    col.shape = capsule
    player.add_child(col)

    camera = Camera3D.new()
    camera.position = Vector3(0, 0.57, 0)
    camera.fov = 68.0
    camera.near = 0.03
    camera.far = 80.0
    camera.current = true
    player.add_child(camera)
    player.rotation.y = yaw
    camera.rotation.x = pitch

    var weapon := MeshInstance3D.new()
    weapon.name = "Weapon"
    var gun := BoxMesh.new()
    gun.size = Vector3(0.42, 0.24, 0.95)
    weapon.mesh = gun
    weapon.position = Vector3(0.0, -0.40, -0.78)
    var gunmat := StandardMaterial3D.new()
    gunmat.albedo_color = Color("1b181b")
    gunmat.roughness = 0.55
    weapon.material_override = gunmat
    camera.add_child(weapon)

    muzzle = MeshInstance3D.new()
    var flash := SphereMesh.new()
    flash.radius = 0.11
    flash.height = 0.22
    muzzle.mesh = flash
    muzzle.position = Vector3(0,-0.40,-1.24)
    var fm := StandardMaterial3D.new()
    fm.albedo_color = Color("ffd86b")
    fm.emission_enabled = true
    fm.emission = Color("ff9f27")
    fm.emission_energy_multiplier = 6.0
    muzzle.material_override = fm
    muzzle.visible = false
    camera.add_child(muzzle)

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    layer.name = "HUD"
    add_child(layer)

    var top := ColorRect.new()
    top.color = Color(0.015,0.055,0.05,0.93)
    top.position = Vector2(0,0)
    top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    top.custom_minimum_size = Vector2(0,62)
    layer.add_child(top)

    var title := Label.new()
    title.text = "ОПЕРАЦИЯ «ЖЁЛУДЬ»"
    title.position = Vector2(18,8)
    title.add_theme_font_size_override("font_size",22)
    title.add_theme_color_override("font_color",Color("f2f1e9"))
    top.add_child(title)

    hud_acorns = Label.new()
    hud_acorns.position = Vector2(18,36)
    hud_acorns.add_theme_font_size_override("font_size",15)
    hud_acorns.add_theme_color_override("font_color",Color("d9d39c"))
    top.add_child(hud_acorns)

    var face := TextureRect.new()
    face.texture = tex_face
    face.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    face.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    face.position = Vector2(715,4)
    face.size = Vector2(54,54)
    top.add_child(face)

    var carolina := Label.new()
    carolina.text = "CAROLINA\nОХОТНИК"
    carolina.position = Vector2(775,8)
    carolina.add_theme_font_size_override("font_size",13)
    carolina.add_theme_color_override("font_color",Color("e9e5dd"))
    top.add_child(carolina)

    hud_hp = Label.new()
    hud_hp.position = Vector2(936,8)
    hud_hp.add_theme_font_size_override("font_size",17)
    hud_hp.add_theme_color_override("font_color",Color("f1f1ed"))
    top.add_child(hud_hp)

    hud_ammo = Label.new()
    hud_ammo.position = Vector2(936,34)
    hud_ammo.add_theme_font_size_override("font_size",15)
    hud_ammo.add_theme_color_override("font_color",Color("c8c7bd"))
    top.add_child(hud_ammo)

    hud_toast = Label.new()
    hud_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hud_toast.position = Vector2(260,80)
    hud_toast.size = Vector2(760,50)
    hud_toast.add_theme_font_size_override("font_size",20)
    hud_toast.add_theme_color_override("font_color",Color("fff2bd"))
    layer.add_child(hud_toast)

    minimap = MiniMap.new()
    minimap.main = self
    minimap.position = Vector2(1085,70)
    minimap.size = Vector2(170,120)
    layer.add_child(minimap)

    var controls := preload("res://scripts/mobile_controls.gd").new()
    controls.name = "MobileControls"
    controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(controls)
    controls.move_changed.connect(_on_move)
    controls.look_changed.connect(_on_look)
    controls.fire_pressed.connect(_shoot)

func _build_audio() -> void:
    music = AudioStreamPlayer.new()
    music.stream = preload("res://assets/acorn_music.mp3")
    music.autoplay = true
    music.volume_db = -9.0
    add_child(music)
    foot1 = _make_audio(preload("res://assets/footstep1.wav"), -10.0)
    foot2 = _make_audio(preload("res://assets/footstep2.wav"), -10.0)
    squirrel_hit = _make_audio(preload("res://assets/squirrel_hit.wav"), -5.0)

func _make_audio(stream: AudioStream, volume: float) -> AudioStreamPlayer:
    var a := AudioStreamPlayer.new()
    a.stream = stream
    a.volume_db = volume
    add_child(a)
    return a

func _on_move(v: Vector2) -> void:
    move_input = v

func _on_look(v: Vector2) -> void:
    _look(v)

func _look(d: Vector2) -> void:
    yaw -= d.x * LOOK_SENS
    pitch = clamp(pitch - d.y * LOOK_SENS, -1.20, 1.15)
    player.rotation.y = yaw
    camera.rotation.x = pitch

func _update_player(delta: float) -> void:
    var keyboard := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var input_vec := move_input
    if keyboard.length() > 0.05:
        input_vec = keyboard
    var forward := -player.global_transform.basis.z
    var right := player.global_transform.basis.x
    var dir := (right * input_vec.x + forward * input_vec.y)
    dir.y = 0.0
    if dir.length() > 1.0:
        dir = dir.normalized()
    player.velocity.x = dir.x * PLAYER_SPEED
    player.velocity.z = dir.z * PLAYER_SPEED
    player.velocity.y = 0.0
    player.move_and_slide()
    player.global_position.y = 0.92
    if dir.length() > 0.15:
        footstep_time -= delta
        if footstep_time <= 0.0:
            (foot1 if not foot_toggle else foot2).play()
            foot_toggle = not foot_toggle
            footstep_time = 0.28

func _update_enemies(delta: float) -> void:
    for e in enemies:
        var s: Sprite3D = e.node
        if not e.alive:
            continue
        var to_player := player.global_position - s.global_position
        to_player.y = 0.0
        var d := to_player.length()
        if d < 6.0 and d > 0.75:
            var step := to_player.normalized() * 1.0 * delta
            var next := s.global_position + step
            if _is_walkable(next.x, next.z):
                s.global_position = next
        if d < 0.68:
            hp = max(0, hp - 12)
            if hp == 0:
                _defeat()

func _check_pickups() -> void:
    for a in acorns.duplicate():
        if not is_instance_valid(a):
            acorns.erase(a)
            continue
        if player.global_position.distance_to(a.global_position) < 0.55:
            acorns.erase(a)
            a.queue_free()
            found += 1
            if found == 1:
                _show_toast("Первый жёлудь. История движется.",1.3)
            elif found == 2:
                _show_toast("Данил сообщает: прогресс исторический.",1.3)
            else:
                _show_toast("ЖЁЛУДЬ! Дарина одобряет.",1.3)
            if found >= ACORN_GOAL:
                _complete_level()
    for f in fakes.duplicate():
        if not is_instance_valid(f):
            fakes.erase(f)
            continue
        if player.global_position.distance_to(f.global_position) < 0.55:
            fakes.erase(f)
            f.queue_free()
            hp = max(0, hp - 12)
            _show_toast("Это не жёлудь. Это ШИШКА.",1.1)
            if hp == 0:
                _defeat()

func _shoot() -> void:
    if dead or fire_cooldown > 0.0:
        return
    if ammo <= 0:
        _show_toast("Пусто. Даже белки в шоке.",0.8)
        return
    ammo -= 1
    fire_cooldown = 0.16
    muzzle_time = 0.09
    muzzle.visible = true
    var origin := camera.global_position
    var dir := -camera.global_transform.basis.z
    var best = null
    var best_dist := 99.0
    for e in enemies:
        if not e.alive:
            continue
        var s: Sprite3D = e.node
        var target := s.global_position + Vector3(0,0.25,0)
        var to := target - origin
        var d := to.length()
        if d > 8.0:
            continue
        var alignment := dir.dot(to.normalized())
        if alignment < 0.986:
            continue
        var query := PhysicsRayQueryParameters3D.create(origin, target)
        query.exclude = [player.get_rid()]
        var hit := get_world_3d().direct_space_state.intersect_ray(query)
        if hit.is_empty() and d < best_dist:
            best = e
            best_dist = d
    if best != null:
        best.hp -= 1
        if squirrel_hit:
            squirrel_hit.play()
        if best.hp <= 0:
            best.alive = false
            var s: Sprite3D = best.node
            s.modulate = Color(0.55,0.55,0.55,1)
            s.scale = Vector3(1.0,0.42,1.0)
            s.position.y = 0.22
            var stars := Label3D.new()
            stars.text = "★  ★  ★"
            stars.font_size = 32
            stars.modulate = Color("f7d76b")
            stars.position = Vector3(0,0.45,0)
            s.add_child(stars)
            _show_toast("БЕЛКА ПОВЕРЖЕНА.",0.9)
        else:
            _show_toast("ПОПАЛА.",0.5)

func _update_weapon(delta: float) -> void:
    fire_cooldown = max(0.0, fire_cooldown - delta)
    if muzzle_time > 0.0:
        muzzle_time -= delta
        if muzzle_time <= 0.0:
            muzzle.visible = false

func _is_walkable(x: float, z: float) -> bool:
    var ix := int(floor(x))
    var iz := int(floor(z))
    if ix < 0 or iz < 0 or ix >= MAP_W or iz >= MAP_H:
        return false
    return MAP[iz][ix] == 0

func _complete_level() -> void:
    _show_toast("УРОВЕНЬ 1 ПРОЙДЕН — ВСЕ ЖЁЛУДИ НАЙДЕНЫ.",3.0)
    # For the architecture test, we stop here rather than silently switching engines.
    # Level 2 will be a separate Godot scene once this foundation is validated.

func _defeat() -> void:
    dead = true
    move_input = Vector2.ZERO
    _show_toast("Белки победили. Это позор.",3.0)

func _show_toast(text: String, duration: float) -> void:
    toast_text = text
    toast_time = duration
    if is_instance_valid(hud_toast):
        hud_toast.text = text

func _update_hud() -> void:
    if not is_instance_valid(hud_hp):
        return
    hud_hp.text = "HP %d" % hp
    hud_ammo.text = "AMMO %d" % ammo
    hud_acorns.text = "УР. 1    ЖЁЛУДИ %d/%d" % [found,ACORN_GOAL]
    if is_instance_valid(minimap):
        minimap.queue_redraw()

class MiniMap extends Control:
    var main: Node
    func _draw() -> void:
        if main == null:
            return
        draw_rect(Rect2(Vector2.ZERO,size),Color(0.04,0.09,0.07,0.88),true)
        var cell := min(size.x / 20.0, size.y / 14.0)
        var ox := (size.x - cell*20.0)/2.0
        var oy := (size.y - cell*14.0)/2.0
        for y in range(14):
            for x in range(20):
                if main.MAP[y][x] == 1:
                    draw_rect(Rect2(ox+x*cell,oy+y*cell,cell+1,cell+1),Color(0.10,0.22,0.16,1),true)
                elif main.path_cells.has(Vector2i(x,y)):
                    draw_rect(Rect2(ox+x*cell,oy+y*cell,cell+1,cell+1),Color(0.30,0.32,0.28,1),true)
        for a in main.acorns:
            if is_instance_valid(a):
                var p: Vector3 = a.global_position
                draw_circle(Vector2(ox+p.x*cell,oy+p.z*cell),2.8,Color("f2d36b"))
        var pp: Vector3 = main.player.global_position
        draw_circle(Vector2(ox+pp.x*cell,oy+pp.z*cell),3.6,Color("f5f2eb"))
        draw_rect(Rect2(Vector2.ZERO,size),Color(0.45,0.60,0.47,0.75),false,2.0)
