extends Control

var game_position := Vector3.ZERO
var game_yaw := 0.0
var acorn_names: Array = []
var squirrel_names: Array = []
var stunned: Dictionary = {}

const MAP_W := 20
const MAP_H := 14
const MAP_ROWS := [
    "11111111111111111111",
    "10000000000000000001",
    "10000011100001100001",
    "10000010100001000001",
    "10001010101010111001",
    "10001000001000100001",
    "10111000001000100001",
    "10000000100000100101",
    "10001110101110000101",
    "10000000000000000101",
    "10011101110000000101",
    "10000000000000000001",
    "10000000000000000001",
    "11111111111111111111"
]

func set_game_state(pos: Vector3, yaw: float, acorns: Array, squirrels: Array, stunned_state: Dictionary) -> void:
    game_position = pos
    game_yaw = yaw
    acorn_names = acorns.duplicate()
    squirrel_names = squirrels.duplicate()
    stunned = stunned_state.duplicate()
    queue_redraw()

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
    var game := get_tree().current_scene
    if game == null:
        return

    var map_left := 8.0
    var map_top := 27.0
    var cell := min((size.x - 16.0) / float(MAP_W), (size.y - 31.0) / float(MAP_H))
    var map_size := Vector2(cell * MAP_W, cell * MAP_H)

    draw_rect(Rect2(map_left - 3.0, map_top - 3.0, map_size.x + 6.0, map_size.y + 6.0), Color(0.02, 0.04, 0.035, 0.72), true)
    for yy in range(MAP_H):
        for xx in range(MAP_W):
            if MAP_ROWS[yy].substr(xx, 1) == "1":
                draw_rect(Rect2(Vector2(map_left + xx * cell, map_top + yy * cell), Vector2(cell + 0.4, cell + 0.4)), Color(0.18, 0.31, 0.24, 0.98), true)

    for i in range(1, 10):
        var tree := game.get_node_or_null("Tree%02d" % i) as Node3D
        if tree != null:
            _world_dot(tree.global_position, map_left, map_top, cell, Color(0.22, 0.58, 0.28, 0.95), 1.8)

    for name in acorn_names:
        var node := game.get_node_or_null(name) as Node3D
        if node != null:
            _world_dot(node.global_position, map_left, map_top, cell, Color(1.0, 0.78, 0.32, 1.0), 2.8)

    for name in squirrel_names:
        var node := game.get_node_or_null(name) as Node3D
        if node != null:
            _world_dot(node.global_position, map_left, map_top, cell, Color(0.85, 0.45, 0.25, 1.0), 2.4)

    var player_map := _world_to_map(game_position, map_left, map_top, cell)
    var facing := Vector2(-sin(game_yaw), -cos(game_yaw)).normalized() * 8.0
    draw_line(player_map, player_map + facing, Color(1.0, 0.82, 0.55, 0.95), 1.8)
    draw_circle(player_map, 3.2, Color(0.95, 0.98, 0.95, 1.0))

func _world_to_map(pos: Vector3, left: float, top: float, cell: float) -> Vector2:
    return Vector2(left + (pos.x + 10.0) * cell, top + (pos.z + 7.0) * cell)

func _world_dot(pos: Vector3, left: float, top: float, cell: float, color: Color, radius: float) -> void:
    var p := _world_to_map(pos, left, top, cell)
    if Rect2(left, top, cell * MAP_W, cell * MAP_H).has_point(p):
        draw_circle(p, radius, color)
