extends Node3D

# ACORN HUNTER — LEVEL 1
# Rebuilt from the last proven CLEAN/V6 control foundation.
# World sprites are deliberately MeshInstance3D + QuadMesh, not Sprite3D.
# UI owns touch input: joystick.gui_input + Fire.pressed.

const WALK_SPEED := 3.4
const TURN_SPEED := 2.15
const JOYSTICK_RADIUS := 58.0
const ACORN_PICKUP_RADIUS := 1.25
const FIRE_RANGE := 18.0
const SQUIRREL_LAYER := 2
const WORLD_LAYER := 1
const MAX_AMMO := 38
const MAX_HP := 100

var move_axis := Vector2.ZERO
var joystick_touch_id := -1
var collected := 0
var ammo := MAX_AMMO
var hp := MAX_HP
var message_time := 0.0
var fire_cooldown := 0.0
var damage_cooldown := 0.0
var recoil_time := 0.0
var foot_timer := 0.0
var fake_cone_found := false
var mission_complete := false
var mission_failed := false
var muted := false
var stunned: Dictionary = {}
var acorns := ["Acorn01", "Acorn02", "Acorn03", "Acorn04"]
var squirrels := ["Squirrel01", "Squirrel02"]
var squirrel_home := {
    "Squirrel01": Vector2(-1.5, 1.2),
    "Squirrel02": Vector2(4.0, -1.0)
}
var squirrel_phase := {"Squirrel01": 0.0, "Squirrel02": 1.7}

const MAP_W := 20
const MAP_H := 14
const CANONICAL_MAP := [
    "11111111111111111111",
    "10000000000000000001",
    "10000011100001100001",
    "10000010100001000001",
    "10001010101010111001",
    "10001000001000100001",
    "10111000001000100001",
    "10000000100000100101",
    "10001110101110000101",
    "10000000000000000101",
    "10011101110000000101",
    "10000000000000000001",
    "10000000000000000001",
    "11111111111111111111"
]

const CANONICAL_TREES := [
    Vector2(5.5, 2.5), Vector2(10.5, 2.5), Vector2(14.5, 3.5),
    Vector2(3.5, 6.5), Vector2(8.5, 6.5), Vector2(13.5, 7.5),
    Vector2(17.5, 8.5), Vector2(5.5, 11.5), Vector2(12.5, 11.5)
]
const CANONICAL_ACORN_BASES := [
    Vector3(5.5, 2.5, 0.22), Vector3(10.5, 2.5, -0.28),
    Vector3(14.5, 3.5, 0.20), Vector3(13.5, 7.5, -0.22)
]
const CANONICAL_SQUIRRELS := [Vector2(9.2, 5.2), Vector2(16.3, 6.7)]
const CANONICAL_FAKE := Vector2(3.5, 6.5)
var canonical_map_ready := false

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var joystick: Panel = $HUD/Joystick
@onready var knob: Panel = $HUD/Joystick/Knob
@onready var fire_button: Button = $HUD/Fire
@onready var mute_button: Button = $HUD/Mute
@onready var count_label: Label = $HUD/Count
@onready var hp_ammo_label: Label = $HUD/HPAmmo
@onready var message_label: Label = $HUD/Message
@onready var mission_panel: Panel = $HUD/Mission
@onready var mission_title: Label = $HUD/Mission/Title
@onready var mission_body: Label = $HUD/Mission/Body
@onready var weapon: TextureRect = $HUD/Weapon
@onready var muzzle: ColorRect = $HUD/MuzzleFlash
@onready var hit_marker: Label = $HUD/HitMarker
@onready var carolina: TextureRect = $HUD/Carolina
@onready var music: AudioStreamPlayer = $Music
@onready var fx: AudioStreamPlayer = $FX

var foot1_stream = preload("res://assets/footstep1.wav")
var foot2_stream = preload("res://assets/footstep2.wav")
var shoot_stream = preload("res://assets/shoot.wav")
var squirrel_hit_stream = preload("res://assets/squirrel_hit.wav")
var pickup_stream = preload("res://assets/pickup.wav")
var damage_stream = preload("res://assets/damage.wav")

const ACORN_LINES := [
    "ЖЁЛУДЬ ДОБЫТ. Дарина, ставь чайник.",
    "Один есть. Белки нервничают.",
    "Исторический жёлудь №%d.",
    "Данил сообщает: прогресс подозрительно хороший.",
    "В карман! И никому не отдавать.",
    "Найден. Официально настоящий.",
    "Ещё один — и можно открывать музей.",
    "Жёлудь найден. Серьёзная археология."
]
const CONE_LINES := [
    "ЭТО ШИШКА. Лес тебя переиграл.",
    "Поздравляю: ты нашла не то.",
    "Дарина просила жёлуди, а не ботанику.",
    "Шишка нанесла 12 урона самолюбию.",
    "Неправильный орех. Очень неправильный.",
    "Каролина, это буквально НЕ ЖЁЛУДЬ.",
    "Лес говорит: внимательнее, пожалуйста."
]
const HIT_LINES := [
    "ПОПАЛА. Белка задумалась о жизни.",
    "Белка получила аргумент.",
    "Точно в пушистую проблему.",
    "Попадание! Белка пересматривает карьеру.",
    "Минус одна попытка украсть жёлудь.",
    "Белка: это было неожиданно.",
    "Тихо. Я всё видела. Отличный выстрел."
]
const STUN_LINES := [
    "Белка контужена. Звёздочки прилагаются.",
    "Белка прилегла подумать.",
    "Пушистый отпуск объявлен досрочно.",
    "Белка временно недееспособна. Достойно.",
    "Она не мёртвая. Она просто очень впечатлена.",
    "Звёздочки — официальный эффект поражения.",
    "Белка выбыла. Жёлуди в безопасности."
]
const DAMAGE_LINES := [
    "АЙ! Белка кусается.",
    "Урон. Пушистый террор продолжается.",
    "Белка сказала: не подходи.",
    "Это было больно. Очень по-беличьи."
]

func _ready() -> void:
    _build_canonical_map()
    _place_canonical_objects()
    camera.rotation = Vector3.ZERO
    camera.fov = 72.0
    camera.near = 0.05
    camera.far = 40.0
    carolina.texture = load("res://assets/carolina_face.png")
    mission_panel.visible = false
    muzzle.visible = false
    hit_marker.visible = false
    knob.position = joystick.size * 0.5 - knob.size * 0.5

    # Touch is handled by the actual UI controls, not by a global input relay.
    joystick.gui_input.connect(_on_joystick_gui_input)
    fire_button.pressed.connect(_on_fire_pressed)
    mute_button.pressed.connect(_toggle_music)
    $HUD/Mission/Menu.pressed.connect(_on_menu_pressed)

    music.volume_db = -9.0
    music.play()
    _update_hud()
    _set_message("Парк открыт. Дубы не прячутся — жёлуди тоже.", 4.0)
    _refresh_minimap()
    _face_world_sprites()

func _physics_process(delta: float) -> void:
    if mission_complete or mission_failed:
        player.velocity = Vector3.ZERO
        return

    var forward := -move_axis.y
    player.velocity = -player.global_transform.basis.z * (forward * WALK_SPEED)
    player.velocity.y = 0.0
    player.move_and_slide()

    if abs(move_axis.x) > 0.04:
        player.rotate_y(-move_axis.x * TURN_SPEED * delta)

    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    damage_cooldown = maxf(0.0, damage_cooldown - delta)
    recoil_time = maxf(0.0, recoil_time - delta)
    message_time = maxf(0.0, message_time - delta)

    if message_time <= 0.0:
        message_label.text = ""
    if recoil_time <= 0.0:
        weapon.position.y = 455.0
    if muzzle.visible:
        muzzle.modulate.a = clampf(muzzle.modulate.a - delta * 7.0, 0.0, 1.0)
        if muzzle.modulate.a <= 0.0:
            muzzle.visible = false

    if abs(forward) > 0.05:
        foot_timer -= delta
        if foot_timer <= 0.0:
            _footstep()
            foot_timer = 0.30
    else:
        foot_timer = 0.0

    _update_squirrels(delta)
    _collect_acorns()
    _check_fake_cone()
    _face_world_sprites()
    _update_hud()
    _refresh_minimap()

func _on_joystick_gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            joystick_touch_id = event.index
            _update_joystick(event.position)
            joystick.accept_event()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _update_joystick(event.position)
        joystick.accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            joystick_touch_id = -2
            _update_joystick(event.position)
            joystick.accept_event()
        elif joystick_touch_id == -2:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventMouseMotion and joystick_touch_id == -2:
        _update_joystick(event.position)
        joystick.accept_event()

func _update_joystick(position: Vector2) -> void:
    var center := joystick.size * 0.5
    var delta := position - center
    if delta.length() > JOYSTICK_RADIUS:
        delta = delta.normalized() * JOYSTICK_RADIUS
    move_axis = Vector2(delta.x / JOYSTICK_RADIUS, delta.y / JOYSTICK_RADIUS)
    knob.position = center - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func _on_fire_pressed() -> void:
    if mission_complete or mission_failed or fire_cooldown > 0.0:
        return
    if ammo <= 0:
        _set_message("Пусто. Даже белки в шоке.", 1.2)
        return

    ammo -= 1
    fire_cooldown = 0.18
    recoil_time = 0.10
    weapon.position.y = 470.0
    muzzle.visible = true
    muzzle.modulate.a = 1.0
    _play_fx(shoot_stream)

    var query := PhysicsRayQueryParameters3D.create(
        camera.global_position,
        camera.global_position + (-camera.global_transform.basis.z * FIRE_RANGE),
        SQUIRREL_LAYER | WORLD_LAYER
    )
    query.collide_with_areas = true
    query.collide_with_bodies = true
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        _miss()
        return

    var squirrel := _find_squirrel_from_collider(hit.get("collider"))
    if squirrel == "" or stunned.has(squirrel):
        _miss()
        return

    stunned[squirrel] = true
    var target := get_node_or_null(squirrel) as MeshInstance3D
    if target != null:
        target.modulate = Color(0.55, 0.72, 1.0, 1.0)
        target.rotation.z = deg_to_rad(-8.0)
    hit_marker.visible = true
    hit_marker.text = "×"
    _play_fx(squirrel_hit_stream)
    _set_message("%s\n%s" % [HIT_LINES.pick_random(), STUN_LINES.pick_random()], 2.0)
    await get_tree().create_timer(0.35).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _find_squirrel_from_collider(collider: Object) -> String:
    var node := collider as Node
    while node != null:
        if squirrels.has(node.name):
            return node.name
        node = node.get_parent()
    return ""

func _miss() -> void:
    hit_marker.visible = true
    hit_marker.text = "•"
    _set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await get_tree().create_timer(0.22).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _update_squirrels(delta: float) -> void:
    var player_pos := Vector2(player.global_position.x, player.global_position.z)
    for name in squirrels:
        if stunned.has(name):
            continue
        var node := get_node_or_null(name) as MeshInstance3D
        if node == null:
            continue
        var home: Vector2 = squirrel_home[name]
        var dist := home.distance_to(player_pos)
        if dist < 6.0 and dist > 1.8:
            var away := (home - player_pos).normalized()
            var proposed := home + away * delta * 0.45
            if not _is_wall(proposed.x, proposed.y):
                squirrel_home[name] = proposed
                node.position.x = proposed.x
                node.position.z = proposed.y
        node.rotation.z = sin(Time.get_ticks_msec() * 0.003 + float(squirrel_phase[name])) * 0.03
        if dist < 1.0 and damage_cooldown <= 0.0:
            damage_cooldown = 0.8
            hp = max(0, hp - 12)
            _play_fx(damage_stream)
            _set_message(DAMAGE_LINES.pick_random(), 1.2)
            if hp <= 0:
                _fail()

func _is_wall(x: float, z: float) -> bool:
    var cell_x := int(floor(x + 10.0))
    var cell_z := int(floor(z + 7.0))
    if cell_x < 0 or cell_x >= MAP_W or cell_z < 0 or cell_z >= MAP_H:
        return true
    return CANONICAL_MAP[cell_z].substr(cell_x, 1) == "1"

func _build_canonical_map() -> void:
    if canonical_map_ready:
        return
    canonical_map_ready = true
    # V11 had four perimeter bodies. They are removed from the scene in V18;
    # create exactly one body per canonical wall cell instead.
    var mesh := BoxMesh.new()
    mesh.size = Vector3(1.0, 2.0, 1.0)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.16, 0.27, 0.20, 1.0)
    mat.albedo_texture = load("res://assets/hedge_wall_0.png")
    mat.roughness = 1.0
    mesh.material = mat
    var shape := BoxShape3D.new()
    shape.size = Vector3(1.0, 2.0, 1.0)
    for row in range(MAP_H):
        for col in range(MAP_W):
            if CANONICAL_MAP[row].substr(col, 1) != "1":
                continue
            var body := StaticBody3D.new()
            body.name = "MapWall_%03d" % (row * MAP_W + col)
            body.position = Vector3(col - 9.5, 1.0, row - 6.5)
            body.collision_layer = WORLD_LAYER
            body.collision_mask = 0
            var visual := MeshInstance3D.new()
            visual.name = "Mesh"
            visual.mesh = mesh
            body.add_child(visual)
            var collision := CollisionShape3D.new()
            collision.name = "Collision"
            collision.shape = shape
            body.add_child(collision)
            add_child(body)

func _old_to_world(x: float, z: float) -> Vector3:
    return Vector3(x - 10.0, 0.0, z - 7.0)

func _walkable_point_near(target: Vector2, radius: float, min_player_dist: float = 0.0) -> Vector2:
    var best := Vector2(1.5, -5.5)
    var best_d := INF
    for row in range(1, MAP_H - 1):
        for col in range(1, MAP_W - 1):
            if CANONICAL_MAP[row].substr(col, 1) != "0":
                continue
            var p := Vector2(col - 9.5, row - 6.5)
            if not _wall_safe(p.x, p.y, radius):
                continue
            if min_player_dist > 0.0 and p.distance_to(Vector2(player.global_position.x, player.global_position.z)) < min_player_dist:
                continue
            var d := p.distance_to(target)
            if d < best_d:
                best_d = d
                best = p
    return best

func _wall_safe(x: float, z: float, r: float) -> bool:
    return not _is_wall(x-r, z-r) and not _is_wall(x+r, z-r) and not _is_wall(x-r, z+r) and not _is_wall(x+r, z+r)

func _place_canonical_objects() -> void:
    # The old build's coordinates are authoritative; convert them into the
    # centered V11 coordinate system and repair only points that touch hedges.
    for i in range(CANONICAL_TREES.size()):
        var tree := get_node_or_null("Tree%02d" % (i + 1)) as MeshInstance3D
        if tree == null:
            continue
        var target := _old_to_world(CANONICAL_TREES[i].x, CANONICAL_TREES[i].y)
        var safe := _walkable_point_near(Vector2(target.x, target.z), 0.24, 0.7)
        tree.position = Vector3(safe.x, 1.55, safe.y)
    for i in range(CANONICAL_ACORN_BASES.size()):
        var acorn := get_node_or_null("Acorn%02d" % (i + 1)) as MeshInstance3D
        if acorn == null:
            continue
        var base := CANONICAL_ACORN_BASES[i]
        var target := _old_to_world(base.x + cos(base.z) * 0.48, base.y + sin(base.z) * 0.48)
        var safe := _walkable_point_near(Vector2(target.x, target.z), 0.08, 0.8)
        # Prefer a visible point just outside the corresponding oak.
        # If the original offset points into a hedge, rotate around the oak until
        # we find the nearest genuinely walkable position.
        var tree := get_node_or_null("Tree%02d" % (i + 1)) as Node3D
        if tree != null:
            var around := Vector2(tree.global_position.x, tree.global_position.z)
            var desired := Vector2(target.x, target.z) - around
            var base_angle := atan2(desired.y, desired.x)
            var found_visible := false
            var best_candidate := safe
            var best_candidate_d := INF
            for k in range(24):
                var angle := base_angle + float(k) * TAU / 24.0
                var candidate := around + Vector2(cos(angle), sin(angle)) * 0.62
                if not _wall_safe(candidate.x, candidate.y, 0.08):
                    continue
                if candidate.distance_to(around) < 0.34:
                    continue
                var candidate_d := candidate.distance_to(Vector2(target.x, target.z))
                if candidate_d < best_candidate_d:
                    best_candidate_d = candidate_d
                    best_candidate = candidate
                    found_visible = true
            if found_visible:
                safe = best_candidate
        acorn.position = Vector3(safe.x, 0.55, safe.y)
    for i in range(CANONICAL_SQUIRRELS.size()):
        var squirrel := get_node_or_null("Squirrel%02d" % (i + 1)) as MeshInstance3D
        if squirrel == null:
            continue
        var target := _old_to_world(CANONICAL_SQUIRRELS[i].x, CANONICAL_SQUIRRELS[i].y)
        var safe := _walkable_point_near(Vector2(target.x, target.z), 0.14, 1.4)
        squirrel.position = Vector3(safe.x, 0.95, safe.y)
        squirrel_home["Squirrel%02d" % (i + 1)] = safe
    var cone := get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null:
        var target := _old_to_world(CANONICAL_FAKE.x + 0.34, CANONICAL_FAKE.y + 0.34)
        var safe := _walkable_point_near(Vector2(target.x, target.z), 0.08, 0.8)
        cone.position = Vector3(safe.x, 0.45, safe.y)

func _collect_acorns() -> void:
    for name in acorns.duplicate():
        var node := get_node_or_null(name) as MeshInstance3D
        if node != null and player.global_position.distance_to(node.global_position) <= ACORN_PICKUP_RADIUS:
            node.visible = false
            acorns.erase(name)
            collected += 1
            if pickup_stream != null:
                _play_fx(pickup_stream)
            _set_message(ACORN_LINES.pick_random() + "\nЖёлуди: %d / 4" % collected, 1.8)
            if collected == 4:
                _complete()

func _check_fake_cone() -> void:
    if fake_cone_found:
        return
    var cone := get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null and player.global_position.distance_to(cone.global_position) <= 1.2:
        fake_cone_found = true
        hp = max(0, hp - 12)
        if damage_stream != null:
            _play_fx(damage_stream)
        _set_message(CONE_LINES.pick_random(), 2.4)
        if hp <= 0:
            _fail()

func _complete() -> void:
    mission_complete = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    mission_body.text = "ЖЁЛУДИ: 4 / 4\n\nОН СУЩЕСТВУЕТ.\n\nКаролина нашла легендарный жёлудь.\nДарина может делать поделку.\nБелки официально проиграли.\n\nP.S. Данил всё это время верил в тебя."
    weapon.visible = false

func _fail() -> void:
    mission_failed = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ПРОВАЛЕНА"
    mission_body.text = "HP: 0\n\nБелки победили.\nЭто позор.\n\nНо Дарина всё ещё ждёт жёлуди."
    weapon.visible = false

func _update_hud() -> void:
    count_label.text = "ЖЁЛУДИ  %d / 4" % collected
    hp_ammo_label.text = "HP %d     AMMO %d" % [hp, ammo]

func _set_message(text: String, duration: float) -> void:
    message_label.text = text
    message_time = duration

func _footstep() -> void:
    if muted:
        return
    fx.stream = foot1_stream if int(Time.get_ticks_msec() / 300) % 2 == 0 else foot2_stream
    fx.play()

func _play_fx(stream: AudioStream) -> void:
    if muted or stream == null:
        return
    fx.stream = stream
    fx.play()

func _toggle_music() -> void:
    muted = not muted
    mute_button.text = "×" if muted else "♪"
    if muted:
        music.stop()
    elif not music.playing:
        music.play()
    _set_message("Музыка выключена." if muted else "Музыка возвращена. Белки снова слышат угрозу.", 1.6)

func _face_world_sprites() -> void:
    for name in ["Tree01", "Tree02", "Tree03", "Tree04", "Tree05", "Tree06", "Acorn01", "Acorn02", "Acorn03", "Acorn04", "Squirrel01", "Squirrel02", "FakePineCone", "Moon", "Star01", "Star02", "Star03"]:
        var node := get_node_or_null(name) as MeshInstance3D
        if node != null:
            var target := camera.global_position
            target.y = node.global_position.y
            node.look_at(target, Vector3.UP)

func _refresh_minimap() -> void:
    $HUD/Minimap.set_game_state(player.global_position, player.rotation.y, acorns, squirrels, stunned)

func _on_menu_pressed() -> void:
    get_tree().change_scene_to_file("res://menu.tscn")
