# ACORN HUNTER — CANONICAL LEVEL 1 V18

Built directly from the user-confirmed V11 working build.

V18 changes only the Level 1 world data: the canonical 20x14 map from the original reference build is generated as 107 StaticBody3D wall cells, and the original Level 1 object coordinates are converted into the centered Godot world with safe placement around hedge cells. The V11 touch/UI/audio foundation is retained.
