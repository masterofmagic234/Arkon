# ACORN HUNTER — V21

Base: confirmed V20 Night Sky / Twinkle build.

## Wall illustration sets
- Six compatible 256x256 wall texture variants were added.
- Existing wall geometry and collision are untouched.
- Each canonical MapWall segment receives a deterministic visual variant, reducing repetition while preserving the exact V20 map.
- The original `hedge_wall_0.png` and canonical `WallMat`/`WallMesh` remain available as reference/fallback.

## Preserved from V20
- modular gameplay architecture
- canonical 20x14 map at 1.8 world units/cell
- 4K night sky + twinkle shader
- billboard world sprites
- squirrel 2-hit combat and stunned state
- minimap and mobile touch controls

No gameplay, input, collision, combat, or mission logic was changed.
