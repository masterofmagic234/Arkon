# ACORN HUNTER — CLEAN V13

V13 is based directly on the user-confirmed working V11 QuadMesh/mobile build.
The V12 canonical Level 1 world is retained, with the missing StyleBoxFlat subresources restored so game.tscn can be instantiated.

This is a structural fix, not a gameplay rewrite.
