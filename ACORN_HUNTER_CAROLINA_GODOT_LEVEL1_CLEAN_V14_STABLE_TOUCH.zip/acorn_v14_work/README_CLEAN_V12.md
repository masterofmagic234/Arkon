# ACORN HUNTER — CLEAN V12

Built directly on the proven V11 QuadMesh/touch foundation.

Changes:
- canonical original Level 1 20x14 map restored
- 9 oak trees, 4 acorns, 2 squirrels, fake pine cone restored
- 38 ammo (original Level 1 value)
- squirrels approach the player; first hit stuns them permanently
- stunned squirrel texture
- retry button on failure
- minimap now shows the canonical wall layout and world objects
- V11 touch joystick/fire/mute architecture preserved
- background music remains an AudioStreamPlayer with autoplay and explicit play() fallback
