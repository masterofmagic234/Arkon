extends Control

var game_position := Vector3.ZERO
var game_yaw := 0.0
var acorn_names: Array = []
var squirrel_names: Array = []
var stunned: Dictionary = {}

const MAP := [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,1,1,1,0,0,0,1,1,0,0,0,0,0,1],
    [1,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,1],
    [1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1],
    [1,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1],
    [1,0,1,1,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1],
    [1,0,0,0,1,1,1,0,1,0,1,1,1,0,0,0,0,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1],
    [1,0,0,1,1,1,0,0,1,1,1,0,0,0,0,0,0,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

func set_game_state(pos: Vector3, yaw: float, acorns: Array, squirrels: Array, stunned_state: Dictionary) -> void:
    game_position = pos
    game_yaw = yaw
    acorn_names = acorns.duplicate()
    squirrel_names = squirrels.duplicate()
    stunned = stunned_state.duplicate()
    queue_redraw()

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
    var rect := Rect2(Vector2(0, 28), Vector2(size.x, size.y - 28))
    var cell := minf(rect.size.x / 20.0, rect.size.y / 14.0)
    var origin := rect.position + Vector2((rect.size.x - cell * 20.0) * 0.5, (rect.size.y - cell * 14.0) * 0.5)

    for y in range(14):
        for x in range(20):
            if MAP[y][x] == 1:
                draw_rect(Rect2(origin + Vector2(x * cell, y * cell), Vector2(cell + 0.5, cell + 0.5)), Color(0.12,0.17,0.15,0.92))

    var center := origin + Vector2((game_position.x + 10.0) * cell, (game_position.z + 7.0) * cell)
    for child in get_tree().current_scene.get_children():
        if child is MeshInstance3D and child.name.begins_with("Tree"):
            _dot_world(origin, cell, child.global_position, Color(0.22,0.55,0.25,0.95), 2.2)

    for name in acorn_names:
        var node := get_tree().current_scene.get_node_or_null(name) as Node3D
        if node:
            _dot_world(origin, cell, node.global_position, Color(0.88,0.58,0.25,1.0), 3.2)

    for name in squirrel_names:
        var node := get_tree().current_scene.get_node_or_null(name) as Node3D
        if node:
            _dot_world(origin, cell, node.global_position, Color(0.9,0.35,0.25,0.95) if not stunned.has(name) else Color(0.45,0.65,0.95,0.9), 2.8)

    var facing := Vector2(-sin(game_yaw), -cos(game_yaw)) * 8.0
    draw_line(center, center + facing, Color(1.0, 0.78, 0.55, 0.95), 2.0)
    draw_circle(center, 3.5, Color(0.9, 0.95, 0.9, 1.0))

func _dot_world(origin: Vector2, cell: float, pos: Vector3, color: Color, radius: float) -> void:
    var p := origin + Vector2((pos.x + 10.0) * cell, (pos.z + 7.0) * cell)
    if Rect2(Vector2.ZERO, size).grow(-2.0).has_point(p):
        draw_circle(p, radius, color)
