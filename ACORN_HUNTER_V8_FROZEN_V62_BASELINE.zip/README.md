# Acorn Hunter — Frozen Level 1 Baseline

This build intentionally preserves the proven v6.2 Level 1 implementation.

## Rule
Do not modify Level 1 while building Level 2 or Level 3.

Level 1 is the regression baseline. New engines must be added alongside it, not by replacing its renderer or gameplay code.

## Current baseline
- Raycasting forest FPS
- Night sky
- Oak trees and acorns
- Carolina HUD portrait
- Footstep sounds
- Squirrel hit sound
- Sprite depth occlusion
- Correct Level 2-safe start position from v6.2
- Supplied Level 1 music
