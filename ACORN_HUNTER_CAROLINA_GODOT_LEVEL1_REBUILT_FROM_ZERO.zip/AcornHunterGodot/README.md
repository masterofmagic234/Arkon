# ACORN HUNTER — Godot Level 1 Rebuild

A clean recreation of the spirit of the original Acorn Hunter Android prototype, rebuilt from zero in Godot 4.7.2.

Level 1 only for this foundation build:
- fixed-height Wolfenstein-style first-person camera
- Operation Acorn title screen
- 20x14 corridor map
- hedges, grass and stone path
- four acorns + one fake pine cone
- squirrels with two-hit combat and a stunned/"contused" state
- dead squirrels remain on the ground with stars
- Carolina HUD
- full minimap
- mobile joystick + right-side look + dedicated fire button
- funny action messages
- night sky, moon and stars
- music, footsteps, shot and squirrel-hit sounds
- final victory screen

The Android build is intended for GitHub Actions: upload this ZIP to the repository and keep build.yml separately in the repository.
