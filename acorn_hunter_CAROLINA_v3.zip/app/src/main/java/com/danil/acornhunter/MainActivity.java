package com.danil.acornhunter;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.*;
import android.media.MediaPlayer;
import java.util.*;

public class MainActivity extends Activity {
    private MediaPlayer music;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        hideSystemUI();
        setContentView(new GameView(this));
        music = MediaPlayer.create(this, R.raw.acorn_music);
        if (music != null) {
            music.setLooping(true);
            music.setVolume(0.34f, 0.34f);
        }
    }

    private void hideSystemUI() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (music != null && music.isPlaying()) music.pause();
    }

    @Override protected void onResume() {
        super.onResume();
        hideSystemUI();
        if (music != null && !music.isPlaying()) music.start();
    }

    @Override protected void onDestroy() {
        if (music != null) { music.release(); music = null; }
        super.onDestroy();
    }

    static class GameView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Random rnd = new Random();
        final MainActivity host;
        Bitmap carolinaFace;

        ArrayList<PointF> acorns = new ArrayList<>();
        ArrayList<PointF> leaves = new ArrayList<>();
        ArrayList<PointF> squirrels = new ArrayList<>();
        ArrayList<PointF> fakeAcorns = new ArrayList<>();

        float playerX, playerY;
        int level = 0, found = 0, total = 3, secrets = 0;
        boolean started = false, finished = false, victory = false, levelComplete = false;
        boolean muted = false;
        String toast = "";
        long toastUntil = 0;
        long lastSquirrelMove = 0;
        int lives = 3;

        GameView(MainActivity c) {
            super(c); host = c; setFocusable(true);
            carolinaFace = BitmapFactory.decodeResource(getResources(), R.drawable.carolina_face);
        }

        float d(float a,float b,float c,float e) { return (float)Math.hypot(a-c,b-e); }

        void startMusic() {
            if (host.music != null && !muted && !host.music.isPlaying()) host.music.start();
        }

        void toggleMusic() {
            muted = !muted;
            if (host.music == null) return;
            if (muted && host.music.isPlaying()) host.music.pause();
            else if (!muted && started) host.music.start();
            showToast(muted ? "Музыка выключена." : "Музыка снова в эфире.");
        }

        void startGame() {
            started = true; finished = false; victory = false; levelComplete = false;
            level = 1; secrets = 0;
            setupLevel();
            startMusic();
        }

        void setupLevel() {
            found = 0; lives = 3; levelComplete = false;
            acorns.clear(); fakeAcorns.clear(); squirrels.clear(); leaves.clear();
            playerX = getWidth()/2f; playerY = getHeight()-170;

            int real = 3 + level;
            total = real;

            for (int i=0;i<55;i++)
                leaves.add(new PointF(30+rnd.nextFloat()*(getWidth()-60),
                        115+rnd.nextFloat()*(getHeight()-310)));

            for (int i=0;i<real;i++) acorns.add(randomItem(170));
            for (int i=0;i<level+2;i++) fakeAcorns.add(randomItem(130));

            if (level >= 2) {
                for (int i=0;i<Math.min(4, level);i++)
                    squirrels.add(new PointF(60+rnd.nextFloat()*(getWidth()-120),
                            180+rnd.nextFloat()*(getHeight()-400)));
            }

            toast = level == 1
                    ? "Уровень 1: парк. Тут всё ещё нет желудей."
                    : "Уровень " + level + ": белки активированы.";
            toastUntil = System.currentTimeMillis()+1800;
            invalidate();
        }

        PointF randomItem(float minFromPlayer) {
            PointF q; int guard=0;
            do {
                q = new PointF(55+rnd.nextFloat()*(getWidth()-110),
                        150+rnd.nextFloat()*(getHeight()-350));
                guard++;
            } while (d(q.x,q.y,playerX,playerY) < minFromPlayer && guard < 200);
            return q;
        }

        void showToast(String s) { toast=s; toastUntil=System.currentTimeMillis()+1500; }

        void completeLevelIfNeeded() {
            if (found >= total && !levelComplete && !finished) {
                if (level < 3) {
                    levelComplete = true;
                    showToast("Уровень пройден.");
                } else {
                    victory = true; finished = true;
                }
            }
        }

        void moveToward(float tx,float ty) {
            if (!started || finished || levelComplete) return;
            float dx=tx-playerX, dy=ty-playerY, len=(float)Math.hypot(dx,dy);
            if (len<2) return;
            playerX=Math.max(48,Math.min(getWidth()-48,playerX+dx/len*30));
            playerY=Math.max(120,Math.min(getHeight()-115,playerY+dy/len*30));

            for (int i=acorns.size()-1;i>=0;i--) {
                PointF a=acorns.get(i);
                if (d(playerX,playerY,a.x,a.y)<55) {
                    acorns.remove(i); found++;
                    if (found==1 && secrets==0) { secrets++; showToast("Котёнок, один есть. Я в тебя верила."); }
                    else if (found==2 && secrets==1) { secrets++; showToast("Данил сообщает: прогресс исторический."); }
                    else showToast("ЖЁЛУДЬ! Дарина одобряет.");
                    completeLevelIfNeeded();
                }
            }

            for (int i=fakeAcorns.size()-1;i>=0;i--) {
                PointF a=fakeAcorns.get(i);
                if (d(playerX,playerY,a.x,a.y)<50) {
                    fakeAcorns.remove(i); lives--;
                    showToast("ЭТО БЫЛ НЕ ЖЁЛУДЬ. Удача: "+lives+"/3");
                    if (lives<=0) { finished=true; victory=false; }
                }
            }

            if (level >= 2 && System.currentTimeMillis()-lastSquirrelMove>900) {
                lastSquirrelMove=System.currentTimeMillis();
                for (PointF s:squirrels) {
                    float ang=rnd.nextFloat()*(float)Math.PI*2;
                    s.x=Math.max(40,Math.min(getWidth()-40,s.x+(float)Math.cos(ang)*70));
                    s.y=Math.max(150,Math.min(getHeight()-120,s.y+(float)Math.sin(ang)*70));
                }
                for (int i=acorns.size()-1;i>=0;i--) {
                    PointF a=acorns.get(i);
                    boolean stolen=false;
                    for (PointF s:squirrels) if (d(a.x,a.y,s.x,s.y)<42) { stolen=true; break; }
                    if (stolen) { acorns.remove(i); total--; showToast("БЕЛКА УКРАЛА ЖЁЛУДЬ. Я ВИДЕЛА."); }
                }
                completeLevelIfNeeded();
            }
            invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            int w=getWidth(),h=getHeight();
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(23,20,33)); c.drawRect(0,0,w,h,p);
            if (!started) { drawStart(c,w,h); return; }

            p.setColor(Color.rgb(39,57,43)); c.drawRect(0,95,w,h,p);
            p.setColor(Color.rgb(27,42,33));
            for(int i=0;i<11;i++){ float x=18+i*w/10f; c.drawRect(x-8,120,x+8,h,p); }
            for(PointF q:leaves){ p.setColor(Color.rgb(83,110,69)); c.drawCircle(q.x,q.y,15,p); p.setColor(Color.rgb(112,86,52)); c.drawCircle(q.x+11,q.y+5,4,p); }

            p.setColor(Color.rgb(23,20,33)); c.drawRect(0,0,w,95,p);
            txt(c,"ОПЕРАЦИЯ «ЖЁЛУДЬ»",18,31,18,Color.WHITE,true);
            txt(c,"УР. "+level+"   "+found+" / "+total,18,64,16,Color.rgb(240,216,165),true);
            txt(c,"❤ "+lives,w-100,64,16,Color.rgb(255,174,183),true);
            p.setColor(Color.argb(100,255,255,255)); c.drawRoundRect(w-58,17,w-16,59,21,21,p);
            txtCenter(c,muted?"×":"♪",w-37,46,20,Color.WHITE,true);

            for(PointF a:fakeAcorns) drawFake(c,a.x,a.y);
            for(PointF a:acorns) drawAcorn(c,a.x,a.y);
            for(PointF s:squirrels) drawSquirrel(c,s.x,s.y);
            drawPlayer(c,playerX,playerY);

            // Bottom controls
            p.setColor(Color.argb(75,255,255,255));
            c.drawCircle(68,h-62,43,p); c.drawCircle(w-68,h-62,43,p);
            txt(c,"←",49,h-50,27,Color.DKGRAY,true); txt(c,"→",w-87,h-50,27,Color.DKGRAY,true);

            if(toastUntil>System.currentTimeMillis()){
                p.setColor(Color.argb(238,255,248,235)); c.drawRoundRect(18,105,w-18,163,27,27,p);
                txt(c,toast,34,140,13,Color.rgb(55,43,47),true); postInvalidateDelayed(100);
            }
            if(levelComplete) drawLevelComplete(c,w,h);
            if(finished) drawFinish(c,w,h);
        }

        void drawStart(Canvas c,int w,int h) {
            txtCenter(c,"ОПЕРАЦИЯ",w,h*0.22f,29,Color.rgb(255,185,190),true);
            txtCenter(c,"«ЖЁЛУДЬ»",w,h*0.30f,44,Color.WHITE,true);
            txtCenter(c,"Игра, которую пришлось сделать после",w,h*0.37f,16,Color.LTGRAY,false);
            txtCenter(c,"того, как ты слишком долго искала жёлуди.",w,h*0.405f,16,Color.LTGRAY,false);
            p.setColor(Color.rgb(255,174,183)); c.drawRoundRect(45,h*0.56f,w-45,h*0.63f,38,38,p);
            txtCenter(c,"НАЧАТЬ ОПЕРАЦИЮ",w,h*0.605f,18,Color.rgb(35,28,35),true);
            txtCenter(c,"Цель: найти хотя бы один.",w,h-92,14,Color.GRAY,false);
            txtCenter(c,"Побочный квест: пережить белок.",w,h-67,14,Color.GRAY,false);
            txtCenter(c,"♪ музыка включается автоматически",w,h-38,12,Color.GRAY,false);
        }

        void drawLevelComplete(Canvas c,int w,int h) {
            p.setColor(Color.argb(245,23,20,33)); c.drawRect(0,0,w,h,p);
            txtCenter(c,"УРОВЕНЬ "+level+" ПРОЙДЕН",w,h*0.31f,28,Color.rgb(255,205,120),true);
            txtCenter(c,"Улик найдено: "+found+".",w,h*0.37f,17,Color.WHITE,false);
            txtCenter(c,level==1?"Это было подозрительно легко.":"Белки пока не сдаются.",w,h*0.42f,16,Color.WHITE,false);
            p.setColor(Color.rgb(255,174,183)); c.drawRoundRect(45,h*0.58f,w-45,h*0.66f,35,35,p);
            txtCenter(c,"ИДТИ ДАЛЬШЕ",w,h*0.635f,18,Color.rgb(35,28,35),true);
        }

        void drawFinish(Canvas c,int w,int h) {
            p.setColor(Color.argb(246,23,20,33)); c.drawRect(0,0,w,h,p);
            if(victory){
                txtCenter(c,"★",w,h*0.20f,52,Color.WHITE,true);
                txtCenter(c,"ОН СУЩЕСТВУЕТ.",w,h*0.30f,30,Color.rgb(255,205,120),true);
                txtCenter(c,"Каролина нашла легендарный жёлудь.",w,h*0.37f,17,Color.WHITE,false);
                txtCenter(c,"Дарина может делать поделку.",w,h*0.415f,17,Color.WHITE,false);
                txtCenter(c,"Белки официально проиграли.",w,h*0.47f,17,Color.rgb(255,174,183),true);
                txtCenter(c,"P.S. Данил всё это время верил в тебя.",w,h*0.56f,15,Color.LTGRAY,false);
            } else {
                txtCenter(c,"ОПЕРАЦИЯ ПРОВАЛЕНА",w,h*0.31f,27,Color.rgb(255,174,183),true);
                txtCenter(c,"Ты приняла подозрительный объект",w,h*0.37f,16,Color.WHITE,false);
                txtCenter(c,"за жёлудь. Это была шишка.",w,h*0.405f,16,Color.WHITE,false);
            }
            p.setColor(Color.rgb(255,174,183)); c.drawRoundRect(45,h*0.67f,w-45,h*0.75f,35,35,p);
            txtCenter(c,"НАЧАТЬ ЗАНОВО",w,h*0.725f,18,Color.rgb(35,28,35),true);
        }

        void drawAcorn(Canvas c,float x,float y){
            p.setColor(Color.rgb(180,116,63)); c.drawOval(x-12,y-7,x+12,y+19,p);
            p.setColor(Color.rgb(89,61,42)); c.drawArc(x-14,y-17,x+14,y+3,180,-180,true,p);
            p.setColor(Color.rgb(230,178,110)); c.drawCircle(x-4,y+6,3,p);
        }
        void drawFake(Canvas c,float x,float y){
            p.setColor(Color.rgb(117,83,53)); c.drawOval(x-13,y-6,x+13,y+20,p);
            p.setColor(Color.rgb(78,60,48)); c.drawArc(x-15,y-16,x+15,y+4,180,-180,true,p);
            p.setColor(Color.rgb(150,115,78)); c.drawLine(x-10,y+5,x+9,y+13,p);
        }
        void drawSquirrel(Canvas c,float x,float y){
            p.setColor(Color.rgb(166,96,55)); c.drawCircle(x,y,17,p); c.drawCircle(x-13,y-13,8,p); c.drawCircle(x+13,y-13,8,p);
            p.setColor(Color.rgb(60,42,42)); c.drawCircle(x-6,y-3,2.5f,p); c.drawCircle(x+6,y-3,2.5f,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); c.drawArc(x-7,y+1,x+7,y+11,10,160,false,p); p.setStyle(Paint.Style.FILL);
        }

        void drawPlayer(Canvas c,float x,float y){
            float bob=(float)Math.sin(System.currentTimeMillis()/180.0)*2f;
            // simple stylized body
            p.setColor(Color.rgb(47,40,61)); c.drawRoundRect(x-28,y-2+bob,x+28,y+42+bob,18,18,p);
            p.setColor(Color.rgb(255,185,190)); c.drawCircle(x-24,y+19+bob,7,p); c.drawCircle(x+24,y+19+bob,7,p);
            if(carolinaFace!=null){
                Rect src=new Rect(0,0,carolinaFace.getWidth(),carolinaFace.getHeight());
                RectF dst=new RectF(x-43,y-83+bob,x+43,y+15+bob);
                c.drawBitmap(carolinaFace,src,dst,p);
            } else {
                p.setColor(Color.rgb(255,185,190)); c.drawCircle(x,y-42+bob,28,p);
            }
            postInvalidateDelayed(40);
        }

        void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){
            p.setTextSize(size); p.setColor(color); p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL)); c.drawText(s,x,y,p);
        }
        void txtCenter(Canvas c,String s,float centerX,float y,float size,int color,boolean bold){
            p.setTextSize(size); p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL)); txt(c,s,centerX-p.measureText(s)/2,y,size,color,bold);
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_DOWN && e.getAction()!=MotionEvent.ACTION_MOVE) return true;
            float x=e.getX(), y=e.getY(); int w=getWidth(),h=getHeight();

            if(x>w-75 && y<80){ if(e.getAction()==MotionEvent.ACTION_DOWN) toggleMusic(); return true; }

            if(!started){
                if(e.getAction()==MotionEvent.ACTION_DOWN && y>h*0.51f && y<h*0.68f) startGame();
                return true;
            }
            if(levelComplete){
                if(e.getAction()==MotionEvent.ACTION_DOWN && y>h*0.54f && y<h*0.71f){ level++; setupLevel(); }
                return true;
            }
            if(finished){
                if(e.getAction()==MotionEvent.ACTION_DOWN && y>h*0.63f && y<h*0.80f) startGame();
                return true;
            }
            if(y>h-140) moveToward(x<w/2?playerX-120:playerX+120,playerY); else moveToward(x,y);
            return true;
        }
    }
}
