extends Node3D

# ACORN HUNTER — LEVEL 1
# Mobile Wolfenstein-style controls:
#   joystick Y = forward/backward
#   joystick X = rotate camera/player horizontally
#   FIRE = hits the first squirrel under the crosshair

const WALK_SPEED := 3.4
const TURN_SPEED := 2.15
const JOYSTICK_RADIUS := 58.0
const ACORN_PICKUP_RADIUS := 1.25
const FIRE_RANGE := 18.0
const SQUIRREL_LAYER := 2
const WORLD_LAYER := 1

var move_axis := Vector2.ZERO
var joystick_touch_id := -1
var mouse_joystick := false
var collected := 0
var message_time := 0.0
var fire_cooldown := 0.0
var recoil_time := 0.0
var fake_cone_found := false
var mission_complete := false
var stunned := {}
var acorns := ["Acorn01", "Acorn02", "Acorn03", "Acorn04"]
var squirrels := ["Squirrel01", "Squirrel02", "Squirrel03"]

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var joystick: Panel = $HUD/Joystick
@onready var knob: Panel = $HUD/Joystick/Knob
@onready var fire_button: Button = $HUD/Fire
@onready var count_label: Label = $HUD/Count
@onready var message_label: Label = $HUD/Message
@onready var mission_panel: Panel = $HUD/Mission
@onready var weapon: TextureRect = $HUD/Weapon
@onready var muzzle: ColorRect = $HUD/MuzzleFlash
@onready var hit_marker: Label = $HUD/HitMarker

func _ready() -> void:
    mission_panel.visible = false
    muzzle.visible = false
    hit_marker.visible = false
    knob.position = joystick.size * 0.5 - knob.size * 0.5
    _set_message("Парк найден. Жёлуди существуют. Белки пока ничего не подозревают.", 4.0)
    _refresh_minimap()

func _physics_process(delta: float) -> void:
    if mission_complete:
        player.velocity = Vector3.ZERO
        return

    # Vertical axis of the single stick = Wolfenstein forward/backward.
    var forward := -move_axis.y
    player.velocity = -player.global_transform.basis.z * (forward * WALK_SPEED)
    player.velocity.y = 0.0
    player.move_and_slide()

    # Horizontal axis of the SAME stick = horizontal camera/player turn.
    if abs(move_axis.x) > 0.04:
        player.rotate_y(-move_axis.x * TURN_SPEED * delta)

    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    recoil_time = maxf(0.0, recoil_time - delta)
    if recoil_time <= 0.0:
        weapon.position.y = 455.0

    if message_time > 0.0:
        message_time -= delta
        if message_time <= 0.0:
            message_label.text = ""

    if muzzle.visible:
        muzzle.modulate.a = clampf(muzzle.modulate.a - delta * 6.0, 0.0, 1.0)
        if muzzle.modulate.a <= 0.0:
            muzzle.visible = false

    _collect_acorns()
    _check_fake_cone()
    _refresh_minimap()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            if _point_in_rect(event.position, joystick.get_global_rect()):
                joystick_touch_id = event.index
                _update_joystick(event.position)
                get_viewport().set_input_as_handled()
            elif _point_in_rect(event.position, fire_button.get_global_rect()):
                _on_fire_pressed()
                get_viewport().set_input_as_handled()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            get_viewport().set_input_as_handled()

    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _update_joystick(event.position)
        get_viewport().set_input_as_handled()

    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            if _point_in_rect(event.position, joystick.get_global_rect()):
                mouse_joystick = true
                _update_joystick(event.position)
            elif _point_in_rect(event.position, fire_button.get_global_rect()):
                _on_fire_pressed()
        elif mouse_joystick:
            mouse_joystick = false
            move_axis = Vector2.ZERO
            _reset_joystick()

    elif event is InputEventMouseMotion and mouse_joystick:
        _update_joystick(event.position)

func _point_in_rect(point: Vector2, rect: Rect2) -> bool:
    return rect.has_point(point)

func _update_joystick(position: Vector2) -> void:
    var center := joystick.get_global_rect().get_center()
    var delta := position - center
    if delta.length() > JOYSTICK_RADIUS:
        delta = delta.normalized() * JOYSTICK_RADIUS
    move_axis = Vector2(delta.x / JOYSTICK_RADIUS, delta.y / JOYSTICK_RADIUS)
    knob.position = joystick.size * 0.5 - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func _collect_acorns() -> void:
    for name in acorns.duplicate():
        var node := get_node_or_null(name) as Sprite3D
        if node != null and player.global_position.distance_to(node.global_position) <= ACORN_PICKUP_RADIUS:
            node.visible = false
            acorns.erase(name)
            collected += 1
            count_label.text = "ЖЁЛУДИ  %d / 4" % collected
            _set_message("Жёлудь добыт. Дарина будет довольна. Ещё %d." % (4 - collected), 1.8)
            if collected == 4:
                _complete()

func _check_fake_cone() -> void:
    if fake_cone_found:
        return
    var cone := get_node_or_null("FakePineCone") as Sprite3D
    if cone != null and player.global_position.distance_to(cone.global_position) <= 1.2:
        fake_cone_found = true
        _set_message("Это не жёлудь. Это шишка. Разведка докладывает: позор.", 2.8)

func _on_fire_pressed() -> void:
    if mission_complete or fire_cooldown > 0.0:
        return
    fire_cooldown = 0.18
    recoil_time = 0.10
    weapon.position.y = 470.0
    muzzle.visible = true
    muzzle.modulate.a = 1.0

    var query := PhysicsRayQueryParameters3D.create(
        camera.global_position,
        camera.global_position + (-camera.global_transform.basis.z * FIRE_RANGE),
        SQUIRREL_LAYER | WORLD_LAYER
    )
    query.collide_with_areas = true
    query.collide_with_bodies = true
    var hit := get_world_3d().direct_space_state.intersect_ray(query)

    if hit.is_empty():
        _miss()
        return

    var collider: Object = hit.get("collider")
    var squirrel := _find_squirrel_from_collider(collider)
    if squirrel == "":
        _miss()
        return

    if stunned.has(squirrel):
        _miss()
        return

    stunned[squirrel] = true
    var target := get_node_or_null(squirrel) as Sprite3D
    if target != null:
        target.modulate = Color(0.48, 0.70, 1.0, 1.0)
    hit_marker.visible = true
    hit_marker.text = "×"
    _set_message("БЕЛКА ОГЛУШЕНА. Животное не пострадало. Операция всё ещё засекречена.", 2.0)
    await get_tree().create_timer(0.35).timeout
    if not mission_complete:
        hit_marker.visible = false

func _find_squirrel_from_collider(collider: Object) -> String:
    if collider == null:
        return ""
    var node := collider as Node
    if node == null:
        return ""
    while node != null:
        if squirrels.has(node.name):
            return node.name
        node = node.get_parent()
    return ""

func _miss() -> void:
    hit_marker.visible = true
    hit_marker.text = "•"
    _set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await get_tree().create_timer(0.22).timeout
    if not mission_complete:
        hit_marker.visible = false

func _complete() -> void:
    mission_complete = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    $HUD/Mission/Title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    $HUD/Mission/Body.text = "ЖЁЛУДИ: 4 / 4\n\nОН СУЩЕСТВУЕТ.\n\nP.S. Данил всё это время верил в тебя."

func _on_menu_pressed() -> void:
    get_tree().change_scene_to_file("res://menu.tscn")

func _set_message(text: String, duration: float) -> void:
    message_label.text = text
    message_time = duration

func _refresh_minimap() -> void:
    var map := $HUD/Minimap
    map.set_game_state(player.global_position, player.rotation.y, acorns, squirrels, stunned)
