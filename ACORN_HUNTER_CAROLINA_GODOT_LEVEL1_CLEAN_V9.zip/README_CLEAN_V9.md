ACORN HUNTER — CLEAN V9

Level 1 content pass based directly on the original Carolina v7 THREE_ERAS build.

Canonical Level 1 concepts preserved:
- 20x14 hedge map and original object layout, translated to the Godot world.
- 4 acorns, 2 squirrels, 1 fake pine cone.
- Squirrels are non-lethal targets: first hit stuns; later hits count as misses.
- Original humorous ACORN/CONE/HIT/STUN/DAMAGE phrase pools.
- HP and ammo.
- Acorn pickup, fake-cone damage, squirrel contact damage.
- Music, footsteps, shooting, pickup, damage and squirrel-hit sounds.
- Carolina HUD portrait.
- Minimap.
- Victory and defeat screens.
- One-stick Wolfenstein control: Y movement, X horizontal turning.
- Camera pitch locked to zero and camera height aligned to the play geometry.

The V9 archive was statically checked. Runtime Android execution still requires the user's Godot CI build.
