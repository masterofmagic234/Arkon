# ACORN HUNTER — CLEAN V6

Level 1 rebuilt from the verified CLEAN V5 foundation into a Wolfenstein-style mobile control model.

## Controls
- One joystick only.
- Joystick up/down: move forward/backward.
- Joystick left/right: rotate camera/player horizontally, like classic Wolfenstein 3D.
- FIRE: raycast shot through the crosshair.

## Gameplay
- Collect 4 acorns.
- Three squirrels can each be stunned exactly once.
- Additional shots at already-stunned squirrels count as misses.
- Fake pine cone has a dedicated joke message.
- Weapon recoil, muzzle flash and hit/miss feedback.
- Physical walls use CharacterBody3D + collision.
- Dynamic minimap shows player direction, acorns and squirrels.
- Completion screen preserves the original Carolina/Acorn Hunter punchline.

## Technical notes
The player is a CharacterBody3D and uses move_and_slide() for collision-aware movement. Touch input uses InputEventScreenTouch/InputEventScreenDrag directly. The scene keeps visual geometry static so runtime logic cannot make the entire level disappear if a script-side feature fails.
