ACORN HUNTER — CLEAN V8

V8 is built directly from the verified-working CLEAN V6 foundation.

Changes:
- Camera vertical rotation fixed from -7 degrees to 0 degrees.
- Same proven single-stick Wolfenstein controls are preserved:
  Y = forward/backward, X = horizontal turn.
- Added HP / AMMO HUD.
- Added music, footsteps, shot and squirrel-hit sounds.
- Added Carolina portrait to HUD.
- Added simple moving squirrels; first hit stuns, later hits count as misses.
- Added ammo depletion and reload-free fixed-magazine behavior for this level.
- Added fake pine-cone HP penalty.
- Added failure screen when HP reaches zero.
- Preserved the working acorn collection and victory path.

This iteration deliberately stays close to the proven V6 architecture so that
new gameplay features do not destabilize scene startup on Android.
Runtime Android testing still occurs in the user's GitHub Actions build.
