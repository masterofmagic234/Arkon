extends Node3D

# ACORN HUNTER — LEVEL 1
# Rebuilt from the last proven CLEAN/V6 control foundation.
# World sprites are deliberately MeshInstance3D + QuadMesh, not Sprite3D.
# UI owns touch input: joystick.gui_input + Fire.pressed.

const LevelData = preload("res://scripts/level_data.gd")
const HudView = preload("res://scripts/hud_view.gd")
const AudioController = preload("res://scripts/audio_controller.gd")

var move_axis := Vector2.ZERO
var joystick_touch_id := -1
var collected := 0
var ammo := LevelData.MAX_AMMO
var hp := LevelData.MAX_HP
var message_time := 0.0
var fire_cooldown := 0.0
var damage_cooldown := 0.0
var recoil_time := 0.0
var foot_timer := 0.0
var fake_cone_found := false
var mission_complete := false
var mission_failed := false
var audio_controller: AudioController
var stunned: Dictionary = {}
var squirrel_hp := LevelData.SQUIRREL_HP.duplicate()
var acorns := LevelData.ACORN_NAMES.duplicate()
var squirrels := LevelData.SQUIRREL_NAMES.duplicate()
var squirrel_home := LevelData.SQUIRREL_HOME.duplicate()
var squirrel_phase := LevelData.SQUIRREL_PHASE.duplicate()
var hud_view: HudView

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var joystick: Panel = $HUD/Joystick
@onready var knob: Panel = $HUD/Joystick/Knob
@onready var fire_button: Button = $HUD/Fire
@onready var mute_button: Button = $HUD/Mute
@onready var count_label: Label = $HUD/Count
@onready var hp_ammo_label: Label = $HUD/HPAmmo
@onready var message_label: Label = $HUD/Message
@onready var mission_panel: Panel = $HUD/Mission
@onready var mission_title: Label = $HUD/Mission/Title
@onready var mission_body: Label = $HUD/Mission/Body
@onready var weapon: TextureRect = $HUD/Weapon
@onready var muzzle: ColorRect = $HUD/MuzzleFlash
@onready var hit_marker: Label = $HUD/HitMarker
@onready var carolina: TextureRect = $HUD/Carolina
@onready var music: AudioStreamPlayer = $Music
@onready var fx: AudioStreamPlayer = $FX

func _ready() -> void:
    camera.rotation = Vector3.ZERO
    camera.fov = 70.0
    camera.near = 0.05
    camera.far = 40.0
    carolina.texture = load("res://assets/carolina_face.png")
    mission_panel.visible = false
    muzzle.visible = false
    hit_marker.visible = false
    knob.position = joystick.size * 0.5 - knob.size * 0.5

    # Touch is handled by the actual UI controls, not by a global input relay.
    joystick.gui_input.connect(_on_joystick_gui_input)
    fire_button.pressed.connect(_on_fire_pressed)
    mute_button.pressed.connect(_toggle_music)
    $HUD/Mission/Menu.pressed.connect(_on_menu_pressed)

    hud_view = HudView.new()
    hud_view.setup(count_label, hp_ammo_label)

    audio_controller = AudioController.new()
    audio_controller.setup(music, fx)
    audio_controller.start_music()
    _update_hud()
    _set_message("Парк открыт. Дубы не прячутся — жёлуди тоже.", 4.0)
    _refresh_minimap()

func _physics_process(delta: float) -> void:
    if mission_complete or mission_failed:
        player.velocity = Vector3.ZERO
        return

    var forward := -move_axis.y
    player.velocity = -player.global_transform.basis.z * (forward * LevelData.WALK_SPEED)
    player.velocity.y = 0.0
    player.move_and_slide()

    if abs(move_axis.x) > 0.04:
        player.rotate_y(-move_axis.x * LevelData.TURN_SPEED * delta)

    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    damage_cooldown = maxf(0.0, damage_cooldown - delta)
    recoil_time = maxf(0.0, recoil_time - delta)
    message_time = maxf(0.0, message_time - delta)

    if message_time <= 0.0:
        message_label.text = ""
    if recoil_time <= 0.0:
        weapon.position.y = 455.0
    if muzzle.visible:
        muzzle.modulate.a = clampf(muzzle.modulate.a - delta * 7.0, 0.0, 1.0)
        if muzzle.modulate.a <= 0.0:
            muzzle.visible = false

    if abs(forward) > 0.05:
        foot_timer -= delta
        if foot_timer <= 0.0:
            _footstep()
            foot_timer = 0.30
    else:
        foot_timer = 0.0

    _update_squirrels(delta)
    _collect_acorns()
    _check_fake_cone()
    _update_hud()
    _refresh_minimap()

func _on_joystick_gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            joystick_touch_id = event.index
            _update_joystick(event.position)
            joystick.accept_event()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _update_joystick(event.position)
        joystick.accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            joystick_touch_id = -2
            _update_joystick(event.position)
            joystick.accept_event()
        elif joystick_touch_id == -2:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            joystick.accept_event()
    elif event is InputEventMouseMotion and joystick_touch_id == -2:
        _update_joystick(event.position)
        joystick.accept_event()

func _update_joystick(position: Vector2) -> void:
    var center := joystick.size * 0.5
    var delta := position - center
    if delta.length() > LevelData.JOYSTICK_RADIUS:
        delta = delta.normalized() * LevelData.JOYSTICK_RADIUS
    move_axis = Vector2(delta.x / LevelData.JOYSTICK_RADIUS, delta.y / LevelData.JOYSTICK_RADIUS)
    knob.position = center - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func _on_fire_pressed() -> void:
    if mission_complete or mission_failed or fire_cooldown > 0.0:
        return
    if ammo <= 0:
        _set_message("Пусто. Даже белки в шоке.", 1.2)
        return

    ammo -= 1
    fire_cooldown = 0.18
    recoil_time = 0.10
    weapon.position.y = 470.0
    muzzle.visible = true
    muzzle.modulate.a = 1.0
    audio_controller.play_fx(audio_controller.shoot_stream)

    var query := PhysicsRayQueryParameters3D.create(
        camera.global_position,
        camera.global_position + (-camera.global_transform.basis.z * LevelData.FIRE_RANGE),
        LevelData.SQUIRREL_LAYER | LevelData.WORLD_LAYER
    )
    query.collide_with_areas = true
    query.collide_with_bodies = true
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        _miss()
        return

    var squirrel := _find_squirrel_from_collider(hit.get("collider"))
    if squirrel == "" or stunned.has(squirrel):
        _miss()
        return

    squirrel_hp[squirrel] = int(squirrel_hp.get(squirrel, 2)) - 1
    var target := get_node_or_null(squirrel) as MeshInstance3D
    audio_controller.play_fx(audio_controller.squirrel_hit_stream)
    hit_marker.visible = true
    hit_marker.text = "×"
    if int(squirrel_hp[squirrel]) <= 0:
        stunned[squirrel] = true
        if target != null:
            var stunned_texture := load("res://assets/squirrel_stunned.png")
            if stunned_texture != null and target.mesh is QuadMesh:
                var base_mat := (target.mesh as QuadMesh).material as StandardMaterial3D
                if base_mat != null:
                    var unique_mat := base_mat.duplicate() as StandardMaterial3D
                    unique_mat.albedo_texture = stunned_texture
                    target.set_surface_override_material(0, unique_mat)
            target.rotation.z = deg_to_rad(-7.0)
            target.scale = Vector3(1.0, 0.78, 1.0)
        _set_message(LevelData.STUN_LINES.pick_random(), 2.0)
    else:
        _set_message(LevelData.HIT_LINES.pick_random() + "\nЕщё один раз — и белка отдыхает.", 1.4)
    await get_tree().create_timer(0.35).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _find_squirrel_from_collider(collider: Object) -> String:
    var node := collider as Node
    while node != null:
        if squirrels.has(node.name):
            return node.name
        node = node.get_parent()
    return ""

func _miss() -> void:
    hit_marker.visible = true
    hit_marker.text = "•"
    _set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await get_tree().create_timer(0.22).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _update_squirrels(delta: float) -> void:
    var player_pos := Vector2(player.global_position.x, player.global_position.z)
    for name in squirrels:
        if stunned.has(name):
            continue
        var node := get_node_or_null(name) as MeshInstance3D
        if node == null:
            continue
        var home: Vector2 = squirrel_home[name]
        var dist := home.distance_to(player_pos)
        if dist < 6.0 and dist > 1.8:
            var away := (home - player_pos).normalized()
            var proposed := home + away * delta * 0.45
            if not _is_wall(proposed.x, proposed.y):
                squirrel_home[name] = proposed
                node.position.x = proposed.x
                node.position.z = proposed.y
        node.rotation.z = sin(Time.get_ticks_msec() * 0.003 + float(squirrel_phase[name])) * 0.03
        if dist < 1.0 and damage_cooldown <= 0.0:
            damage_cooldown = 0.8
            hp = max(0, hp - 12)
            audio_controller.play_fx(audio_controller.damage_stream)
            _set_message(LevelData.DAMAGE_LINES.pick_random(), 1.2)
            if hp <= 0:
                _fail()

func _is_wall(x: float, z: float) -> bool:
    var cell_x := int(floor(x / LevelData.CELL_SIZE + 10.0))
    var cell_z := int(floor(z / LevelData.CELL_SIZE + 7.0))
    if cell_x < 0 or cell_x >= LevelData.MAP_WIDTH or cell_z < 0 or cell_z >= LevelData.MAP_HEIGHT:
        return true
    return LevelData.CANONICAL_MAP[cell_z].substr(cell_x, 1) == "1"

func _collect_acorns() -> void:
    for name in acorns.duplicate():
        var node := get_node_or_null(name) as MeshInstance3D
        if node != null and player.global_position.distance_to(node.global_position) <= LevelData.ACORN_PICKUP_RADIUS:
            node.visible = false
            acorns.erase(name)
            collected += 1
            if audio_controller.pickup_stream != null:
                audio_controller.play_fx(audio_controller.pickup_stream)
            _set_message(LevelData.ACORN_LINES.pick_random() + "\nЖёлуди: %d / %d" % [collected, LevelData.ACORN_COUNT], 1.8)
            if collected == LevelData.ACORN_COUNT:
                _complete()

func _check_fake_cone() -> void:
    if fake_cone_found:
        return
    var cone := get_node_or_null("FakePineCone") as MeshInstance3D
    if cone != null and player.global_position.distance_to(cone.global_position) <= 1.2:
        fake_cone_found = true
        hp = max(0, hp - 12)
        if audio_controller.damage_stream != null:
            audio_controller.play_fx(audio_controller.damage_stream)
        _set_message(LevelData.CONE_LINES.pick_random(), 2.4)
        if hp <= 0:
            _fail()

func _complete() -> void:
    mission_complete = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    mission_body.text = "ЖЁЛУДИ: %d / %d\n\nОН СУЩЕСТВУЕТ.\n\nКаролина нашла легендарный жёлудь.\nДарина может делать поделку.\nБелки официально проиграли.\n\nP.S. Данил всё это время верил в тебя." % [LevelData.ACORN_COUNT, LevelData.ACORN_COUNT]
    weapon.visible = false

func _fail() -> void:
    mission_failed = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ПРОВАЛЕНА"
    mission_body.text = "HP: 0\n\nБелки победили.\nЭто позор.\n\nНо Дарина всё ещё ждёт жёлуди."
    weapon.visible = false

func _update_hud() -> void:
    hud_view.update_status(collected, LevelData.ACORN_COUNT, hp, ammo)

func _set_message(text: String, duration: float) -> void:
    message_label.text = text
    message_time = duration

func _footstep() -> void:
    audio_controller.footstep()

func _toggle_music() -> void:
    var is_muted := audio_controller.toggle_music()
    mute_button.text = "×" if is_muted else "♪"
    _set_message("Музыка выключена." if is_muted else "Музыка возвращена. Белки снова слышат угрозу.", 1.6)

func _face_world_sprites() -> void:
    # Billboard materials handle camera-facing orientation.
    pass

func _refresh_minimap() -> void:
    $HUD/Minimap.set_game_state(player.global_position, player.rotation.y, acorns, squirrels, stunned)

func _on_menu_pressed() -> void:
    get_tree().change_scene_to_file("res://menu.tscn")
