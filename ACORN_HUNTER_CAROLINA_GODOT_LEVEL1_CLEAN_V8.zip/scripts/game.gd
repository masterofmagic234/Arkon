extends Node3D

# ACORN HUNTER — LEVEL 1
# Proven CLEAN V6 control foundation, expanded carefully.
# Mobile Wolfenstein-style controls:
#   joystick Y = forward/backward
#   joystick X = turn left/right
#   FIRE = first hit stuns a squirrel; later shots are misses

const WALK_SPEED := 3.4
const TURN_SPEED := 2.15
const JOYSTICK_RADIUS := 58.0
const ACORN_PICKUP_RADIUS := 1.25
const FIRE_RANGE := 18.0
const SQUIRREL_LAYER := 2
const WORLD_LAYER := 1
const MAX_AMMO := 35
const MAX_HP := 100

var move_axis := Vector2.ZERO
var joystick_touch_id := -1
var mouse_joystick := false
var collected := 0
var ammo := MAX_AMMO
var hp := MAX_HP
var message_time := 0.0
var fire_cooldown := 0.0
var recoil_time := 0.0
var foot_timer := 0.0
var bob := 0.0
var fake_cone_found := false
var mission_complete := false
var mission_failed := false
var muted := false
var stunned: Dictionary = {}
var acorns := ["Acorn01", "Acorn02", "Acorn03", "Acorn04"]
var squirrels := ["Squirrel01", "Squirrel02", "Squirrel03"]
var squirrel_home := {
    "Squirrel01": Vector2(-1.5,1.2),
    "Squirrel02": Vector2(4.0,-1.0),
    "Squirrel03": Vector2(-4.0,3.2)
}
var squirrel_phase := {"Squirrel01":0.0, "Squirrel02":1.7, "Squirrel03":3.4}

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var joystick: Panel = $HUD/Joystick
@onready var knob: Panel = $HUD/Joystick/Knob
@onready var fire_button: Button = $HUD/Fire
@onready var count_label: Label = $HUD/Count
@onready var hp_ammo_label: Label = $HUD/HPAmmo
@onready var message_label: Label = $HUD/Message
@onready var mission_panel: Panel = $HUD/Mission
@onready var mission_title: Label = $HUD/Mission/Title
@onready var mission_body: Label = $HUD/Mission/Body
@onready var weapon: TextureRect = $HUD/Weapon
@onready var muzzle: ColorRect = $HUD/MuzzleFlash
@onready var hit_marker: Label = $HUD/HitMarker
@onready var mute_button: Button = $HUD/Mute
@onready var carolina: TextureRect = $HUD/Carolina

var music_stream = preload("res://assets/acorn_music.mp3")
var foot1_stream = preload("res://assets/footstep1.wav")
var foot2_stream = preload("res://assets/footstep2.wav")
var shoot_stream = preload("res://assets/shoot.wav")
var squirrel_hit_stream = preload("res://assets/squirrel_hit.wav")

var audio_music: AudioStreamPlayer
var audio_fx: AudioStreamPlayer

func _ready() -> void:
    # Critical camera correction: perfectly level Wolfenstein-style horizon.
    camera.rotation = Vector3.ZERO
    camera.fov = 72.0
    camera.near = 0.05
    camera.far = 40.0

    carolina.texture = load("res://assets/carolina_face.png")
    mission_panel.visible = false
    muzzle.visible = false
    hit_marker.visible = false
    knob.position = joystick.size * 0.5 - knob.size * 0.5
    _setup_audio()
    _update_hud()
    _set_message("Парк найден. Жёлуди существуют. Белки пока ничего не подозревают.", 4.0)
    _refresh_minimap()

func _setup_audio() -> void:
    audio_music = AudioStreamPlayer.new()
    audio_music.stream = music_stream
    audio_music.volume_db = -9.0
    add_child(audio_music)
    audio_fx = AudioStreamPlayer.new()
    add_child(audio_fx)
    audio_music.play()

func _physics_process(delta: float) -> void:
    if mission_complete or mission_failed:
        player.velocity = Vector3.ZERO
        return

    var forward := -move_axis.y
    player.velocity = -player.global_transform.basis.z * (forward * WALK_SPEED)
    player.velocity.y = 0.0
    player.move_and_slide()

    if abs(move_axis.x) > 0.04:
        player.rotate_y(-move_axis.x * TURN_SPEED * delta)

    camera.rotation.x = 0.0
    camera.rotation.z = 0.0

    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    recoil_time = maxf(0.0, recoil_time - delta)
    message_time = maxf(0.0, message_time - delta)

    if message_time <= 0.0:
        message_label.text = ""
    if recoil_time <= 0.0:
        weapon.position.y = 455.0
    if muzzle.visible:
        muzzle.modulate.a = clampf(muzzle.modulate.a - delta * 7.0, 0.0, 1.0)
        if muzzle.modulate.a <= 0.0:
            muzzle.visible = false

    if abs(forward) > 0.05:
        bob += delta * 10.0
        foot_timer -= delta
        if foot_timer <= 0.0:
            _footstep()
            foot_timer = 0.30
    else:
        foot_timer = 0.0

    _update_squirrels(delta)
    _collect_acorns()
    _check_fake_cone()
    _update_hud()
    _refresh_minimap()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            if _point_in_rect(event.position, joystick.get_global_rect()):
                joystick_touch_id = event.index
                _update_joystick(event.position)
                get_viewport().set_input_as_handled()
            elif _point_in_rect(event.position, fire_button.get_global_rect()):
                _on_fire_pressed()
                get_viewport().set_input_as_handled()
            elif _point_in_rect(event.position, mute_button.get_global_rect()):
                _toggle_music()
                get_viewport().set_input_as_handled()
        elif event.index == joystick_touch_id:
            joystick_touch_id = -1
            move_axis = Vector2.ZERO
            _reset_joystick()
            get_viewport().set_input_as_handled()

    elif event is InputEventScreenDrag and event.index == joystick_touch_id:
        _update_joystick(event.position)
        get_viewport().set_input_as_handled()

    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            if _point_in_rect(event.position, joystick.get_global_rect()):
                mouse_joystick = true
                _update_joystick(event.position)
            elif _point_in_rect(event.position, fire_button.get_global_rect()):
                _on_fire_pressed()
            elif _point_in_rect(event.position, mute_button.get_global_rect()):
                _toggle_music()
        elif mouse_joystick:
            mouse_joystick = false
            move_axis = Vector2.ZERO
            _reset_joystick()

    elif event is InputEventMouseMotion and mouse_joystick:
        _update_joystick(event.position)

func _point_in_rect(point: Vector2, rect: Rect2) -> bool:
    return rect.has_point(point)

func _update_joystick(position: Vector2) -> void:
    var center := joystick.get_global_rect().get_center()
    var delta := position - center
    if delta.length() > JOYSTICK_RADIUS:
        delta = delta.normalized() * JOYSTICK_RADIUS
    move_axis = Vector2(delta.x / JOYSTICK_RADIUS, delta.y / JOYSTICK_RADIUS)
    knob.position = joystick.size * 0.5 - knob.size * 0.5 + delta

func _reset_joystick() -> void:
    knob.position = joystick.size * 0.5 - knob.size * 0.5

func _on_fire_pressed() -> void:
    if mission_complete or mission_failed or fire_cooldown > 0.0:
        return
    if ammo <= 0:
        _set_message("Пусто. Даже белки в шоке.", 1.2)
        return

    ammo -= 1
    fire_cooldown = 0.18
    recoil_time = 0.10
    weapon.position.y = 470.0
    muzzle.visible = true
    muzzle.modulate.a = 1.0
    _play_fx(shoot_stream)

    var query := PhysicsRayQueryParameters3D.create(
        camera.global_position,
        camera.global_position + (-camera.global_transform.basis.z * FIRE_RANGE),
        SQUIRREL_LAYER | WORLD_LAYER
    )
    query.collide_with_areas = true
    query.collide_with_bodies = true
    var hit := get_world_3d().direct_space_state.intersect_ray(query)

    if hit.is_empty():
        _miss()
        return

    var collider: Object = hit.get("collider")
    var squirrel := _find_squirrel_from_collider(collider)
    if squirrel == "":
        _miss()
        return

    if stunned.has(squirrel):
        _miss()
        return

    stunned[squirrel] = true
    var target := get_node_or_null(squirrel) as Sprite3D
    if target != null:
        target.modulate = Color(0.48, 0.70, 1.0, 1.0)
        target.rotation.z = deg_to_rad(-8.0)
    hit_marker.visible = true
    hit_marker.text = "×"
    _play_fx(squirrel_hit_stream)
    _set_message("БЕЛКА ОГЛУШЕНА. Животное не пострадало. Повторный выстрел — мимо.", 2.0)
    await get_tree().create_timer(0.35).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _find_squirrel_from_collider(collider: Object) -> String:
    if collider == null:
        return ""
    var node := collider as Node
    if node == null:
        return ""
    while node != null:
        if squirrels.has(node.name):
            return node.name
        node = node.get_parent()
    return ""

func _miss() -> void:
    hit_marker.visible = true
    hit_marker.text = "•"
    _set_message("Мимо. Белки делают вид, что ничего не заметили.", 1.1)
    await get_tree().create_timer(0.22).timeout
    if not mission_complete and not mission_failed:
        hit_marker.visible = false

func _update_squirrels(delta: float) -> void:
    var player_pos := Vector2(player.global_position.x, player.global_position.z)
    for name in squirrels:
        if stunned.has(name):
            continue
        var node := get_node_or_null(name) as Sprite3D
        if node == null:
            continue
        var home: Vector2 = squirrel_home[name]
        var dist := home.distance_to(player_pos)
        if dist < 6.0 and dist > 1.8:
            var away := (home - player_pos).normalized()
            var proposed := home + away * delta * 0.45
            if not _is_wall(proposed.x, proposed.y):
                squirrel_home[name] = proposed
                node.position.x = proposed.x
                node.position.z = proposed.y
        node.rotation.z = sin(Time.get_ticks_msec() * 0.003 + float(squirrel_phase[name])) * 0.03
        if dist < 1.0:
            hp = max(0, hp - int(12.0 * delta))
            if hp <= 0:
                _fail()

func _is_wall(x: float, z: float) -> bool:
    # The V6 level uses perimeter walls; keep squirrels inside that proven play space.
    return x < -9.2 or x > 9.2 or z < -6.2 or z > 6.2

func _collect_acorns() -> void:
    for name in acorns.duplicate():
        var node := get_node_or_null(name) as Sprite3D
        if node != null and player.global_position.distance_to(node.global_position) <= ACORN_PICKUP_RADIUS:
            node.visible = false
            acorns.erase(name)
            collected += 1
            _set_message("Жёлудь добыт. Дарина будет довольна. Ещё %d." % (4 - collected), 1.8)
            if collected == 4:
                _complete()

func _check_fake_cone() -> void:
    if fake_cone_found:
        return
    var cone := get_node_or_null("FakePineCone") as Sprite3D
    if cone != null and player.global_position.distance_to(cone.global_position) <= 1.2:
        fake_cone_found = true
        hp = max(0, hp - 15)
        _set_message("ЭТО НЕ ЖЁЛУДЬ. Потеряно 15 HP. Это ШИШКА.", 2.4)
        if hp <= 0:
            _fail()

func _complete() -> void:
    mission_complete = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ЗАВЕРШЕНА"
    mission_body.text = "ЖЁЛУДИ: 4 / 4\n\nОН СУЩЕСТВУЕТ.\n\nP.S. Данил всё это время верил в тебя."
    weapon.visible = false

func _fail() -> void:
    mission_failed = true
    move_axis = Vector2.ZERO
    _reset_joystick()
    mission_panel.visible = true
    mission_title.text = "ОПЕРАЦИЯ ПРОВАЛЕНА"
    mission_body.text = "HP: 0\n\nБелки победили.\nЭто позор.\n\nНо Дарина всё ещё ждёт жёлуди."
    weapon.visible = false

func _update_hud() -> void:
    count_label.text = "ЖЁЛУДИ  %d / 4" % collected
    hp_ammo_label.text = "HP %d     AMMO %d" % [hp, ammo]

func _set_message(text: String, duration: float) -> void:
    message_label.text = text
    message_time = duration

func _footstep() -> void:
    if muted:
        return
    audio_fx.stream = foot1_stream if int(Time.get_ticks_msec() / 300) % 2 == 0 else foot2_stream
    audio_fx.play()

func _play_fx(stream: AudioStream) -> void:
    if muted:
        return
    audio_fx.stream = stream
    audio_fx.play()

func _toggle_music() -> void:
    muted = not muted
    mute_button.text = "×" if muted else "♪"
    if muted:
        audio_music.stop()
    elif not audio_music.playing:
        audio_music.play()
    _set_message("Музыка выключена." if muted else "Музыка возвращена. Белки снова слышат угрозу.", 1.6)

func _refresh_minimap() -> void:
    $HUD/Minimap.set_game_state(player.global_position, player.rotation.y, acorns, squirrels, stunned)
